const { timingSafeEqual } = require('node:crypto');

const HOST_SURFACE_CAPABILITIES = Object.freeze([
  'surface.list',
  'surface.create',
  'surface.attach',
  'surface.resize',
  'surface.close',
  'activity.read',
  'approval.respond',
  'usage.read',
  'diff.read',
  'repository.read',
  'preview.read',
  'file.upload',
  'terminal.attach',
  'terminal.persist'
]);

function bearerToken(req) {
  const authorization = typeof req.headers.authorization === 'string'
    ? req.headers.authorization
    : '';
  const match = authorization.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : '';
}

function tokensEqual(actual, expected) {
  const actualBuffer = Buffer.from(actual);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length
    && timingSafeEqual(actualBuffer, expectedBuffer);
}

function validDimension(value) {
  return Number.isInteger(value) && value > 0 && value <= 1000;
}

function parseCreateRequest(body) {
  if (!Array.isArray(body.argv) || body.argv.length === 0) {
    throw new Error('argv must be a non-empty array');
  }
  if (body.argv.some((argument) => typeof argument !== 'string' || argument.includes('\0'))) {
    throw new Error('argv must contain only strings without NUL bytes');
  }
  if (body.cwd !== undefined && (typeof body.cwd !== 'string' || body.cwd.trim() === '')) {
    throw new Error('cwd must be a non-empty string');
  }
  const columns = body.columns === undefined ? 80 : body.columns;
  const rows = body.rows === undefined ? 24 : body.rows;
  if (!validDimension(columns) || !validDimension(rows)) {
    throw new Error('columns and rows must be integers from 1 through 1000');
  }
  return {
    argv: [...body.argv],
    cwd: body.cwd,
    columns,
    rows
  };
}

function createHostSurfaceApi({
  hostToken,
  serverBootID,
  surfaceRegistry,
  attachTicketStore,
  hostDescriptor,
  hostCapabilities = HOST_SURFACE_CAPABILITIES,
  readJsonBody,
  sendJson
}) {
  const expectedToken = typeof hostToken === 'string' ? hostToken : '';

  function authenticate(req, res) {
    if (expectedToken === '') {
      sendJson(res, 503, { ok: false, error: 'host API authentication is not configured' });
      return false;
    }
    if (!tokensEqual(bearerToken(req), expectedToken)) {
      res.setHeader('www-authenticate', 'Bearer');
      sendJson(res, 401, { ok: false, error: 'invalid host bearer token' });
      return false;
    }
    return true;
  }

  function requireRegistry(res) {
    if (!surfaceRegistry) {
      sendJson(res, 503, { ok: false, error: 'surface registry is unavailable' });
      return false;
    }
    return true;
  }

  async function handle(req, res, url) {
    if (url.pathname !== '/v1/host' && !url.pathname.startsWith('/v1/surfaces')) {
      return false;
    }
    if (!authenticate(req, res)) {
      return true;
    }

    const method = req.method || 'GET';
    if (method === 'GET' && url.pathname === '/v1/host') {
      sendJson(res, 200, {
        ok: true,
        host: {
          ...hostDescriptor,
          server_boot_id: serverBootID,
          capabilities: hostCapabilities
        }
      });
      return true;
    }
    if (!requireRegistry(res)) {
      return true;
    }
    if (method === 'GET' && url.pathname === '/v1/surfaces') {
      sendJson(res, 200, {
        ok: true,
        server_boot_id: serverBootID,
        surfaces: surfaceRegistry.list()
      });
      return true;
    }

    if (method === 'POST' && url.pathname === '/v1/surfaces') {
      try {
        const body = await readJsonBody(req);
        const surface = surfaceRegistry.create(parseCreateRequest(body));
        sendJson(res, 201, {
          ok: true,
          server_boot_id: serverBootID,
          surface
        });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return true;
    }

    const ticketMatch = url.pathname.match(/^\/v1\/surfaces\/([^/]+)\/attach-tickets$/);
    if (method === 'POST' && ticketMatch) {
      const surfaceId = decodeURIComponent(ticketMatch[1]);
      try {
        const body = await readJsonBody(req);
        if (body.server_boot_id !== serverBootID) {
          sendJson(res, 409, {
            ok: false,
            error: 'server boot identity does not match'
          });
          return true;
        }
        const surface = surfaceRegistry.get(surfaceId);
        if (!surface || surface.state !== 'running') {
          sendJson(res, 404, { ok: false, error: 'surface not found' });
          return true;
        }
        if (!attachTicketStore) {
          sendJson(res, 503, { ok: false, error: 'attach ticket store is unavailable' });
          return true;
        }
        const attachTicket = attachTicketStore.issue({
          surfaceId,
          serverBootID
        });
        sendJson(res, 201, { ok: true, attach_ticket: attachTicket });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return true;
    }

    const resizeMatch = url.pathname.match(/^\/v1\/surfaces\/([^/]+)\/resize$/);
    if (method === 'POST' && resizeMatch) {
      const surfaceId = decodeURIComponent(resizeMatch[1]);
      try {
        const body = await readJsonBody(req);
        if (!validDimension(body.columns) || !validDimension(body.rows)) {
          throw new Error('columns and rows must be integers from 1 through 1000');
        }
        const surface = surfaceRegistry.resize(surfaceId, body.columns, body.rows);
        if (!surface) {
          sendJson(res, 404, { ok: false, error: 'surface not found' });
          return true;
        }
        sendJson(res, 200, { ok: true, surface });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return true;
    }

    const surfaceMatch = url.pathname.match(/^\/v1\/surfaces\/([^/]+)$/);
    if (method === 'DELETE' && surfaceMatch) {
      const surfaceId = decodeURIComponent(surfaceMatch[1]);
      if (!surfaceRegistry.close(surfaceId)) {
        sendJson(res, 404, { ok: false, error: 'surface not found' });
        return true;
      }
      sendJson(res, 200, { ok: true, surface_id: surfaceId });
      return true;
    }

    sendJson(res, 404, { ok: false, error: 'surface endpoint not found' });
    return true;
  }

  return { authenticate, handle };
}

module.exports = {
  HOST_SURFACE_CAPABILITIES,
  createHostSurfaceApi,
  parseCreateRequest
};
