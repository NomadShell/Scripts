# Moshline host helper (`nomad-bridge` / `nomad-hook`)

The Moshline host helper is the host-side companion for Moshline's mobile control surface. It ingests events from existing CLI coding agents, normalizes them into `Nomad Event v1`, forwards notification callbacks, and exposes lightweight session metadata to mobile clients. `nomad-bridge` and `nomad-hook` remain internal package/protocol names.

Bridge is not the default owner of agent execution. Users run Claude Code,
Codex CLI, Gemini CLI, OpenCode, Cursor Agent, Kimi Code, Qwen Code, and similar
tools directly in their shell or tmux sessions. The `/agents/*` and `/codex/*`
managed runtime APIs are compatibility and development tools, not the preferred
product path.

## Host daemon setup

Install the host package on macOS or Ubuntu/Debian Linux, then run:

```bash
moshline-host setup
moshline-host doctor
moshline-host run -- codex
```

`setup` installs a LaunchAgent or user systemd service, merges supported agent
hooks, and prints a `moshline://pair` QR payload. The daemon owns persistent PTY
surfaces; hooks can only report an observed surface, while the current daemon
registry is the authority that upgrades it to a verified attach route.

Setup preserves existing JSON/TOML hooks and is idempotent. To remove only the
Moshline-owned adapter for one provider:

```bash
moshline-host hooks uninstall --agent cursor
```

Omit `--agent` to remove all Moshline-owned hook entries; unrelated user hooks
and Kimi configuration remain intact.

## Run

```bash
cd bridge
npm install
npm start
npm test
npm run test:contracts
npm run start
npm run snapshot:beta -- --bridge http://127.0.0.1:24000
npm run snapshot:beta:summary -- --window-days 7 --samples-per-day 2
npm run snapshot:beta:incident -- --report-dir ../reports/beta-acceptance
npm run soak:beta -- --bridge http://127.0.0.1:24000 --duration-seconds 14400 --interval-seconds 300
npm run capture:moshi-parity -- --milestone m2,m3,m4,m5 --session <real-session-id>
```

`capture:moshi-parity` creates a redacted host/session/event-ID scaffold for the
physical-device release gates. It is not an automatic pass. Follow
[`../docs/evidence/2026-07-12-physical-acceptance-runbook.md`](../docs/evidence/2026-07-12-physical-acceptance-runbook.md)
and fill the device result/artifact columns before promoting parity rows.

Environment variables:
- `BRIDGE_HOST` (default `127.0.0.1`)
- `BRIDGE_PORT` (default `24000`)
- `BRIDGE_DATA_DIR` (default `./data`)
- `BRIDGE_NOTIFICATION_WEBHOOK_URL` (optional; forwards `permission.requested` as webhook payload)
- `BRIDGE_NOTIFICATION_WEBHOOK_SECRET` (optional; HMAC-SHA256 signs notification webhook body with anti-replay headers)
- `BRIDGE_POLICY_WHITELIST_COMMANDS` (optional comma-separated commands; whitelist match will be marked no-confirmation in policy metadata)
- `BRIDGE_POLICY_ENFORCE_HIGH_RISK_REASON` (optional boolean; when enabled, approved decisions for high-risk/unknown requests require a non-empty reason)
- `BRIDGE_POLICY_CONFIG_SIGNING_SECRET` (optional; if set, `POST /policy/config` requires HMAC signature headers)
- `BRIDGE_POLICY_CONFIG_REPLAY_WINDOW_SECONDS` (optional; default `300`, used for policy config timestamp skew and nonce replay window)
- `BRIDGE_SECURITY_ALERT_WEBHOOK_URL` (optional; sends high-severity policy security alerts, e.g. signed config rejection attempts)
- `BRIDGE_SECURITY_ALERT_WEBHOOK_MIN_SEVERITY` (optional; default `high`, values: `none|low|medium|high|critical`, filters outbound security alert webhooks)
- `BRIDGE_SECURITY_ALERT_WEBHOOK_CODE_ALLOWLIST` (optional comma-separated codes, e.g. `policy.config.rejected`; empty means no code filter)
- `BRIDGE_SECURITY_ALERT_WEBHOOK_ROUTES` (optional JSON array; per-route webhook config with `webhook_url`, `min_severity`, `code_allowlist`, `enabled`)
- `BRIDGE_SECURITY_ALERT_ESCALATION_WEBHOOK_URL` (optional; sends `security.alert.escalated` payload when unacknowledged alerts are auto-escalated)
- `BRIDGE_SECURITY_ALERT_ESCALATION_ENABLED` (optional boolean; enables periodic SLA-based alert escalation)
- `BRIDGE_SECURITY_ALERT_ESCALATION_INTERVAL_SECONDS` (optional; default `0` disabled)
- `BRIDGE_SECURITY_ALERT_ESCALATION_ACK_DEADLINE_SECONDS` (optional; default `900`)
- `BRIDGE_SECURITY_ALERT_ESCALATION_MIN_SEVERITY` (optional; default `high`)
- `BRIDGE_SECURITY_ALERT_ESCALATION_CODE_ALLOWLIST` (optional comma-separated codes; empty means no code filter)
- `BRIDGE_SECURITY_ALERT_ESCALATION_ACTOR` (optional; default `nomad-auto`)
- `BRIDGE_SECURITY_ALERT_ESCALATION_NOTE` (optional; default `SLA breach`)
- `BRIDGE_CURSOR_MAX_AGE_SECONDS` (optional; default `604800`, `0` disables cursor expiry)
- `BRIDGE_ENABLE_MANAGED_RUNTIME` (optional; set to `1` to mark managed runtime APIs as explicitly enabled in `/health`)

## Endpoints

- `GET /health`
- `GET /console`
- `GET /console/app.js`
- `GET /console/styles.css`
- `POST /console/api/policy/config`
- `GET /sessions/summary?window_seconds=3600`
- `GET /metrics/kpi?window_seconds=3600`
- `GET /policy/config`
- `GET /policy/audit`
- `GET /policy/audit/summary`
- `GET /security/alerts`
- `GET /security/alerts/summary`
- `POST /security/alerts/:alert_id/ack`
- `POST /security/alerts/escalate`
- `POST /policy/config`
- `POST /policy/evaluate`
- `POST /hooks/claude`
- `POST /hooks/claude/session-start`
- `POST /hooks/codex`
- `GET /agents/hooks`
- `GET /agents/hooks/:agent_id/install-plan`
- `GET /agents/sessions/:session_id/metadata`
- `POST /claude/hooks/settings`
- `POST /claude/hooks/install`
- `GET /agents/sessions/:session_id/events?limit=200&cursor=<event_id>`
- `GET /agents/sessions/:session_id/artifacts`
- `GET /agents/sessions/:session_id/cursor`
- `POST /agents/sessions/:session_id/cursor`
- `POST /sessions/:session_id/permissions/decide`
- `GET /sessions/:session_id/events?limit=200&cursor=<event_id>`
- `GET /sessions/:session_id/cursor`
- `POST /sessions/:session_id/cursor`
- `POST /sessions/cursors/prune`
- `GET /v1/notification-rules` (host bearer token required)
- `PUT /v1/notification-rules` (host bearer token required)
- `POST /v1/metrics/events` (host bearer token required)
- `GET /v1/metrics/product?window_seconds=2592000` (host bearer token required)
- `GET /v1/sessions` (host bearer token required)
- `GET /v1/sessions/:session_id/events` (host bearer token required)
- `POST /v1/sessions/:session_id/command` (host bearer token required)
- `POST /v1/sessions/:session_id/approval/respond` (host bearer token required)

The versioned mobile contract is published under [`../contracts/v1`](../contracts/v1).
Paired clients use these bearer-only routes. The unversioned `/agents/*` paths
remain compatibility/local-development surfaces and are not the Android client
contract.

Compatibility/development managed runtime APIs:
- `POST /agents/sessions/start`
- `GET /agents/sessions`
- `GET /agents/runtime`
- `POST /agents/sessions/:session_id/command`
- `POST /agents/sessions/:session_id/stop`
- `POST /agents/sessions/:session_id/approval/respond`
- `POST /codex/sessions/start`
- `GET /codex/sessions`
- `GET /codex/runtime`
- `POST /codex/sessions/:session_id/command`
- `POST /codex/sessions/:session_id/stop`
- `POST /codex/sessions/:session_id/elicitation/respond`

`/agents/*` and `/codex/*` managed runtime APIs remain for compatibility with existing iOS and script clients, plus local development of runtime adapters. They are not the default mobile setup path.

## Mobile Setup Checklist

Moshline's iOS setup checks the local host helper, event ingestion, session replay, cursor sync, and mobile notification path. Start the Bridge first:

```bash
cd bridge
npm install
npm start
```

Then verify from the same network context used by the app:

```bash
curl http://127.0.0.1:24000/health
```

On a physical iPhone, `127.0.0.1` is the phone itself. Use a LAN-reachable Bridge URL or the app's SSH Relay mode when testing from device hardware. The mobile checklist also reports APNS token availability, notification webhook configuration, SSH Relay readiness, and a webhook test round-trip.

For the preferred product flow, install `nomad-hook` into the CLI agents you already use, run those agents in shell or tmux, and let Bridge project their events into Moshline's mobile Inbox. Use `/agents/runtime` or `/codex/runtime` only when intentionally testing managed runtime compatibility.

## Managed Runtime Compatibility

The APIs below can start and steer Bridge-owned runtime processes for compatibility testing and adapter development. They are not required for the default Nomad mobile control surface.

`POST /agents/sessions/start` and `POST /codex/sessions/start` support:
- `session_id` (optional stable bridge session id)
- `runtime: "codex_cli" | "pi_rpc"` (optional; defaults to `BRIDGE_AGENT_RUNTIME`)
- `mode: "cli" | "mcp"` (default `cli`)
- when `mode="mcp"` and no `args` are provided, bridge auto-selects `mcp` or `mcp-server` based on local Codex version.

Managed Agent session responses include provider/runtime metadata:
- `session_id`, `pid`, `running`
- `provider`, `runtime` (`codex_cli|pi_rpc`)
- `mode` (`cli|mcp`)
- `command`, `args`, `cwd`
- `mcp_subcommand`, `started_at`

`POST /agents/sessions/:session_id/command` and `/codex/sessions/:session_id/command` support:
- `type`: `prompt | steer | follow_up | abort | get_state`
- `message`: required for `prompt`, `steer`, and `follow_up`
- `images`: optional runtime passthrough
- `id`: optional client command id
- `streaming_behavior`: optional runtime passthrough

`POST /agents/sessions/:session_id/approval/respond` is the provider-neutral approval callback:
- with `request_id`, bridge forwards to the running runtime elicitation protocol when supported.
- without `request_id`, bridge appends an idempotent generic `permission.decided` event by `request_event_id`.
- when the source request carries `agent_run_id`, the response must carry the
  same value; stale or missing run identity is rejected with HTTP `409`.
- strict high-risk reason gating applies to both modes.
- legacy `POST /codex/sessions/:session_id/elicitation/respond` remains available for Codex MCP elicitation responses.

`GET/POST /agents/sessions/:session_id/cursor` mirrors `/sessions/:session_id/cursor` for shared timeline cursor sync. `POST` accepts `cursor` plus optional `if_match_updated_timestamp`; stale writes return `409 cursor version conflict` with the server's current state.

`GET /sessions/summary` response includes cross-session aggregates in the given window:
- `total_events`, `total_sessions`, `active_sessions`
- `source_counts`, `type_counts`, `risk_counts`
- `permission.requested/decided/approved/denied/pending`

`GET /metrics/kpi` response includes KPI-oriented aggregates in the given window:
- `connection`: `started/ended/ended_ok/ended_nonzero/success_rate`
- `approval`: `requested/decided/approved/denied/pending/average_latency_ms/p95_latency_ms`
- `task`: `started/completed/failed/aborted/completion_rate`
- `reliability`: `system_errors/session_end_nonzero`

`/sessions/:session_id/permissions/decide` is idempotent by
`request_event_id` and enforces matching `agent_run_id` for modern requests.
A replay with the same decision returns the original result; a conflicting
decision fails with HTTP `409` and records `approval.idempotency_violation`.

`/v1/notification-rules` persists at most 100 project + event-type rules and
applies replacements immediately, without a hook/helper restart. Product
metrics are privacy-bounded local JSONL events: only fixed identifiers,
timestamps, booleans, and counts are accepted; command text and summaries are
rejected. `/v1/metrics/product` aggregates the PRD activation, decision-loop,
truthful-route, handoff reconnect, W4 retention, and conversion measures.

MCP parsing:
- `jsonrpc method=codex/event` notifications are normalized to Event v1.
- `jsonrpc method=elicitation/create` requests are normalized as `permission.requested`.
- stdio supports both newline-delimited JSON and MCP `Content-Length` framed messages.
- elicitation response writes back as MCP `Content-Length` JSON-RPC frame.

Policy enrichment (advisory + whitelist auto-approve):
- `permission.requested` events are enriched with `payload.policy`.
- `meta.risk_level` may be adjusted by policy rules (e.g. whitelist -> `none`, dangerous pattern -> higher risk).
- Current rules cover command whitelist and dangerous command patterns (`rm -rf`, `git push --force`, `sudo`, publish/delete operations).
- For running Codex sessions, if a `permission.requested` event is whitelist-matched and includes `request_id`, bridge auto-responds approval to MCP and appends `permission.decided` (`actor=policy`) without triggering push callback.
- `GET /policy/config` returns current whitelist command set.
- `GET /policy/config` also returns policy signing requirement, security alert webhook routing fields, and security alert escalation scheduler fields.
- `POST /policy/config` updates runtime whitelist / strict gate / security alert routing config / escalation scheduler config and persists to `<BRIDGE_DATA_DIR>/policy.json`.
- when `BRIDGE_POLICY_CONFIG_SIGNING_SECRET` is enabled, `POST /policy/config` requires:
  - `x-nomad-policy-signature-version: v1`
  - `x-nomad-policy-timestamp`
  - `x-nomad-policy-nonce`
  - `x-nomad-policy-signature`
- policy config signature base string: `${timestamp}.${nonce}.${raw_json_body}`.
- bridge rejects replayed policy nonces within the replay window and records both accepted and rejected updates in policy audit log.
- `GET /policy/audit?limit=50` returns recent policy config audit events.
- `GET /policy/audit/summary?window_seconds=86400` returns action/status aggregates in the requested window.
- when `BRIDGE_SECURITY_ALERT_WEBHOOK_URL` is configured, bridge emits `security.alert` webhook on high-severity `policy.config.rejected` events (status >= 401).
- strict gate rejections (`policy.reason_required`) also emit `security.alert` and are filtered/routed by the same severity+code rules.
- when `BRIDGE_SECURITY_ALERT_WEBHOOK_MIN_SEVERITY` is configured, webhook emission is threshold-filtered by severity rank (local alert persistence is unaffected).
- when `BRIDGE_SECURITY_ALERT_WEBHOOK_CODE_ALLOWLIST` is configured, webhook emission is additionally filtered by alert `code` (`*` wildcard supported; empty means no code filter).
- when `BRIDGE_SECURITY_ALERT_WEBHOOK_ROUTES` is configured, each route applies its own severity/code filter and dispatches to its own `webhook_url` (`enabled=false` route is skipped).
- high-severity alerts are also persisted locally and queryable via `GET /security/alerts?limit=50`.
- alert severity/code aggregates are queryable via `GET /security/alerts/summary?window_seconds=86400`.
- alert summary also includes `acknowledged_count` and `unacknowledged_count`.
- alert summary also includes `escalated_count` and `unescalated_count`.
- `POST /security/alerts/escalate` supports SLA escalation for unacknowledged alerts with filters: `ack_deadline_seconds`, `min_severity`, `code_allowlist`, `actor`, `note`.
- escalation is idempotent per alert: already escalated alerts are skipped on subsequent runs.
- when `BRIDGE_SECURITY_ALERT_ESCALATION_WEBHOOK_URL` is configured, each escalation dispatches `security.alert.escalated` webhook payload.
- scheduler auto-escalation can be enabled via `/policy/config` fields:
  - `security_alert_escalation_enabled`
  - `security_alert_escalation_interval_seconds`
  - `security_alert_escalation_ack_deadline_seconds`
  - `security_alert_escalation_min_severity`
  - `security_alert_escalation_code_allowlist`
  - `security_alert_escalation_actor`
  - `security_alert_escalation_note`
- `POST /policy/config` also supports `enforce_high_risk_reason` to toggle strict approval reason gating.
- `POST /console/api/policy/config` is a console-only loopback endpoint for policy edits without exposing signing secrets in the browser.
  - currently supports: `whitelist_commands`, `enforce_high_risk_reason`
  - when `BRIDGE_POLICY_CONFIG_SIGNING_SECRET` is enabled, this endpoint remains writable for local console clients (`127.0.0.1` / `::1`) while external unsigned `POST /policy/config` is still rejected.
- `POST /policy/evaluate` performs dry-run classification for a command (`risk_level` + policy rationale).
- when strict gate is enabled, `approved` decisions without reason are rejected for high-risk (or unknown-context) requests.
- gate rejections are appended to session replay as `system.error` (`payload.code=policy.reason_required`) for timeline/audit visibility.

Webhook signing:
- when `BRIDGE_NOTIFICATION_WEBHOOK_SECRET` is set, bridge signs webhook payload with HMAC-SHA256 (`v1`) and sends:
  - `x-nomad-signature-version: v1`
  - `x-nomad-timestamp: <unix-seconds>`
  - `x-nomad-nonce: <uuid>`
  - `x-nomad-signature: <hex-hmac>`
- signature base string: `${timestamp}.${nonce}.${raw_json_body}`

Replay response fields:
- `events`: current page of events
- `next_cursor`: last event id in current page
- `has_more`: whether there are additional events after this page

Session cursor sync fields:
- `session_id`: target session id
- `cursor`: shared cursor (`null` means cleared)
- `updated_at` / `updated_timestamp`: last cursor write time
- `POST /sessions/:session_id/cursor` accepts optional `if_match_updated_timestamp` for optimistic concurrency; stale writes return `409 cursor version conflict` with server `current` state.
- cursor reads apply lifecycle policy via `BRIDGE_CURSOR_MAX_AGE_SECONDS` (expired cursors are treated as cleared and removed from disk).
- `POST /sessions/cursors/prune` body: `{ "max_age_seconds": 86400 }` (optional override; default server max age), response includes `removed_count` and `removed_sessions`.

Security alert fields:
- each alert includes stable `id`
- each alert includes triage state: `acknowledged`, `acknowledged_at`, `acknowledged_by`, `ack_note`, `ack_event_id`
- each alert includes escalation state: `escalated`, `escalated_at`, `escalated_by`, `escalation_note`, `escalation_reason`, `escalation_event_id`
- `POST /security/alerts/:alert_id/ack` body: `{ "actor": "ios", "note": "optional" }` (idempotent)
- `POST /security/alerts/escalate` body example:
  - `{ "ack_deadline_seconds": 900, "min_severity": "high", "code_allowlist": ["policy.config.rejected"], "actor": "nomad-auto", "note": "SLA breach" }`

## Storage

Replay log is append-only JSONL per session:
- `data/events/<url-encoded-session-id>.jsonl`

Beta snapshot artifacts:
- `../reports/beta-acceptance/snapshot-<timestamp>.json`
- `../reports/beta-acceptance/snapshot-<timestamp>.md`
- `../reports/beta-acceptance/latest.json`
- `../reports/beta-acceptance/latest.md`
- `../reports/beta-acceptance/history.ndjson`
- `../reports/beta-acceptance/summary-<timestamp>.json`
- `../reports/beta-acceptance/summary-<timestamp>.md`
- `../reports/beta-acceptance/summary-latest.json`
- `../reports/beta-acceptance/summary-latest.md`
- `../reports/beta-acceptance/incidents/incident-<timestamp>.md`
- `../reports/beta-acceptance/incidents/incident-latest.md`
- `../reports/beta-acceptance/soak/run-<timestamp>.json`
- `../reports/beta-acceptance/soak/run-<timestamp>.md`
- `../reports/beta-acceptance/soak/run-latest.json`
- `../reports/beta-acceptance/soak/run-latest.md`

Schema:
- `nomad-event-v1.schema.json`
