const { randomBytes, randomUUID } = require('node:crypto');
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { buildHookInstallPlan, getSupportedHookAgents } = require('./agentHookCatalog');
const { createProductMetricStore } = require('./productMetrics');

function configPathForHome(home) {
  return path.join(home, '.config', 'moshline', 'host.json');
}

function readHostConfig(configPath) {
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

function writePrivateJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
  const temporaryPath = `${filePath}.tmp-${process.pid}`;
  fs.writeFileSync(temporaryPath, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  fs.chmodSync(temporaryPath, 0o600);
  fs.renameSync(temporaryPath, filePath);
  fs.chmodSync(filePath, 0o600);
}

function mergeObjects(existing, incoming) {
  if (Array.isArray(existing) && Array.isArray(incoming)) {
    const seen = new Set(existing.map((value) => JSON.stringify(value)));
    return [
      ...existing,
      ...incoming.filter((value) => {
        const identity = JSON.stringify(value);
        if (seen.has(identity)) {
          return false;
        }
        seen.add(identity);
        return true;
      })
    ];
  }
  if (!existing || typeof existing !== 'object' || Array.isArray(existing)) {
    return incoming;
  }
  if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
    return incoming;
  }
  const merged = { ...existing };
  for (const [key, value] of Object.entries(incoming)) {
    merged[key] = mergeObjects(existing[key], value);
  }
  return merged;
}

function removeManagedTomlBlock(content, agentID) {
  const startMarker = `# >>> moshline hook ${agentID} >>>`;
  const endMarker = `# <<< moshline hook ${agentID} <<<`;
  const start = content.indexOf(startMarker);
  if (start < 0) {
    return content;
  }
  const end = content.indexOf(endMarker, start + startMarker.length);
  if (end < 0) {
    throw new Error(`managed ${agentID} hook block is missing its end marker`);
  }
  const remainder = `${content.slice(0, start)}${content.slice(end + endMarker.length)}`
    .replace(/\n{3,}/g, '\n\n')
    .trimEnd();
  return remainder ? `${remainder}\n` : '';
}

function installManagedTomlBlock(filePath, agentID, content) {
  const existing = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '';
  const base = removeManagedTomlBlock(existing, agentID).trimEnd();
  const next = `${base ? `${base}\n\n` : ''}${content.trim()}\n`;
  fs.writeFileSync(filePath, next, { mode: 0o600 });
  fs.chmodSync(filePath, 0o600);
}

function isManagedHookCommand(command, agentID) {
  return typeof command === 'string'
    && command.includes('nomad-hook emit')
    && command.includes(`--agent '${agentID}'`);
}

function removeManagedJSONHooks(value, agentID) {
  if (Array.isArray(value)) {
    return value
      .map((item) => removeManagedJSONHooks(item, agentID))
      .filter((item) => item !== undefined);
  }
  if (!value || typeof value !== 'object') {
    return value;
  }
  if (isManagedHookCommand(value.command, agentID)) {
    return undefined;
  }
  const cleaned = {};
  for (const [key, child] of Object.entries(value)) {
    const next = removeManagedJSONHooks(child, agentID);
    if (next !== undefined) {
      cleaned[key] = next;
    }
  }
  if (Array.isArray(cleaned.hooks) && cleaned.hooks.length === 0
    && Object.keys(cleaned).every((key) => ['hooks', 'matcher', 'sequential'].includes(key))) {
    return undefined;
  }
  return cleaned;
}

function expandHomePath(home, filePath) {
  return filePath === '~' ? home : filePath.replace(/^~\//, `${home}${path.sep}`);
}

function installAgentHooks({ home, bridgeURL, projectID = 'default' }) {
  const installed = [];
  for (const agent of getSupportedHookAgents()) {
    const plan = buildHookInstallPlan(agent.id, { bridgeURL, projectID });
    for (const file of plan.files) {
      const filePath = expandHomePath(home, file.path);
      fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
      if (file.mode === 'merge-json') {
        let existing = {};
        if (fs.existsSync(filePath)) {
          existing = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        }
        const incoming = JSON.parse(file.content);
        // Replace our previous managed entries before merging. This keeps
        // third-party hooks intact while allowing command changes (for
        // example Codex --quiet) to upgrade instead of leaving duplicates.
        const withoutManagedHooks = removeManagedJSONHooks(existing, agent.id) || {};
        writePrivateJson(filePath, mergeObjects(withoutManagedHooks, incoming));
      } else if (file.mode === 'managed-toml-block') {
        installManagedTomlBlock(filePath, agent.id, file.content);
      } else {
        fs.writeFileSync(filePath, file.content, { mode: 0o600 });
        fs.chmodSync(filePath, 0o600);
      }
      installed.push({ agent: agent.id, path: filePath });
    }
  }
  return installed;
}

function uninstallAgentHooks({ home, agentIDs } = {}) {
  const supported = getSupportedHookAgents();
  const selected = agentIDs === undefined
    ? supported
    : agentIDs.map((agentID) => {
      const agent = supported.find((candidate) => candidate.id === agentID);
      if (!agent) {
        throw new Error(`unsupported agent: ${agentID}`);
      }
      return agent;
    });
  const removed = [];
  for (const agent of selected) {
    const filePath = expandHomePath(home, agent.configPath);
    if (!fs.existsSync(filePath)) {
      continue;
    }
    const mode = agent.mode || 'merge-json';
    let changed = false;
    if (mode === 'merge-json') {
      const existing = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      const cleaned = removeManagedJSONHooks(existing, agent.id);
      changed = JSON.stringify(existing) !== JSON.stringify(cleaned);
      if (changed) {
        writePrivateJson(filePath, cleaned);
      }
    } else if (mode === 'managed-toml-block') {
      const existing = fs.readFileSync(filePath, 'utf8');
      const cleaned = removeManagedTomlBlock(existing, agent.id);
      changed = existing !== cleaned;
      if (changed) {
        fs.writeFileSync(filePath, cleaned, { mode: 0o600 });
        fs.chmodSync(filePath, 0o600);
      }
    } else if (mode === 'own-file') {
      const content = fs.readFileSync(filePath, 'utf8');
      if ((agent.id === 'opencode' && content.includes('NomadPlugin'))
        || content.includes(`--agent '${agent.id}'`)) {
        fs.unlinkSync(filePath);
        changed = true;
      }
    }
    if (changed) {
      removed.push({ agent: agent.id, path: filePath });
    }
  }
  return removed;
}

function xmlEscape(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&apos;');
}

function systemdQuote(value) {
  return `"${String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`;
}

function buildServiceEnvironmentPath(nodePath, environmentPath = process.env.PATH) {
  const volatilePrefixes = [
    '/tmp/',
    '/private/tmp/',
    '/var/folders/',
    '/var/run/',
    '/pkg/env/'
  ];
  const volatileSegments = [
    '/.codex/tmp/',
    '/.cache/codex-runtimes/'
  ];
  const durableEnvironmentEntries = typeof environmentPath === 'string'
    ? environmentPath.split(path.delimiter).filter((entry) => path.isAbsolute(entry)
      && !volatilePrefixes.some((prefix) => entry.startsWith(prefix))
      && !volatileSegments.some((segment) => entry.includes(segment)))
    : [];
  const entries = [
    path.dirname(nodePath),
    ...durableEnvironmentEntries,
    '/opt/homebrew/bin',
    '/usr/local/bin',
    '/usr/bin',
    '/bin',
    '/usr/sbin',
    '/sbin'
  ].filter(Boolean);
  return [...new Set(entries)].join(path.delimiter);
}

function buildSystemdService({ nodePath, cliPath, configPath, environmentPath }) {
  const servicePath = buildServiceEnvironmentPath(nodePath, environmentPath);
  return `[Unit]\nDescription=Moshline host daemon\nAfter=network-online.target\n\n[Service]\nType=simple\nEnvironment=${systemdQuote(`PATH=${servicePath}`)}\nEnvironment=${systemdQuote('LANG=en_US.UTF-8')}\nEnvironment=${systemdQuote('LC_CTYPE=en_US.UTF-8')}\nExecStart=${systemdQuote(nodePath)} ${systemdQuote(cliPath)} daemon --config ${systemdQuote(configPath)}\nRestart=on-failure\nRestartSec=2\n\n[Install]\nWantedBy=default.target\n`;
}

function buildLaunchAgent({ nodePath, cliPath, configPath, logPath, environmentPath }) {
  const arguments = [nodePath, cliPath, 'daemon', '--config', configPath]
    .map((argument) => `      <string>${xmlEscape(argument)}</string>`)
    .join('\n');
  const servicePath = buildServiceEnvironmentPath(nodePath, environmentPath);
  return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">\n<dict>\n  <key>Label</key>\n  <string>com.moshline.host</string>\n  <key>ProgramArguments</key>\n  <array>\n${arguments}\n  </array>\n  <key>EnvironmentVariables</key>\n  <dict>\n    <key>PATH</key>\n    <string>${xmlEscape(servicePath)}</string>\n    <key>LANG</key>\n    <string>en_US.UTF-8</string>\n    <key>LC_CTYPE</key>\n    <string>en_US.UTF-8</string>\n  </dict>\n  <key>RunAtLoad</key>\n  <true/>\n  <key>KeepAlive</key>\n  <true/>\n  <key>StandardOutPath</key>\n  <string>${xmlEscape(logPath)}</string>\n  <key>StandardErrorPath</key>\n  <string>${xmlEscape(logPath)}</string>\n</dict>\n</plist>\n`;
}

function installService({ platform, home, nodePath, cliPath, configPath, environmentPath }) {
  if (platform === 'linux') {
    const servicePath = path.join(home, '.config', 'systemd', 'user', 'moshline-host.service');
    fs.mkdirSync(path.dirname(servicePath), { recursive: true });
    fs.writeFileSync(servicePath, buildSystemdService({
      nodePath,
      cliPath,
      configPath,
      environmentPath
    }), {
      mode: 0o644
    });
    return { kind: 'systemd-user', servicePath };
  }
  if (platform === 'darwin') {
    const servicePath = path.join(home, 'Library', 'LaunchAgents', 'com.moshline.host.plist');
    const logPath = path.join(home, 'Library', 'Logs', 'Moshline', 'host.log');
    fs.mkdirSync(path.dirname(servicePath), { recursive: true });
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    fs.writeFileSync(
      servicePath,
      buildLaunchAgent({ nodePath, cliPath, configPath, logPath, environmentPath }),
      { mode: 0o644 }
    );
    return { kind: 'launch-agent', servicePath };
  }
  throw new Error(`unsupported host platform: ${platform}`);
}

function startService({ platform, home, servicePath }) {
  if (platform === 'linux') {
    const reload = spawnSync('systemctl', ['--user', 'daemon-reload'], { encoding: 'utf8' });
    if (reload.status !== 0) {
      throw new Error(`systemd reload failed: ${(reload.stderr || reload.stdout).trim()}`);
    }
    const enable = spawnSync('systemctl', ['--user', 'enable', '--now', 'moshline-host.service'], {
      encoding: 'utf8'
    });
    if (enable.status !== 0) {
      throw new Error(`systemd start failed: ${(enable.stderr || enable.stdout).trim()}`);
    }
    return;
  }
  const domain = `gui/${process.getuid()}`;
  spawnSync('launchctl', ['bootout', domain, servicePath], { encoding: 'utf8' });
  const result = spawnSync('launchctl', ['bootstrap', domain, servicePath], { encoding: 'utf8' });
  if (result.status !== 0) {
    throw new Error(`LaunchAgent start failed: ${(result.stderr || result.stdout).trim()}`);
  }
}

function buildPairingURL(config) {
  const url = new URL('moshline://pair');
  url.searchParams.set('v', '2');
  url.searchParams.set('host_id', config.host_id);
  url.searchParams.set('name', config.host_name);
  url.searchParams.set('address', config.address);
  url.searchParams.set('user', config.ssh_user);
  url.searchParams.set('ssh_port', String(config.ssh_port));
  url.searchParams.set('bridge_port', String(config.bridge_port));
  url.searchParams.set('token', config.host_token);
  return url.toString();
}

function setupHost({
  home = os.homedir(),
  platform = process.platform,
  address,
  user,
  sshPort,
  bridgePort,
  configPath = configPathForHome(home),
  nodePath = process.execPath,
  cliPath = path.join(__dirname, '..', 'bin', 'moshline-host.js'),
  environmentPath = process.env.PATH,
  shouldStart = true,
  shouldInstallHooks = true
}) {
  const existing = fs.existsSync(configPath) ? readHostConfig(configPath) : {};
  const stateDir = path.join(home, '.local', 'share', 'moshline');
  const config = {
    version: 2,
    host_id: existing.host_id || randomUUID(),
    host_name: existing.host_name || os.hostname(),
    // Preserve values from a previous setup when the caller did not explicitly
    // override them, so re-running `moshline-host setup` (e.g. to reinstall
    // hooks) does not silently reset a configured --address/--ssh-port.
    address: address || existing.address || os.hostname(),
    ssh_user: user || existing.ssh_user || os.userInfo().username,
    ssh_port: Number(sshPort || existing.ssh_port || 22),
    // The paired phone reaches the bridge directly at the advertised address
    // with a host bearer token, so the daemon must bind a routable interface.
    // Exposure is bounded by auth: /v1/* and /agents/* require the token, and
    // the event-ingestion/metadata routes require loopback or the token (see
    // requireLocalOrAuthenticated), so a LAN peer cannot forge events.
    bridge_host: existing.bridge_host || '0.0.0.0',
    bridge_port: Number(bridgePort || existing.bridge_port || 24000),
    host_token: existing.host_token || randomBytes(32).toString('base64url'),
    data_dir: existing.data_dir || stateDir,
    control_socket: existing.control_socket || path.join(stateDir, 'moshline-host.sock')
  };
  writePrivateJson(configPath, config);
  const productMetricStore = createProductMetricStore({
    filePath: path.join(config.data_dir, 'metrics', 'product-events.jsonl')
  });
  const setupMetric = (type) => productMetricStore.append({
    event_id: randomUUID(),
    type,
    timestamp: Math.floor(Date.now() / 1000),
    installation_id: config.host_id,
    host_id: config.host_id
  });
  setupMetric('setup.started');
  const service = installService({
    platform,
    home,
    nodePath,
    cliPath,
    configPath,
    environmentPath
  });
  const hooks = shouldInstallHooks
    ? installAgentHooks({
        home,
        bridgeURL: `http://127.0.0.1:${config.bridge_port}`
      })
    : [];
  if (shouldStart) {
    startService({ platform, home, servicePath: service.servicePath });
  }
  setupMetric('setup.completed');
  return {
    config,
    configPath,
    service,
    hooks,
    pairingURL: buildPairingURL(config)
  };
}

module.exports = {
  buildLaunchAgent,
  buildPairingURL,
  buildServiceEnvironmentPath,
  buildSystemdService,
  configPathForHome,
  installAgentHooks,
  uninstallAgentHooks,
  readHostConfig,
  setupHost
};
