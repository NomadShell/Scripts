'use strict';

class BoundedCache {
  constructor(limit) {
    if (!Number.isInteger(limit) || limit <= 0) {
      throw new Error('bounded cache limit must be a positive integer');
    }
    this.limit = limit;
    this.entries = new Map();
  }

  get size() {
    return this.entries.size;
  }

  has(key) {
    return this.entries.has(key);
  }

  get(key) {
    if (!this.entries.has(key)) {
      return undefined;
    }
    const value = this.entries.get(key);
    this.entries.delete(key);
    this.entries.set(key, value);
    return value;
  }

  set(key, value) {
    this.entries.delete(key);
    this.entries.set(key, value);
    while (this.entries.size > this.limit) {
      this.entries.delete(this.entries.keys().next().value);
    }
    return this;
  }

  delete(key) {
    return this.entries.delete(key);
  }
}

module.exports = { BoundedCache };
