const ALLOWED_RISK_LEVELS = ['none', 'low', 'medium', 'high', 'critical'];
const RISK_LEVEL_WEIGHT = new Map(ALLOWED_RISK_LEVELS.map((level, index) => [level, index]));

const DANGEROUS_COMMAND_RULES = [
  {
    id: 'dangerous.rm_rf',
    pattern: /(^|\s)rm\s+-rf(\s|$)/i,
    risk: 'critical',
    rationale: 'Matched destructive command pattern rm -rf'
  },
  {
    id: 'dangerous.force_push',
    pattern: /(^|\s)git\s+push\b[^\n]*--force(\s|$)/i,
    risk: 'high',
    rationale: 'Matched force-push pattern git push --force'
  },
  {
    id: 'dangerous.sudo',
    pattern: /(^|\s)sudo\s+/i,
    risk: 'high',
    rationale: 'Matched privileged execution pattern sudo'
  },
  {
    id: 'dangerous.publish',
    pattern: /(^|\s)(npm|pnpm|yarn)\s+publish(\s|$)/i,
    risk: 'high',
    rationale: 'Matched publish pattern that affects package distribution'
  },
  {
    id: 'dangerous.kubectl_delete',
    pattern: /(^|\s)kubectl\s+delete(\s|$)/i,
    risk: 'high',
    rationale: 'Matched kubectl delete pattern that can remove cluster resources'
  }
];

function normalizeCommand(value) {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim().replace(/\s+/g, ' ');
}

function normalizeRiskLevel(level) {
  if (typeof level !== 'string') {
    return 'none';
  }
  return RISK_LEVEL_WEIGHT.has(level) ? level : 'none';
}

function maxRiskLevel(left, right) {
  const leftLevel = normalizeRiskLevel(left);
  const rightLevel = normalizeRiskLevel(right);
  const leftWeight = RISK_LEVEL_WEIGHT.get(leftLevel);
  const rightWeight = RISK_LEVEL_WEIGHT.get(rightLevel);
  return leftWeight >= rightWeight ? leftLevel : rightLevel;
}

function parseCommaSeparatedList(raw) {
  if (typeof raw !== 'string') {
    return [];
  }
  return raw
    .split(',')
    .map((item) => normalizeCommand(item))
    .filter((item) => item !== '');
}

function parseBoolean(value, defaultValue = false) {
  if (typeof value === 'boolean') {
    return value;
  }
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (normalized === 'true' || normalized === '1' || normalized === 'yes') {
      return true;
    }
    if (normalized === 'false' || normalized === '0' || normalized === 'no') {
      return false;
    }
  }
  return defaultValue;
}

function isWhitelistedCommand(command, whitelistCommands) {
  const normalized = normalizeCommand(command).toLowerCase();
  for (const allowed of whitelistCommands) {
    const token = allowed.toLowerCase();
    if (normalized === token || normalized.startsWith(`${token} `)) {
      return allowed;
    }
  }
  return null;
}

function extractCommand(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return '';
  }

  if (typeof payload.command === 'string' && payload.command.trim() !== '') {
    return normalizeCommand(payload.command);
  }

  const toolInput = payload.tool_input && typeof payload.tool_input === 'object'
    && !Array.isArray(payload.tool_input)
    ? payload.tool_input
    : {};
  if (typeof toolInput.command === 'string' && toolInput.command.trim() !== '') {
    return normalizeCommand(toolInput.command);
  }

  if (Array.isArray(payload.command_args) && payload.command_args.length > 0) {
    return normalizeCommand(payload.command_args.map(String).join(' '));
  }

  if (typeof payload.cmd === 'string' && payload.cmd.trim() !== '') {
    return normalizeCommand(payload.cmd);
  }

  if (typeof toolInput.cmd === 'string' && toolInput.cmd.trim() !== '') {
    return normalizeCommand(toolInput.cmd);
  }

  if (payload.raw && typeof payload.raw === 'object' && !Array.isArray(payload.raw)) {
    if (Array.isArray(payload.raw.codex_command) && payload.raw.codex_command.length > 0) {
      return normalizeCommand(payload.raw.codex_command.map(String).join(' '));
    }
  }

  return '';
}

function buildDefaultPolicy(command) {
  return {
    command,
    requires_confirmation: true,
    decision: 'confirm',
    matched_rule: 'default.manual_confirm',
    rationale: 'No whitelist match; keep manual confirmation',
    risk_level: 'medium'
  };
}

function createPolicyEngine(options = {}) {
  const optionWhitelist = Array.isArray(options.whitelistCommands)
    ? options.whitelistCommands
    : [];
  const envWhitelist = parseCommaSeparatedList(process.env.BRIDGE_POLICY_WHITELIST_COMMANDS);
  let whitelistCommands = normalizeWhitelistCommands([...optionWhitelist, ...envWhitelist]);
  const envEnforceHighRiskReason = parseBoolean(process.env.BRIDGE_POLICY_ENFORCE_HIGH_RISK_REASON, false);
  let enforceHighRiskReason = parseBoolean(options.enforceHighRiskReason, envEnforceHighRiskReason);

  function setWhitelistCommands(commands) {
    if (!Array.isArray(commands)) {
      throw new Error('invalid whitelist_commands');
    }
    whitelistCommands = normalizeWhitelistCommands(commands);
    return [...whitelistCommands];
  }

  function setEnforceHighRiskReason(value) {
    enforceHighRiskReason = parseBoolean(value, false);
    return enforceHighRiskReason;
  }

  function evaluateCommand(command) {
    const normalizedCommand = normalizeCommand(command);
    if (!normalizedCommand) {
      return null;
    }

    const matchedWhitelist = isWhitelistedCommand(normalizedCommand, whitelistCommands);
    if (matchedWhitelist) {
      return {
        command: normalizedCommand,
        requires_confirmation: false,
        decision: 'allow',
        matched_rule: 'whitelist.command',
        rationale: `Command matches whitelist rule: ${matchedWhitelist}`,
        risk_level: 'none',
        override_risk_level: true
      };
    }

    for (const rule of DANGEROUS_COMMAND_RULES) {
      if (rule.pattern.test(normalizedCommand)) {
        return {
          command: normalizedCommand,
          requires_confirmation: true,
          decision: 'confirm',
          matched_rule: rule.id,
          rationale: rule.rationale,
          risk_level: rule.risk,
          override_risk_level: false
        };
      }
    }

    return buildDefaultPolicy(normalizedCommand);
  }

  function evaluateEvent(event) {
    if (!event || typeof event !== 'object' || Array.isArray(event)) {
      return event;
    }

    if (event.type !== 'permission.requested') {
      return event;
    }

    // Native Codex hooks can observe a permission check that is owned by the
    // provider's auto reviewer. Keep the event for audit, but do not replace
    // the verified non-manual outcome with Bridge's default manual policy.
    if (event.payload?.requires_manual_approval === false
      && ['provider_auto_review', 'provider_full_access']
        .includes(event.payload?.approval_context)) {
      return event;
    }

    const command = extractCommand(event.payload);
    if (!command) {
      return event;
    }

    const policyResult = evaluateCommand(command);
    if (!policyResult) {
      return event;
    }

    const originalRiskLevel = event.meta && typeof event.meta === 'object'
      ? normalizeRiskLevel(event.meta.risk_level)
      : 'none';

    const resolvedRiskLevel = policyResult.override_risk_level
      ? policyResult.risk_level
      : maxRiskLevel(originalRiskLevel, policyResult.risk_level);

    return {
      ...event,
      payload: {
        ...(event.payload || {}),
        command,
        requires_manual_approval: policyResult.requires_confirmation,
        policy: {
          requires_confirmation: policyResult.requires_confirmation,
          decision: policyResult.decision,
          matched_rule: policyResult.matched_rule,
          rationale: policyResult.rationale,
          risk_level: resolvedRiskLevel
        }
      },
      meta: {
        ...(event.meta || {}),
        risk_level: resolvedRiskLevel
      }
    };
  }

  return {
    evaluateEvent,
    evaluateCommand,
    setWhitelistCommands,
    setEnforceHighRiskReason,
    whitelistCommands: () => [...whitelistCommands],
    enforceHighRiskReason: () => enforceHighRiskReason
  };
}

function normalizeWhitelistCommands(commands) {
  if (!Array.isArray(commands)) {
    return [];
  }
  return Array.from(new Set(commands
    .map((item) => normalizeCommand(String(item)))
    .filter((item) => item !== '')));
}

module.exports = {
  createPolicyEngine,
  ALLOWED_RISK_LEVELS
};
