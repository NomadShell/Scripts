'use strict';

const fs = require('node:fs');
const path = require('node:path');

const MAX_TRANSCRIPT_TAIL_BYTES = 2 * 1024 * 1024;
const MAX_SESSION_META_BYTES = 2 * 1024 * 1024;

function isObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function finiteNonNegative(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
    ? value
    : null;
}

function allowedTranscriptPath(filePath, { home, codexHome } = {}) {
  if (typeof filePath !== 'string' || filePath.trim() === '') {
    return null;
  }
  const resolvedHome = typeof home === 'string' && home.trim() !== ''
    ? path.resolve(home)
    : null;
  const resolvedCodexHome = path.resolve(
    typeof codexHome === 'string' && codexHome.trim() !== ''
      ? codexHome
      : path.join(resolvedHome || '', '.codex')
  );
  const candidate = path.resolve(filePath);
  const roots = [
    path.join(resolvedCodexHome, 'sessions'),
    path.join(resolvedCodexHome, 'archived_sessions')
  ];
  let canonicalCandidate;
  try {
    canonicalCandidate = fs.realpathSync(candidate);
  } catch {
    return null;
  }
  const allowed = roots.some((root) => {
    try {
      const canonicalRoot = fs.realpathSync(root);
      return canonicalCandidate === canonicalRoot
        || canonicalCandidate.startsWith(`${canonicalRoot}${path.sep}`);
    } catch {
      return false;
    }
  });
  return allowed ? canonicalCandidate : null;
}

function readTail(filePath, maxBytes = MAX_TRANSCRIPT_TAIL_BYTES) {
  const stat = fs.statSync(filePath);
  const bytes = Math.min(stat.size, maxBytes);
  const start = stat.size - bytes;
  const descriptor = fs.openSync(filePath, 'r');
  try {
    const buffer = Buffer.alloc(bytes);
    fs.readSync(descriptor, buffer, 0, bytes, start);
    let text = buffer.toString('utf8');
    if (start > 0) {
      const newline = text.indexOf('\n');
      text = newline >= 0 ? text.slice(newline + 1) : '';
    }
    return text;
  } finally {
    fs.closeSync(descriptor);
  }
}

function readFirstLine(filePath, maxBytes = MAX_SESSION_META_BYTES) {
  const stat = fs.statSync(filePath);
  const descriptor = fs.openSync(filePath, 'r');
  const chunks = [];
  let offset = 0;
  try {
    while (offset < stat.size && offset < maxBytes) {
      const bytes = Math.min(64 * 1024, stat.size - offset, maxBytes - offset);
      const buffer = Buffer.alloc(bytes);
      const read = fs.readSync(descriptor, buffer, 0, bytes, offset);
      if (read <= 0) {
        break;
      }
      const content = read === bytes ? buffer : buffer.subarray(0, read);
      const newline = content.indexOf(0x0a);
      if (newline >= 0) {
        chunks.push(content.subarray(0, newline));
        return Buffer.concat(chunks).toString('utf8');
      }
      chunks.push(content);
      offset += read;
    }
    return offset >= stat.size ? Buffer.concat(chunks).toString('utf8') : '';
  } finally {
    fs.closeSync(descriptor);
  }
}

function findRecordBackwards(filePath, matcher, chunkBytes = MAX_TRANSCRIPT_TAIL_BYTES) {
  const stat = fs.statSync(filePath);
  const descriptor = fs.openSync(filePath, 'r');
  let position = stat.size;
  let trailingFragment = Buffer.alloc(0);
  try {
    while (position > 0) {
      const start = Math.max(0, position - chunkBytes);
      const bytes = position - start;
      const buffer = Buffer.alloc(bytes);
      fs.readSync(descriptor, buffer, 0, bytes, start);
      const combined = Buffer.concat([buffer, trailingFragment]);
      const firstNewline = start > 0 ? combined.indexOf(0x0a) : -1;
      let parseBuffer = combined;
      if (start > 0) {
        if (firstNewline < 0) {
          trailingFragment = combined;
          position = start;
          continue;
        }
        trailingFragment = combined.subarray(0, firstNewline);
        parseBuffer = combined.subarray(firstNewline + 1);
      } else {
        trailingFragment = Buffer.alloc(0);
      }
      const lines = parseBuffer.toString('utf8').split('\n');
      for (let index = lines.length - 1; index >= 0; index -= 1) {
        if (!lines[index]) {
          continue;
        }
        try {
          const matched = matcher(JSON.parse(lines[index]));
          if (matched) {
            return matched;
          }
        } catch {
          // A single very large record can span multiple chunks. Its fragments
          // are joined on the next iteration before parsing.
        }
      }
      position = start;
    }
    return null;
  } finally {
    fs.closeSync(descriptor);
  }
}

function windowLabel(minutes) {
  if (!Number.isFinite(minutes) || minutes <= 0) {
    return 'Rate limit';
  }
  if (minutes % 10_080 === 0) {
    const days = (minutes / 1_440);
    return `${days} day`;
  }
  if (minutes % 1_440 === 0) {
    return `${minutes / 1_440} day`;
  }
  if (minutes % 60 === 0) {
    return `${minutes / 60} hour`;
  }
  return `${minutes} minute`;
}

function isoTimestamp(value) {
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? new Date(parsed).toISOString() : null;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    const milliseconds = Math.abs(value) >= 100_000_000_000 ? value : value * 1000;
    return new Date(milliseconds).toISOString();
  }
  return null;
}

function normalizeRateLimitWindow(kind, value, capturedAt) {
  if (!isObject(value)) {
    return null;
  }
  const usedPercent = finiteNonNegative(value.used_percent);
  if (usedPercent === null || usedPercent > 100) {
    return null;
  }
  const minutes = finiteNonNegative(value.window_minutes);
  return {
    id: `codex-${kind}-${minutes ?? 'unknown'}m`,
    label: windowLabel(minutes),
    ...(minutes !== null ? { duration_seconds: minutes * 60 } : {}),
    used_fraction: usedPercent / 100,
    remaining_fraction: 1 - (usedPercent / 100),
    ...(isoTimestamp(value.resets_at) ? { resets_at: isoTimestamp(value.resets_at) } : {}),
    captured_at: capturedAt
  };
}

function usageFromTokenCount(record) {
  if (!isObject(record) || record.type !== 'event_msg'
      || record.payload?.type !== 'token_count') {
    return null;
  }
  const capturedAt = isoTimestamp(record.timestamp) || new Date().toISOString();
  const info = isObject(record.payload.info) ? record.payload.info : {};
  const tokenUsage = isObject(info.last_token_usage)
    ? info.last_token_usage
    : (isObject(info.total_token_usage) ? info.total_token_usage : {});
  const contextUsed = finiteNonNegative(tokenUsage.total_tokens);
  const contextLimit = finiteNonNegative(info.model_context_window);
  const rateLimits = isObject(record.payload.rate_limits) ? record.payload.rate_limits : {};
  const windows = ['primary', 'secondary']
    .map((kind) => normalizeRateLimitWindow(kind, rateLimits[kind], capturedAt))
    .filter(Boolean);
  if (contextUsed === null && contextLimit === null && windows.length === 0) {
    return null;
  }
  const planType = typeof rateLimits.plan_type === 'string'
    ? rateLimits.plan_type.trim()
    : '';
  return {
    capturedAt,
    usage: {
      schema_version: windows.length > 0 ? 2 : 1,
      provider: 'codex',
      ...(planType ? { account_label: planType } : {}),
      captured_at: capturedAt,
      ...(contextUsed !== null ? { context_used_tokens: contextUsed } : {}),
      ...(contextLimit !== null ? { context_limit_tokens: contextLimit } : {}),
      ...(windows.length > 0 ? { windows } : {})
    },
    tokenUsage: {
      input_tokens: finiteNonNegative(tokenUsage.input_tokens),
      cached_input_tokens: finiteNonNegative(tokenUsage.cached_input_tokens),
      output_tokens: finiteNonNegative(tokenUsage.output_tokens),
      reasoning_output_tokens: finiteNonNegative(tokenUsage.reasoning_output_tokens),
      total_tokens: contextUsed
    }
  };
}

function approvalContextFromTurnContext(record, { turnId } = {}) {
  if (!isObject(record) || record.type !== 'turn_context' || !isObject(record.payload)) {
    return null;
  }
  const expectedTurnId = typeof turnId === 'string' ? turnId.trim() : '';
  const recordTurnId = typeof record.payload.turn_id === 'string'
    ? record.payload.turn_id.trim()
    : '';
  if (!expectedTurnId || !recordTurnId || recordTurnId !== expectedTurnId) {
    return null;
  }
  const approvalPolicy = typeof record.payload.approval_policy === 'string'
    ? record.payload.approval_policy.trim()
    : '';
  const approvalsReviewer = typeof record.payload.approvals_reviewer === 'string'
    ? record.payload.approvals_reviewer.trim()
    : '';
  const sandboxMode = typeof record.payload.sandbox_policy?.type === 'string'
    ? record.payload.sandbox_policy.type.trim()
    : '';
  return {
    ...(recordTurnId ? { turn_id: recordTurnId } : {}),
    ...(approvalPolicy ? { approval_policy: approvalPolicy } : {}),
    ...(approvalsReviewer ? { approvals_reviewer: approvalsReviewer } : {}),
    ...(sandboxMode ? { sandbox_mode: sandboxMode } : {})
  };
}

function sessionMetadataFromSessionMeta(record) {
  if (!isObject(record) || record.type !== 'session_meta' || !isObject(record.payload)) {
    return null;
  }
  const id = typeof record.payload.id === 'string' ? record.payload.id.trim() : '';
  const sessionId = typeof record.payload.session_id === 'string'
    ? record.payload.session_id.trim()
    : '';
  if (!id && !sessionId) {
    return null;
  }
  const resolvedSessionId = sessionId || id;
  const transcriptId = id || resolvedSessionId;
  const parentThreadId = typeof record.payload.parent_thread_id === 'string'
    ? record.payload.parent_thread_id.trim()
    : '';
  return {
    sessionId: resolvedSessionId,
    transcriptId,
    ...(transcriptId !== resolvedSessionId ? { agentId: transcriptId } : {}),
    ...(parentThreadId ? { parentThreadId } : {})
  };
}

function readCodexTranscriptSnapshot(filePath, options = {}) {
  const allowed = allowedTranscriptPath(filePath, options);
  if (!allowed) {
    return null;
  }
  let tail;
  let transcriptMetadata = null;
  try {
    tail = readTail(allowed);
  } catch {
    return null;
  }
  try {
    transcriptMetadata = sessionMetadataFromSessionMeta(
      JSON.parse(readFirstLine(allowed))
    );
  } catch {
    // Usage reads can still be served from a valid tail. Identity-bound reads
    // below remain fail-closed because they require verified session metadata.
    transcriptMetadata = null;
  }
  const expectedSessionId = typeof options.sessionId === 'string'
    ? options.sessionId.trim()
    : '';
  if (expectedSessionId && transcriptMetadata?.sessionId !== expectedSessionId) {
    return null;
  }
  const expectedAgentId = typeof options.agentId === 'string'
    ? options.agentId.trim()
    : '';
  const identityBoundRead = expectedSessionId !== '' || expectedAgentId !== '';
  if (identityBoundRead && transcriptMetadata?.agentId
    && (!expectedAgentId || transcriptMetadata.agentId !== expectedAgentId)) {
    return null;
  }
  if (expectedAgentId && transcriptMetadata?.transcriptId !== expectedAgentId) {
    return null;
  }
  const lines = tail.split('\n').filter(Boolean);
  let usage = null;
  let approvalContext = null;
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try {
      const record = JSON.parse(lines[index]);
      if (!usage) {
        usage = usageFromTokenCount(record);
      }
      if (!approvalContext) {
        approvalContext = approvalContextFromTurnContext(record, options);
      }
      if (usage && approvalContext) {
        break;
      }
    } catch {
      // Ignore truncated or provider-specific records and continue backwards.
    }
  }
  if (!approvalContext && options.deepApprovalScan === true) {
    try {
      approvalContext = findRecordBackwards(
        allowed,
        (record) => approvalContextFromTurnContext(record, options)
      );
    } catch {
      approvalContext = null;
    }
  }
  if (!usage && !approvalContext) {
    return null;
  }
  return {
    ...(transcriptMetadata?.sessionId ? { sessionId: transcriptMetadata.sessionId } : {}),
    ...(transcriptMetadata?.agentId ? { agentId: transcriptMetadata.agentId } : {}),
    ...(transcriptMetadata?.parentThreadId
      ? { parentThreadId: transcriptMetadata.parentThreadId }
      : {}),
    transcriptPath: allowed,
    ...(usage || {}),
    ...(approvalContext ? { approvalContext } : {})
  };
}

function readCodexTranscriptUsage(filePath, options = {}) {
  const snapshot = readCodexTranscriptSnapshot(filePath, options);
  if (!snapshot?.usage) {
    return null;
  }
  return {
    capturedAt: snapshot.capturedAt,
    usage: snapshot.usage,
    tokenUsage: snapshot.tokenUsage
  };
}

module.exports = {
  allowedTranscriptPath,
  approvalContextFromTurnContext,
  readCodexTranscriptSnapshot,
  readCodexTranscriptUsage,
  sessionMetadataFromSessionMeta,
  usageFromTokenCount
};
