const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { unresolvedManualPermissionRequests } = require('./hostSessionMetadata');

function eventsDir(dataDir) {
  return path.join(dataDir, 'events');
}

function cursorsDir(dataDir) {
  return path.join(dataDir, 'cursors');
}

function sessionFilePath(dataDir, sessionId) {
  return path.join(eventsDir(dataDir), `${encodeURIComponent(sessionId)}.jsonl`);
}

function sessionCursorFilePath(dataDir, sessionId) {
  return path.join(cursorsDir(dataDir), `${encodeURIComponent(sessionId)}.json`);
}

function normalizeSessionId(sessionId) {
  const normalized = typeof sessionId === 'string' ? sessionId.trim() : '';
  return normalized || 'unknown-session';
}

function resolveCursorMaxAgeMs(maxAgeSeconds) {
  if (!Number.isFinite(maxAgeSeconds)) {
    return null;
  }
  const seconds = Math.floor(maxAgeSeconds);
  if (seconds <= 0) {
    return null;
  }
  return seconds * 1000;
}

function maybeExpireSessionCursor(dataDir, sessionId, cursorState, options = {}) {
  const maxAgeMs = resolveCursorMaxAgeMs(options.maxAgeSeconds);
  if (maxAgeMs === null) {
    return cursorState;
  }
  if (!cursorState || typeof cursorState !== 'object') {
    return cursorState;
  }
  if (typeof cursorState.cursor !== 'string' || cursorState.cursor.trim() === '') {
    return cursorState;
  }
  const updatedTimestamp = Number.isFinite(cursorState.updated_timestamp)
    ? Math.trunc(cursorState.updated_timestamp)
    : null;
  if (updatedTimestamp === null) {
    return cursorState;
  }
  const nowTimestampMs = Number.isFinite(options.nowTimestampMs)
    ? Math.trunc(options.nowTimestampMs)
    : Date.now();
  if ((nowTimestampMs - updatedTimestamp) <= maxAgeMs) {
    return cursorState;
  }

  const normalizedSessionId = normalizeSessionId(sessionId);
  const filePath = sessionCursorFilePath(dataDir, normalizedSessionId);
  if (fs.existsSync(filePath)) {
    fs.rmSync(filePath, { force: true });
  }
  return {
    session_id: normalizedSessionId,
    cursor: null,
    updated_at: null,
    updated_timestamp: null
  };
}

function loadSessionCursor(dataDir, sessionId, options = {}) {
  const normalizedSessionId = normalizeSessionId(sessionId);
  const filePath = sessionCursorFilePath(dataDir, normalizedSessionId);
  if (!fs.existsSync(filePath)) {
    return {
      session_id: normalizedSessionId,
      cursor: null,
      updated_at: null,
      updated_timestamp: null
    };
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    const cursor = typeof parsed?.cursor === 'string' && parsed.cursor.trim() !== ''
      ? parsed.cursor.trim()
      : null;
    const updatedAt = typeof parsed?.updated_at === 'string' ? parsed.updated_at : null;
    const updatedTimestamp = Number.isFinite(parsed?.updated_timestamp)
      ? Math.trunc(parsed.updated_timestamp)
      : null;
    const state = {
      session_id: normalizedSessionId,
      cursor,
      updated_at: updatedAt,
      updated_timestamp: updatedTimestamp
    };
    return maybeExpireSessionCursor(dataDir, normalizedSessionId, state, options);
  } catch {
    return {
      session_id: normalizedSessionId,
      cursor: null,
      updated_at: null,
      updated_timestamp: null
    };
  }
}

function purgeExpiredSessionCursors(dataDir, options = {}) {
  const dirPath = cursorsDir(dataDir);
  if (!fs.existsSync(dirPath)) {
    return {
      removed_count: 0,
      removed_sessions: []
    };
  }
  const entries = fs.readdirSync(dirPath).filter((entry) => entry.endsWith('.json'));
  const removedSessions = [];
  for (const entry of entries) {
    let rawSessionId = entry.slice(0, -5);
    try {
      rawSessionId = decodeURIComponent(rawSessionId);
    } catch {
      // keep raw encoded value
    }
    const sessionId = normalizeSessionId(rawSessionId);
    const filePath = sessionCursorFilePath(dataDir, sessionId);
    const existedBefore = fs.existsSync(filePath);
    loadSessionCursor(dataDir, sessionId, options);
    const existsAfter = fs.existsSync(filePath);
    if (existedBefore && !existsAfter) {
      removedSessions.push(sessionId);
    }
  }
  return {
    removed_count: removedSessions.length,
    removed_sessions: removedSessions
  };
}

function saveSessionCursor(dataDir, sessionId, cursor) {
  const normalizedSessionId = normalizeSessionId(sessionId);
  const normalizedCursor = typeof cursor === 'string' ? cursor.trim() : '';
  const filePath = sessionCursorFilePath(dataDir, normalizedSessionId);

  if (!normalizedCursor) {
    if (fs.existsSync(filePath)) {
      fs.rmSync(filePath, { force: true });
    }
    return {
      session_id: normalizedSessionId,
      cursor: null,
      updated_at: null,
      updated_timestamp: null
    };
  }

  const previousState = loadSessionCursor(dataDir, normalizedSessionId);
  const previousTimestamp = Number.isFinite(previousState?.updated_timestamp)
    ? Math.trunc(previousState.updated_timestamp)
    : null;
  const wallClockTimestamp = Date.now();
  const nowTimestamp = previousTimestamp !== null && wallClockTimestamp <= previousTimestamp
    ? previousTimestamp + 1
    : wallClockTimestamp;
  const updatedAt = new Date(nowTimestamp).toISOString();
  const payload = {
    session_id: normalizedSessionId,
    cursor: normalizedCursor,
    updated_at: updatedAt,
    updated_timestamp: nowTimestamp
  };
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
  fs.renameSync(tempPath, filePath);
  return payload;
}

function deleteSession(dataDir, sessionId) {
  const normalizedSessionId = normalizeSessionId(sessionId);
  const targets = [
    sessionFilePath(dataDir, normalizedSessionId),
    sessionCursorFilePath(dataDir, normalizedSessionId)
  ];
  let deleted = false;
  for (const target of targets) {
    if (!fs.existsSync(target)) {
      continue;
    }
    fs.rmSync(target, { force: true });
    deleted = true;
  }
  return {
    session_id: normalizedSessionId,
    deleted
  };
}

function appendSessionEvent(dataDir, event) {
  const dir = eventsDir(dataDir);
  fs.mkdirSync(dir, { recursive: true });
  const normalizedSessionId = normalizeSessionId(event?.session_id);
  const filePath = sessionFilePath(dataDir, normalizedSessionId);
  const storedEvent = {
    ...event,
    session_id: normalizedSessionId
  };
  fs.appendFileSync(filePath, `${JSON.stringify(storedEvent)}\n`, 'utf8');
}

function parseSessionEvents(dataDir, sessionId) {
  const filePath = sessionFilePath(dataDir, sessionId);
  if (!fs.existsSync(filePath)) {
    return [];
  }

  const content = fs.readFileSync(filePath, 'utf8');
  return content
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter((value) => value !== null);
}

function listSessionEvents(dataDir, sessionId, options = {}) {
  return listSessionEventsWithCursor(dataDir, sessionId, options).events;
}

function listSessionIds(dataDir) {
  const dir = eventsDir(dataDir);
  if (!fs.existsSync(dir)) {
    return [];
  }

  return fs.readdirSync(dir)
    .filter((name) => name.endsWith('.jsonl'))
    .map((name) => name.slice(0, -'.jsonl'.length))
    .map((name) => {
      try {
        return decodeURIComponent(name);
      } catch {
        return name;
      }
    })
    .filter((sessionId) => sessionId.trim() !== '')
    .sort();
}

function boundedSessionEvents(events, limit = 1000, pendingLimit = 128) {
  const rows = Array.isArray(events) ? events : [];
  const normalizedLimit = Number.isFinite(limit) ? Math.max(1, Math.floor(limit)) : 1000;
  const normalizedPendingLimit = Number.isFinite(pendingLimit)
    ? Math.max(0, Math.floor(pendingLimit))
    : 128;
  if (rows.length <= normalizedLimit) {
    return rows;
  }
  const unresolvedPendingEvents = unresolvedManualPermissionRequests(rows, {
    requireExplicitManualApproval: true
  });
  const retainedPendingEvents = normalizedPendingLimit === 0
    ? []
    : unresolvedPendingEvents.slice(-normalizedPendingLimit);
  const pendingEvents = new Set(retainedPendingEvents);
  const recentStart = rows.length - normalizedLimit;
  return rows.filter((event, index) => index >= recentStart || pendingEvents.has(event));
}

function listSessionEventsWithCursor(dataDir, sessionId, options = {}) {
  const limit = Number.isFinite(options.limit) ? Math.max(1, Math.floor(options.limit)) : 200;
  const cursor = typeof options.cursor === 'string' && options.cursor.trim() !== ''
    ? options.cursor.trim()
    : null;
  const rows = Array.isArray(options.events)
    ? options.events
    : parseSessionEvents(dataDir, sessionId);
  const cursorIndex = cursor
    ? rows.findIndex((event) => event.id === cursor)
    : -1;
  const resetRequired = Boolean(cursor && cursorIndex < 0);
  // A missing cursor means the client's cache can no longer be advanced
  // safely. Rebase it on the bounded tail; replaying row zero would turn a
  // stale cursor into an unbounded historical replay.
  const isTailReplay = !cursor || resetRequired;
  const startIndex = isTailReplay
    ? Math.max(0, rows.length - limit)
    : cursorIndex + 1;

  const scopedRows = rows.slice(startIndex);
  const hasMore = !isTailReplay && scopedRows.length > limit;
  const pageEvents = hasMore ? scopedRows.slice(0, limit) : scopedRows;
  const pendingRequests = unresolvedManualPermissionRequests(rows, {
    requireExplicitManualApproval: true
  });
  // Pending requests are state, not history. Include their original events in
  // every page so a bounded/tail cache can still render and act on them. Keep
  // next_cursor tied to pageEvents so these descriptors never advance a cursor.
  const includedEvents = new Set([...pageEvents, ...pendingRequests]);
  const events = rows.filter((event) => includedEvents.has(event));
  const nextCursor = pageEvents.length > 0
    ? pageEvents[pageEvents.length - 1].id
    : (resetRequired ? null : cursor);

  return {
    events,
    next_cursor: nextCursor || null,
    has_more: hasMore,
    pending_count: pendingRequests.length,
    reset_required: resetRequired
  };
}

function findPermissionDecisionEvent(dataDir, sessionId, requestEventId) {
  if (typeof requestEventId !== 'string' || requestEventId.trim() === '') {
    return null;
  }

  const events = parseSessionEvents(dataDir, sessionId);
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index];
    if (event.type !== 'permission.decided') {
      continue;
    }
    const existingRequestId = event?.payload?.request_event_id;
    if (existingRequestId === requestEventId) {
      return event;
    }
  }
  return null;
}

function findSessionEventById(dataDir, sessionId, eventId) {
  if (typeof eventId !== 'string' || eventId.trim() === '') {
    return null;
  }
  const lookupId = eventId.trim();
  const events = parseSessionEvents(dataDir, sessionId);
  for (let index = events.length - 1; index >= 0; index -= 1) {
    if (events[index]?.id === lookupId) {
      return events[index];
    }
  }
  return null;
}

function normalizeArtifactString(value) {
  const normalized = typeof value === 'string' ? value.trim() : '';
  return normalized || null;
}

function firstWorkspaceRoot(events, options = {}) {
  const explicit = normalizeArtifactString(options.workspaceRoot);
  if (explicit && path.isAbsolute(explicit)) {
    return path.resolve(explicit);
  }
  for (const event of events) {
    const cwd = normalizeArtifactString(event?.payload?.cwd);
    if (cwd && path.isAbsolute(cwd)) {
      return path.resolve(cwd);
    }
  }
  return null;
}

function resolveSafeArtifactPath(rawPath, workspaceRoot) {
  const normalizedPath = normalizeArtifactString(rawPath);
  if (!normalizedPath || !workspaceRoot) {
    return null;
  }
  const root = path.resolve(workspaceRoot);
  const resolved = path.isAbsolute(normalizedPath)
    ? path.resolve(normalizedPath)
    : path.resolve(root, normalizedPath);
  const relative = path.relative(root, resolved);
  if (relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))) {
    return resolved;
  }
  return null;
}

function artifactMetadata(filePath) {
  try {
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) {
      return {
        exists: false,
        size_bytes: null,
        updated_at: null
      };
    }
    return {
      exists: true,
      size_bytes: stat.size,
      updated_at: stat.mtime.toISOString()
    };
  } catch {
    return {
      exists: false,
      size_bytes: null,
      updated_at: null
    };
  }
}

function artifactId(type, filePath) {
  return createHash('sha256')
    .update(`${type}:${filePath}`)
    .digest('hex')
    .slice(0, 16);
}

function addArtifact(artifacts, seen, {
  type,
  label,
  filePath,
  sourceEventId
}) {
  const key = `${type}:${filePath}`;
  if (seen.has(key)) {
    return;
  }
  seen.add(key);
  const metadata = artifactMetadata(filePath);
  artifacts.push({
    id: artifactId(type, filePath),
    type,
    label,
    path: filePath,
    source_event_id: sourceEventId || null,
    ...metadata
  });
}

function collectArtifactCandidates(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return [];
  }
  const candidates = [];
  const scalarFields = [
    ['transcript_path', 'transcript', 'Transcript'],
    ['session_file', 'transcript', 'Session transcript'],
    ['summary_file', 'summary', 'Summary'],
    ['summary_path', 'summary', 'Summary'],
    ['log_path', 'log', 'Log'],
    ['artifact_path', 'artifact', 'Artifact'],
    ['file_path', 'artifact', 'Artifact'],
    ['output_file', 'artifact', 'Artifact']
  ];

  for (const [field, type, label] of scalarFields) {
    const value = normalizeArtifactString(payload[field]);
    if (value) {
      candidates.push({ path: value, type, label });
    }
  }

  const artifactPaths = Array.isArray(payload.artifact_paths) ? payload.artifact_paths : [];
  for (const value of artifactPaths) {
    const artifactPath = normalizeArtifactString(value);
    if (artifactPath) {
      candidates.push({ path: artifactPath, type: 'artifact', label: 'Artifact' });
    }
  }

  const artifacts = Array.isArray(payload.artifacts) ? payload.artifacts : [];
  for (const artifact of artifacts) {
    if (typeof artifact === 'string') {
      const artifactPath = normalizeArtifactString(artifact);
      if (artifactPath) {
        candidates.push({ path: artifactPath, type: 'artifact', label: 'Artifact' });
      }
      continue;
    }
    if (!artifact || typeof artifact !== 'object' || Array.isArray(artifact)) {
      continue;
    }
    const artifactPath = normalizeArtifactString(artifact.path || artifact.file_path);
    if (!artifactPath) {
      continue;
    }
    const type = normalizeArtifactString(artifact.type) || 'artifact';
    const label = normalizeArtifactString(artifact.label) || 'Artifact';
    candidates.push({ path: artifactPath, type, label });
  }

  return candidates;
}

function listSessionArtifacts(dataDir, sessionId, options = {}) {
  const events = parseSessionEvents(dataDir, sessionId);
  const workspaceRoot = firstWorkspaceRoot(events, options);
  const artifacts = [];
  const seen = new Set();

  for (const event of events) {
    for (const candidate of collectArtifactCandidates(event?.payload)) {
      const filePath = resolveSafeArtifactPath(candidate.path, workspaceRoot);
      if (!filePath) {
        continue;
      }
      addArtifact(artifacts, seen, {
        type: candidate.type,
        label: candidate.label,
        filePath,
        sourceEventId: event?.id
      });
    }
  }

  return artifacts;
}

module.exports = {
  appendSessionEvent,
  boundedSessionEvents,
  deleteSession,
  listSessionIds,
  listSessionEvents,
  listSessionEventsWithCursor,
  listSessionArtifacts,
  findPermissionDecisionEvent,
  findSessionEventById,
  loadSessionCursor,
  saveSessionCursor,
  purgeExpiredSessionCursors
};
