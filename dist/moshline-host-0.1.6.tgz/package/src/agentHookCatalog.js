'use strict';

const SUPPORTED = [
  { id: 'claude', label: 'Claude Code', executable: 'claude', configPath: '~/.claude/settings.json' },
  { id: 'codex', label: 'Codex CLI', executable: 'codex', configPath: '~/.codex/hooks.json' },
  { id: 'opencode', label: 'OpenCode', executable: 'opencode', configPath: '~/.config/opencode/plugins/nomad.js', mode: 'own-file' },
  { id: 'gemini', label: 'Gemini CLI', executable: 'gemini', configPath: '~/.gemini/settings.json' },
  { id: 'cursor', label: 'Cursor Agent', executable: 'cursor-agent', configPath: '~/.cursor/hooks.json' },
  { id: 'kimi', label: 'Kimi Code', executable: 'kimi', configPath: '~/.kimi-code/config.toml', mode: 'managed-toml-block' },
  { id: 'qwen', label: 'Qwen Code', executable: 'qwen', configPath: '~/.qwen/settings.json' }
];
const CLAUDE_PERMISSION_HOOK_TIMEOUT_SECONDS = 120;
const CLAUDE_PERMISSION_DECISION_TIMEOUT_SECONDS = CLAUDE_PERMISSION_HOOK_TIMEOUT_SECONDS - 10;

function getSupportedHookAgents() {
  return SUPPORTED.map((agent) => ({ ...agent }));
}

function shellQuote(value) {
  return '\'' + String(value).replace(/'/g, '\'\\\'\'') + '\'';
}

function buildCommand(agentID, bridgeURL, projectID, eventName = null) {
  const parts = [
    'nomad-hook',
    'emit',
    '--bridge',
    shellQuote(bridgeURL),
    '--agent',
    shellQuote(agentID),
    '--project',
    shellQuote(projectID)
  ];
  if (eventName) {
    parts.push('--event', shellQuote(eventName));
  }
  // Codex treats hook stdout as protocol output. Keep successful delivery
  // silent so a valid event is not reported as a failed hook in the CLI.
  if (agentID === 'codex') {
    parts.push('--quiet');
  }
  return parts.join(' ');
}

function buildCommandHookGroup(command, matcher = '', timeout = null) {
  return {
    matcher,
    hooks: [
      {
        type: 'command',
        command,
        ...(Number.isFinite(timeout) ? { timeout } : {})
      }
    ]
  };
}

function buildClaudeContent(command) {
  const permissionCommand = `${command} --await-decision --decision-timeout '${CLAUDE_PERMISSION_DECISION_TIMEOUT_SECONDS}'`;
  return JSON.stringify({
    hooks: {
      // Notification/Stop drive attention + reply updates. PreToolUse and
      // PostToolUse feed the Chat View's collapsed tool cards.
      Notification: [buildCommandHookGroup(command)],
      PermissionRequest: [buildCommandHookGroup(permissionCommand, '', CLAUDE_PERMISSION_HOOK_TIMEOUT_SECONDS)],
      SessionEnd: [buildCommandHookGroup(command)],
      Stop: [buildCommandHookGroup(command)],
      PreToolUse: [buildCommandHookGroup(command)],
      PostToolUse: [buildCommandHookGroup(command)]
    }
  }, null, 2);
}

function buildCodexContent(command) {
  const events = [
    'SessionStart',
    'UserPromptSubmit',
    'PreToolUse',
    'PostToolUse',
    'PermissionRequest',
    'SessionEnd',
    'Stop'
  ];
  return JSON.stringify({
    hooks: Object.fromEntries(events.map((eventName) => [
      eventName,
      [buildCommandHookGroup(command)]
    ]))
  }, null, 2);
}

function buildGeminiCommandHookGroup(command, matcher = '') {
  return {
    matcher,
    hooks: [
      {
        name: 'nomad-hook',
        type: 'command',
        command,
        timeout: 10000
      }
    ]
  };
}

function buildGeminiContent(command) {
  return JSON.stringify({
    hooks: {
      Notification: [buildGeminiCommandHookGroup(command)],
      AfterTool: [buildGeminiCommandHookGroup(command)]
    }
  }, null, 2);
}

function buildOpenCodePluginContent(bridgeURL, projectID) {
  return [
    'export const NomadPlugin = async ({ $ }) => {',
    `  const bridgeURL = ${JSON.stringify(bridgeURL)};`,
    `  const projectID = ${JSON.stringify(projectID)};`,
    '  const ignoredEventTypes = new Set(["message.part.delta"]);',
    '',
    '  return {',
    '    event: async ({ event }) => {',
    '      if (ignoredEventTypes.has(event.type)) return;',
    '      const eventInput = new Response(JSON.stringify(event));',
    '      await $`nomad-hook emit --bridge ${bridgeURL} --agent opencode --project ${projectID} --event ${event.type} < ${eventInput}`;',
    '    }',
    '  };',
    '};',
    ''
  ].join('\n');
}

function buildCursorContent(bridgeURL, projectID) {
  const events = [
    'sessionStart',
    'beforeSubmitPrompt',
    'preToolUse',
    'postToolUse',
    'stop'
  ];
  return JSON.stringify({
    version: 1,
    hooks: Object.fromEntries(events.map((eventName) => [eventName, [{
      command: buildCommand('cursor', bridgeURL, projectID, eventName)
    }]]))
  }, null, 2);
}

function buildKimiContent(bridgeURL, projectID) {
  const events = [
    'SessionStart',
    'UserPromptSubmit',
    'PreToolUse',
    'PostToolUse',
    'PermissionRequest',
    'Stop'
  ];
  const rules = events.map((eventName) => [
    '[[hooks]]',
    `event = ${JSON.stringify(eventName)}`,
    `command = ${JSON.stringify(buildCommand('kimi', bridgeURL, projectID, eventName))}`,
    'timeout = 10'
  ].join('\n'));
  return [
    '# >>> moshline hook kimi >>>',
    ...rules,
    '# <<< moshline hook kimi <<<',
    ''
  ].join('\n');
}

function buildQwenContent(bridgeURL, projectID) {
  const events = [
    'SessionStart',
    'UserPromptSubmit',
    'PreToolUse',
    'PostToolUse',
    'PermissionRequest',
    'Stop'
  ];
  return JSON.stringify({
    hooks: Object.fromEntries(events.map((eventName) => [eventName, [
      {
        matcher: '',
        hooks: [{
          name: 'moshline',
          type: 'command',
          command: buildCommand('qwen', bridgeURL, projectID, eventName)
        }]
      }
    ]]))
  }, null, 2);
}

function buildFileContent(agentID, command, bridgeURL, projectID) {
  if (agentID === 'claude') {
    return buildClaudeContent(command);
  }
  if (agentID === 'codex') {
    return buildCodexContent(command);
  }
  if (agentID === 'gemini') {
    return buildGeminiContent(command);
  }
  if (agentID === 'opencode') {
    return buildOpenCodePluginContent(bridgeURL, projectID);
  }
  if (agentID === 'cursor') {
    return buildCursorContent(bridgeURL, projectID);
  }
  if (agentID === 'kimi') {
    return buildKimiContent(bridgeURL, projectID);
  }
  if (agentID === 'qwen') {
    return buildQwenContent(bridgeURL, projectID);
  }
  throw new Error(`unsupported agent: ${agentID}`);
}

function buildHookInstallPlan(agentID, { bridgeURL, projectID = 'default' } = {}) {
  const agent = SUPPORTED.find((candidate) => candidate.id === agentID);
  if (!agent) {
    throw new Error(`unsupported agent: ${agentID}`);
  }
  if (typeof bridgeURL !== 'string' || bridgeURL.trim() === '') {
    throw new Error('bridgeURL is required');
  }

  const command = buildCommand(agent.id, bridgeURL, projectID);

  return {
    agent: agent.id,
    label: agent.label,
    managedBy: 'nomad',
    files: [
      {
        path: agent.configPath,
        mode: agent.mode || 'merge-json',
        content: buildFileContent(agent.id, command, bridgeURL, projectID)
      }
    ]
  };
}

module.exports = {
  CLAUDE_PERMISSION_DECISION_TIMEOUT_SECONDS,
  CLAUDE_PERMISSION_HOOK_TIMEOUT_SECONDS,
  getSupportedHookAgents,
  buildHookInstallPlan
};
