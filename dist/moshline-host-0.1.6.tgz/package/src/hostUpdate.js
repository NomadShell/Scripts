const { createHash } = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const DEFAULT_UPDATE_MANIFEST_URL =
  'https://raw.githubusercontent.com/NomadShell/Scripts/main/dist/latest.json';
const UPDATE_MANIFEST_SCHEMA_VERSION = 1;
const BRIDGE_PROTOCOL_VERSION = 1;
const UPDATE_INTERVAL_MS = 6 * 60 * 60 * 1000;
const UPDATE_INITIAL_DELAY_MIN_MS = 60 * 1000;
const UPDATE_INITIAL_DELAY_JITTER_MS = 4 * 60 * 1000;
const UPDATE_LOCK_STALE_MS = 2 * 60 * 60 * 1000;
const MAX_MANIFEST_BYTES = 64 * 1024;
const MAX_PACKAGE_BYTES = 128 * 1024 * 1024;

function parseSemanticVersion(value) {
  const match = /^(?:v)?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(
    typeof value === 'string' ? value.trim() : ''
  );
  if (!match) {
    throw new Error(`invalid semantic version: ${value}`);
  }
  return match.slice(1).map((part) => Number.parseInt(part, 10));
}

function compareSemanticVersions(left, right) {
  const leftParts = parseSemanticVersion(left);
  const rightParts = parseSemanticVersion(right);
  for (let index = 0; index < leftParts.length; index += 1) {
    if (leftParts[index] !== rightParts[index]) {
      return leftParts[index] < rightParts[index] ? -1 : 1;
    }
  }
  return 0;
}

function safeHttpsURL(value, label) {
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    throw new Error(`${label} must be an absolute HTTPS URL`);
  }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password) {
    throw new Error(`${label} must be an absolute HTTPS URL without credentials`);
  }
  return parsed;
}

function validateUpdateManifest(value, {
  manifestURL = DEFAULT_UPDATE_MANIFEST_URL,
  protocolVersion = BRIDGE_PROTOCOL_VERSION,
  nodeMajor = Number.parseInt(process.versions.node.split('.')[0], 10)
} = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('update manifest must be a JSON object');
  }
  if (value.schema_version !== UPDATE_MANIFEST_SCHEMA_VERSION) {
    throw new Error(`unsupported update manifest schema: ${value.schema_version}`);
  }
  const version = typeof value.version === 'string' ? value.version.trim() : '';
  parseSemanticVersion(version);
  const sha256 = typeof value.sha256 === 'string' ? value.sha256.trim().toLowerCase() : '';
  if (!/^[a-f0-9]{64}$/.test(sha256)) {
    throw new Error('update manifest sha256 must be a 64-character hexadecimal digest');
  }
  const sourceURL = safeHttpsURL(manifestURL, 'update manifest URL');
  const packageURL = safeHttpsURL(value.package_url, 'update package URL');
  const sourceDirectory = sourceURL.pathname.slice(0, sourceURL.pathname.lastIndexOf('/') + 1);
  if (packageURL.origin !== sourceURL.origin || !packageURL.pathname.startsWith(sourceDirectory)) {
    throw new Error('update package URL must share the manifest origin and directory');
  }
  const protocolMin = Number(value.protocol_min);
  const protocolMax = Number(value.protocol_max);
  if (!Number.isInteger(protocolMin) || !Number.isInteger(protocolMax)
    || protocolMin < 1 || protocolMax < protocolMin) {
    throw new Error('update manifest protocol range is invalid');
  }
  if (protocolVersion < protocolMin || protocolVersion > protocolMax) {
    throw new Error(
      `bridge protocol ${protocolVersion} is outside update compatibility range `
      + `${protocolMin}-${protocolMax}`
    );
  }
  const minNodeMajor = Number(value.min_node_major);
  if (!Number.isInteger(minNodeMajor) || minNodeMajor < 18) {
    throw new Error('update manifest min_node_major must be an integer of at least 18');
  }
  if (nodeMajor < minNodeMajor) {
    throw new Error(`update requires Node.js ${minNodeMajor} or newer (found ${nodeMajor})`);
  }
  return {
    schema_version: UPDATE_MANIFEST_SCHEMA_VERSION,
    version,
    package_url: packageURL.toString(),
    sha256,
    protocol_min: protocolMin,
    protocol_max: protocolMax,
    min_node_major: minNodeMajor
  };
}

async function fetchBuffer(url, {
  fetchImpl = fetch,
  maximumBytes,
  timeoutMs = 30_000,
  label
}) {
  let response;
  try {
    response = await fetchImpl(url, {
      headers: { accept: label === 'update manifest' ? 'application/json' : 'application/octet-stream' },
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch (error) {
    throw new Error(`${label} request failed: ${error.message}`);
  }
  if (!response.ok) {
    throw new Error(`${label} request failed (${response.status})`);
  }
  const contentLength = Number(response.headers?.get?.('content-length'));
  if (Number.isFinite(contentLength) && contentLength > maximumBytes) {
    throw new Error(`${label} exceeds ${maximumBytes} bytes`);
  }
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > maximumBytes) {
    throw new Error(`${label} exceeds ${maximumBytes} bytes`);
  }
  return buffer;
}

async function checkForHostUpdate({
  currentVersion,
  manifestURL = DEFAULT_UPDATE_MANIFEST_URL,
  fetchImpl = fetch,
  protocolVersion = BRIDGE_PROTOCOL_VERSION,
  nodeMajor
}) {
  parseSemanticVersion(currentVersion);
  const buffer = await fetchBuffer(manifestURL, {
    fetchImpl,
    maximumBytes: MAX_MANIFEST_BYTES,
    label: 'update manifest'
  });
  let value;
  try {
    value = JSON.parse(buffer.toString('utf8'));
  } catch {
    throw new Error('update manifest is not valid JSON');
  }
  const manifest = validateUpdateManifest(value, {
    manifestURL,
    protocolVersion,
    ...(nodeMajor === undefined ? {} : { nodeMajor })
  });
  return {
    current_version: currentVersion,
    latest_version: manifest.version,
    update_available: compareSemanticVersions(currentVersion, manifest.version) < 0,
    manifest
  };
}

function sha256(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

function commandFailure(command, args, result) {
  const detail = String(result?.stderr || result?.stdout || result?.error?.message || '').trim();
  return new Error(`${command} ${args.join(' ')} failed${detail ? `: ${detail}` : ''}`);
}

function runChecked(command, args, {
  spawnImpl = spawnSync,
  env = process.env,
  timeout = 10 * 60 * 1000
} = {}) {
  const result = spawnImpl(command, args, {
    encoding: 'utf8',
    env,
    shell: false,
    timeout
  });
  if (result?.error || result?.status !== 0) {
    throw commandFailure(command, args, result);
  }
  return result;
}

function npmExecutable(platform = process.platform) {
  return platform === 'win32' ? 'npm.cmd' : 'npm';
}

function assertGlobalInstallWritable({
  packageRoot,
  spawnImpl = spawnSync,
  fsImpl = fs,
  env = process.env
}) {
  const result = runChecked(npmExecutable(), ['root', '--global'], { spawnImpl, env });
  const globalRoot = path.resolve(result.stdout.trim());
  const installedRoot = fsImpl.realpathSync(packageRoot);
  const relative = path.relative(globalRoot, installedRoot);
  if (relative === '' || relative === '..'
    || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) {
    throw new Error('self-update is available only from a globally installed Host Helper');
  }
  try {
    fsImpl.accessSync(globalRoot, fs.constants.W_OK);
    fsImpl.accessSync(installedRoot, fs.constants.W_OK);
  } catch {
    throw new Error(
      'automatic update cannot write the global npm installation; reinstall the Host Helper '
      + 'in a user-writable npm prefix'
    );
  }
}

function prepareRollbackArchive({
  packageRoot,
  temporaryDirectory,
  spawnImpl = spawnSync,
  env = process.env
}) {
  const npm = npmExecutable();
  const result = runChecked(npm, [
    'pack', packageRoot,
    '--pack-destination', temporaryDirectory,
    '--json'
  ], { spawnImpl, env });
  let packed;
  try {
    packed = JSON.parse(result.stdout);
  } catch {
    throw new Error('npm pack returned invalid JSON while preparing rollback');
  }
  const filename = Array.isArray(packed) ? packed[0]?.filename : packed?.filename;
  if (typeof filename !== 'string' || filename.trim() === '') {
    throw new Error('npm pack did not produce a rollback archive');
  }
  return path.join(temporaryDirectory, filename);
}

function installGlobalArchive(archivePath, {
  spawnImpl = spawnSync,
  env = process.env
} = {}) {
  return runChecked(npmExecutable(), [
    'install', '--global', archivePath, '--no-audit', '--no-fund'
  ], { spawnImpl, env });
}

function reconfigureHost({
  cliPath,
  configPath,
  spawnImpl = spawnSync,
  env = process.env
}) {
  return runChecked(process.execPath, [
    cliPath,
    'setup',
    '--config', configPath,
    '--no-qr',
    '--json'
  ], { spawnImpl, env, timeout: 60_000 });
}

async function waitForHealthyVersion({
  version,
  port,
  fetchImpl = fetch,
  timeoutMs = 30_000,
  sleepImpl = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds))
}) {
  const deadline = Date.now() + timeoutMs;
  let lastError = 'host daemon did not answer';
  while (Date.now() < deadline) {
    try {
      const response = await fetchImpl(`http://127.0.0.1:${port}/health`, {
        signal: AbortSignal.timeout(2000)
      });
      const body = await response.json();
      if (response.ok && body.ok === true && body.bridge_version === version) {
        return body;
      }
      lastError = `host daemon reported version ${body.bridge_version || 'unknown'}`;
    } catch (error) {
      lastError = error.message;
    }
    await sleepImpl(500);
  }
  throw new Error(`host daemon did not become healthy on ${version}: ${lastError}`);
}

function acquireUpdateLock(lockPath, {
  fsImpl = fs,
  now = Date.now()
} = {}) {
  fsImpl.mkdirSync(path.dirname(lockPath), { recursive: true, mode: 0o700 });
  try {
    const stat = fsImpl.statSync(lockPath);
    if (now - stat.mtimeMs > UPDATE_LOCK_STALE_MS) {
      fsImpl.unlinkSync(lockPath);
    }
  } catch (error) {
    if (error.code !== 'ENOENT') {
      throw error;
    }
  }
  let descriptor;
  try {
    descriptor = fsImpl.openSync(lockPath, 'wx', 0o600);
    fsImpl.writeFileSync(descriptor, `${JSON.stringify({ pid: process.pid, started_at: now })}\n`);
  } catch (error) {
    if (error.code === 'EEXIST') {
      throw new Error('another bridge update is already running');
    }
    throw error;
  } finally {
    if (descriptor !== undefined) {
      fsImpl.closeSync(descriptor);
    }
  }
  return () => {
    try {
      fsImpl.unlinkSync(lockPath);
    } catch (error) {
      if (error.code !== 'ENOENT') {
        throw error;
      }
    }
  };
}

async function applyHostUpdate({
  currentVersion,
  config,
  configPath,
  manifestURL = DEFAULT_UPDATE_MANIFEST_URL,
  packageRoot = path.join(__dirname, '..'),
  cliPath = path.join(__dirname, '..', 'bin', 'moshline-host.js'),
  fetchImpl = fetch,
  fsImpl = fs,
  env = process.env,
  preflightImpl = assertGlobalInstallWritable,
  prepareRollbackImpl = prepareRollbackArchive,
  installArchiveImpl = installGlobalArchive,
  reconfigureImpl = reconfigureHost,
  waitForVersionImpl = waitForHealthyVersion
}) {
  if (!config || !Number.isInteger(Number(config.bridge_port))) {
    throw new Error('host config must include bridge_port before updating');
  }
  const stateDirectory = typeof config.data_dir === 'string' && config.data_dir.trim() !== ''
    ? config.data_dir
    : path.join(os.homedir(), '.local', 'share', 'moshline');
  const updateDirectory = path.join(stateDirectory, 'updates');
  const releaseLock = acquireUpdateLock(path.join(updateDirectory, 'update.lock'), { fsImpl });
  let temporaryDirectory;
  try {
    const check = await checkForHostUpdate({
      currentVersion,
      manifestURL,
      fetchImpl
    });
    if (!check.update_available) {
      return { ...check, updated: false, rolled_back: false };
    }
    await preflightImpl({ packageRoot, fsImpl, env });

    fsImpl.mkdirSync(updateDirectory, { recursive: true, mode: 0o700 });
    temporaryDirectory = fsImpl.mkdtempSync(path.join(updateDirectory, 'apply-'));
    const archive = await fetchBuffer(check.manifest.package_url, {
      fetchImpl,
      maximumBytes: MAX_PACKAGE_BYTES,
      timeoutMs: 2 * 60 * 1000,
      label: 'update package'
    });
    const actualDigest = sha256(archive);
    if (actualDigest !== check.manifest.sha256) {
      throw new Error(
        `update package checksum mismatch (expected ${check.manifest.sha256}, found ${actualDigest})`
      );
    }
    const archivePath = path.join(
      temporaryDirectory,
      `moshline-host-${check.manifest.version}.tgz`
    );
    fsImpl.writeFileSync(archivePath, archive, { mode: 0o600 });
    const rollbackPath = await prepareRollbackImpl({
      packageRoot,
      temporaryDirectory,
      env
    });

    try {
      await installArchiveImpl(archivePath, { env });
      await reconfigureImpl({ cliPath, configPath, env });
      await waitForVersionImpl({
        version: check.manifest.version,
        port: Number(config.bridge_port),
        fetchImpl
      });
    } catch (updateError) {
      try {
        await installArchiveImpl(rollbackPath, { env });
        await reconfigureImpl({ cliPath, configPath, env });
        await waitForVersionImpl({
          version: currentVersion,
          port: Number(config.bridge_port),
          fetchImpl
        });
      } catch (rollbackError) {
        throw new Error(
          `bridge update failed (${updateError.message}); rollback also failed (${rollbackError.message})`
        );
      }
      throw new Error(`bridge update failed and was rolled back: ${updateError.message}`);
    }
    return { ...check, updated: true, rolled_back: false };
  } finally {
    if (temporaryDirectory) {
      fsImpl.rmSync(temporaryDirectory, { recursive: true, force: true });
    }
    releaseLock();
  }
}

function startHostUpdateScheduler({
  configPath,
  cliPath,
  dataDirectory,
  platform = process.platform,
  env = process.env,
  spawnImpl = spawn,
  randomImpl = Math.random,
  setTimeoutImpl = setTimeout,
  clearTimeoutImpl = clearTimeout
}) {
  if (env.MOSHLINE_DISABLE_AUTO_UPDATE === '1') {
    return { stop() {} };
  }
  const logPath = path.join(dataDirectory, 'update.log');
  let stopped = false;
  let timer;

  function schedule(delay) {
    timer = setTimeoutImpl(run, delay);
    timer.unref?.();
  }

  function run() {
    if (stopped) {
      return;
    }
    try {
      fs.mkdirSync(path.dirname(logPath), { recursive: true, mode: 0o700 });
      const logDescriptor = fs.openSync(logPath, 'a', 0o600);
      try {
        const updateArguments = [
          cliPath,
          'update',
          '--apply',
          '--background',
          '--config', configPath
        ];
        let command = process.execPath;
        let commandArguments = updateArguments;
        let detached = true;
        if (platform === 'linux') {
          const forwardedEnvironment = [
            'HOME',
            'PATH',
            'NPM_CONFIG_PREFIX',
            'HTTPS_PROXY',
            'HTTP_PROXY',
            'NO_PROXY',
            'MOSHLINE_UPDATE_MANIFEST_URL'
          ].filter((name) => typeof env[name] === 'string' && env[name] !== '')
            .map((name) => `--setenv=${name}=${env[name]}`);
          command = 'systemd-run';
          commandArguments = [
            '--user',
            '--unit=moshline-host-update',
            '--collect',
            '--quiet',
            '--setenv=MOSHLINE_DISABLE_AUTO_UPDATE=1',
            ...forwardedEnvironment,
            process.execPath,
            ...updateArguments
          ];
          detached = false;
        }
        const child = spawnImpl(command, commandArguments, {
          detached,
          env: { ...env, MOSHLINE_DISABLE_AUTO_UPDATE: '1' },
          stdio: ['ignore', logDescriptor, logDescriptor]
        });
        child.unref?.();
      } finally {
        fs.closeSync(logDescriptor);
      }
    } catch (error) {
      try {
        fs.appendFileSync(
          logPath,
          `${new Date().toISOString()} update launch failed: ${error.message}\n`,
          { mode: 0o600 }
        );
      } catch {
        // Auto-update failures must never take down the active host daemon.
      }
    }
    schedule(UPDATE_INTERVAL_MS);
  }

  schedule(
    UPDATE_INITIAL_DELAY_MIN_MS
      + Math.floor(Math.max(0, Math.min(1, randomImpl())) * UPDATE_INITIAL_DELAY_JITTER_MS)
  );
  return {
    stop() {
      stopped = true;
      if (timer !== undefined) {
        clearTimeoutImpl(timer);
      }
    }
  };
}

module.exports = {
  BRIDGE_PROTOCOL_VERSION,
  DEFAULT_UPDATE_MANIFEST_URL,
  UPDATE_INTERVAL_MS,
  applyHostUpdate,
  assertGlobalInstallWritable,
  checkForHostUpdate,
  compareSemanticVersions,
  parseSemanticVersion,
  sha256,
  startHostUpdateScheduler,
  validateUpdateManifest,
  waitForHealthyVersion
};
