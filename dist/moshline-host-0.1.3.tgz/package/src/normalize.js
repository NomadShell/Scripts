const { randomUUID } = require('node:crypto');

const EVENT_TYPE_MAP = {
  session_start: 'session.started',
  session_update: 'session.updated',
  session_end: 'session.ended',
  task_start: 'task.started',
  task_step: 'task.step',
  task_complete: 'task.completed',
  task_failed: 'task.failed',
  task_abort: 'task.aborted',
  tool_use: 'tool.call',
  tool_result: 'tool.result',
  permission_request: 'permission.requested',
  permission_decision: 'permission.decided',
  summary: 'summary.updated',
  error: 'system.error',
  'session.started': 'session.started',
  'session.updated': 'session.updated',
  'session.ended': 'session.ended',
  'task.started': 'task.started',
  'task.step': 'task.step',
  'task.completed': 'task.completed',
  'task.failed': 'task.failed',
  'task.aborted': 'task.aborted',
  'tool.call': 'tool.call',
  'tool.result': 'tool.result',
  'permission.requested': 'permission.requested',
  'permission.decided': 'permission.decided',
  'summary.updated': 'summary.updated',
  'system.error': 'system.error',
  // Native provider hook event names (Claude Code, Codex, Gemini) so events
  // emitted through `nomad-hook emit` land on the correct canonical type
  // instead of the generic `task.step` fallback. Only unambiguous lifecycle
  // hooks are mapped here.
  //
  // Deliberately NOT mapped: Claude's `Notification` hook, which fires for both
  // permission prompts AND idle attention. Mapping it to `permission.requested`
  // would fabricate approval cards for non-approval notifications, so it stays
  // on the neutral default. Real approvals arrive as explicit
  // `permission_request`/`permission.requested` events.
  PreToolUse: 'tool.call',
  PostToolUse: 'tool.result',
  SessionStart: 'session.started',
  UserPromptSubmit: 'task.started',
  Stop: 'task.step',
  TaskCompleted: 'task.step',
  SubagentStop: 'task.step',
  AfterTool: 'tool.result',
  BeforeTool: 'tool.call',
  PermissionRequest: 'permission.requested',
  preToolUse: 'tool.call',
  postToolUse: 'tool.result',
  sessionStart: 'session.started',
  beforeSubmitPrompt: 'task.started',
  stop: 'task.step'
};

const ALLOWED_RISK_LEVELS = new Set(['none', 'low', 'medium', 'high', 'critical']);
const ALLOWED_PERMISSION_DECISIONS = new Set(['approved', 'denied']);
const BYPASS_PERMISSION_SOURCES = new Set(['codex', 'claude']);

function isBypassPermissionsMode(source, payload) {
  const normalizedSource = typeof source === 'string' ? source.trim().toLowerCase() : '';
  if (!BYPASS_PERMISSION_SOURCES.has(normalizedSource)) {
    return false;
  }
  const rawMode = typeof payload?.permission_mode === 'string'
    ? payload.permission_mode
    : '';
  const normalizedMode = rawMode.trim().toLowerCase().replace(/[._\s-]/g, '');
  return normalizedMode === 'bypasspermissions';
}

function isUserInputPermissionRequest(payload) {
  const rawToolName = typeof payload?.tool_name === 'string'
    ? payload.tool_name
    : (typeof payload?.tool === 'string' ? payload.tool : '');
  const normalizedToolName = rawToolName.trim().toLowerCase().replace(/[._\s-]/g, '');
  return normalizedToolName === 'askuserquestion';
}

function normalizeTimestamp(rawTimestamp) {
  if (typeof rawTimestamp === 'number' && Number.isFinite(rawTimestamp)) {
    return Math.floor(rawTimestamp);
  }
  return Math.floor(Date.now() / 1000);
}

function normalizePayload(input) {
  if (input && typeof input.payload === 'object' && !Array.isArray(input.payload)) {
    return input.payload;
  }
  return {};
}

function hasActiveBackgroundWork(payload) {
  const collections = [payload?.background_tasks, payload?.session_crons];
  return collections.some((items) => Array.isArray(items) && items.some((item) => {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      return false;
    }
    const status = typeof item.status === 'string' ? item.status.trim().toLowerCase() : '';
    return ['pending', 'queued', 'running', 'in_progress'].includes(status);
  }));
}

function normalizeEventType(rawType) {
  if (typeof rawType !== 'string' || rawType.trim() === '') {
    return 'task.step';
  }
  return EVENT_TYPE_MAP[rawType] || 'task.step';
}

function normalizeEvent(input, source) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error(`invalid ${source} hook payload`);
  }

  const payload = normalizePayload(input);
  const isTurnFinished = ['Stop', 'stop'].includes(input.event_type);
  const isWorkItemCompleted = input.event_type === 'TaskCompleted';
  const normalizedType = normalizeEventType(input.event_type);
  const normalizedPayload = isTurnFinished
    ? {
        ...payload,
        lifecycle: 'turn.finished',
        ...(hasActiveBackgroundWork(payload) ? { background_work_active: true } : {})
      }
    : (isWorkItemCompleted
      ? { ...payload, lifecycle: 'work_item.completed' }
      : payload);
  const sessionId = typeof input.session_id === 'string' && input.session_id.trim() !== ''
    ? input.session_id
    : 'unknown-session';
  const traceId = typeof input.trace_id === 'string' && input.trace_id.trim() !== ''
    ? input.trace_id
    : randomUUID();
  const riskLevel = typeof input.risk_level === 'string' && ALLOWED_RISK_LEVELS.has(input.risk_level)
    ? input.risk_level
    : 'none';

  return {
    spec_version: 'nomad.event.v1',
    id: randomUUID(),
    session_id: sessionId,
    source,
    type: normalizedType,
    timestamp: normalizeTimestamp(input.timestamp),
    payload: normalizedPayload,
    meta: {
      trace_id: traceId,
      risk_level: riskLevel
    }
  };
}

function normalizeClaudeHookEvent(input) {
  return normalizeEvent(input, 'claude');
}

function normalizeCodexMcpEvent(input) {
  return normalizeEvent(input, 'codex');
}

function normalizeAgentHookEvent(input, source) {
  if (typeof source !== 'string' || !/^[a-z0-9_-]{1,32}$/i.test(source)) {
    throw new Error('invalid agent hook source');
  }
  const event = normalizeEvent(input, source.toLowerCase());
  if (event.type !== 'permission.requested') {
    return event;
  }
  const approvalContext = isUserInputPermissionRequest(event.payload)
    ? 'user_input_required'
    : (isBypassPermissionsMode(event.source, event.payload)
      ? 'bypass_permissions_exception'
      : '');
  return {
    ...event,
    payload: {
      ...event.payload,
      approval_scope: 'host_local',
      requires_manual_approval: true,
      ...(approvalContext ? { approval_context: approvalContext } : {})
    }
  };
}

function isCodexEventMethod(method) {
  if (typeof method !== 'string') {
    return false;
  }
  if (method === 'codex/event') {
    return true;
  }
  return method.endsWith('/codex/event');
}

function toObjectOrNull(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value;
  }
  return null;
}

function normalizeCodexEventCandidate(candidate) {
  const event = toObjectOrNull(candidate);
  if (!event) {
    return null;
  }

  const data = toObjectOrNull(event.data) || {};
  const payload = toObjectOrNull(event.payload) || event;

  return {
    session_id: selectNonEmptyString(
      event.session_id,
      event.sessionId,
      data.session_id,
      data.sessionId
    ),
    event_type: selectNonEmptyString(
      event.event_type,
      event.type,
      data.event_type,
      data.type
    ),
    payload,
    timestamp: event.timestamp || data.timestamp,
    trace_id: selectNonEmptyString(
      event.trace_id,
      event.traceId,
      data.trace_id,
      data.traceId
    ),
    risk_level: selectNonEmptyString(
      event.risk_level,
      event.riskLevel,
      data.risk_level,
      data.riskLevel
    )
  };
}

function extractCodexMcpNotification(parsed) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return null;
  }
  if (!isCodexEventMethod(parsed.method)) {
    return null;
  }

  const params = toObjectOrNull(parsed.params);
  if (!params) {
    return null;
  }

  const msg = toObjectOrNull(params.msg);
  if (msg) {
    return normalizeCodexEventCandidate(msg);
  }
  return normalizeCodexEventCandidate(params);
}

function extractCodexElicitationRequest(parsed) {
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return null;
  }
  if (parsed.method !== 'elicitation/create') {
    return null;
  }
  const params = parsed.params;
  if (!params || typeof params !== 'object' || Array.isArray(params)) {
    return null;
  }

  const rawCommand = Array.isArray(params.codex_command)
    ? params.codex_command.map(String)
    : [];
  const payload = {
    request_id: typeof parsed.id === 'string' || typeof parsed.id === 'number' ? String(parsed.id) : null,
    call_id: selectNonEmptyString(params.codex_call_id, params.codex_mcp_tool_call_id),
    command: rawCommand.length > 0 ? rawCommand.join(' ') : null,
    command_args: rawCommand,
    cwd: selectNonEmptyString(params.codex_cwd),
    message: selectNonEmptyString(params.message),
    raw: params
  };

  return {
    session_id: selectNonEmptyString(params.session_id, params.sessionId),
    event_type: 'permission_request',
    payload,
    trace_id: selectNonEmptyString(params.trace_id, params.traceId),
    risk_level: 'high'
  };
}

function selectNonEmptyString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim() !== '') {
      return value;
    }
  }
  return null;
}

function normalizeCodexCliLine(sessionId, line, stream = 'stdout') {
  if (typeof sessionId !== 'string' || sessionId.trim() === '') {
    throw new Error('invalid session id');
  }

  const text = typeof line === 'string' ? line.trim() : '';
  if (!text) {
    return null;
  }

  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      const elicitation = extractCodexElicitationRequest(parsed);
      if (elicitation) {
        return normalizeCodexMcpEvent({
          session_id: elicitation.session_id || sessionId,
          event_type: elicitation.event_type,
          payload: elicitation.payload,
          trace_id: elicitation.trace_id,
          risk_level: elicitation.risk_level
        });
      }

      const mcpMsg = extractCodexMcpNotification(parsed);
      if (mcpMsg) {
        return normalizeCodexMcpEvent({
          session_id: selectNonEmptyString(mcpMsg.session_id, mcpMsg.sessionId, sessionId),
          event_type: selectNonEmptyString(mcpMsg.event_type, mcpMsg.type),
          payload: typeof mcpMsg.payload === 'object' && mcpMsg.payload !== null ? mcpMsg.payload : mcpMsg,
          timestamp: mcpMsg.timestamp || parsed.timestamp,
          trace_id: selectNonEmptyString(mcpMsg.trace_id, mcpMsg.traceId, parsed.trace_id),
          risk_level: selectNonEmptyString(mcpMsg.risk_level, mcpMsg.riskLevel, parsed.risk_level)
        });
      }

      return normalizeCodexMcpEvent({
        session_id: sessionId,
        event_type: selectNonEmptyString(parsed.event_type, parsed.type),
        payload: typeof parsed.payload === 'object' && parsed.payload !== null ? parsed.payload : parsed,
        timestamp: parsed.timestamp,
        trace_id: selectNonEmptyString(parsed.trace_id, parsed.traceId),
        risk_level: selectNonEmptyString(parsed.risk_level, parsed.riskLevel)
      });
    }
  } catch {
    // fallback to plain text event
  }

  return normalizeCodexMcpEvent({
    session_id: sessionId,
    event_type: 'task_step',
    payload: {
      stream,
      text
    }
  });
}

function buildPermissionDecisionEvent(sessionId, input) {
  if (typeof sessionId !== 'string' || sessionId.trim() === '') {
    throw new Error('invalid session id');
  }
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('invalid permission decision payload');
  }

  const requestEventId = typeof input.request_event_id === 'string' ? input.request_event_id.trim() : '';
  if (!requestEventId) {
    throw new Error('missing request_event_id');
  }

  const decision = typeof input.decision === 'string' ? input.decision.trim() : '';
  if (!ALLOWED_PERMISSION_DECISIONS.has(decision)) {
    throw new Error('invalid decision');
  }

  const traceId = typeof input.trace_id === 'string' && input.trace_id.trim() !== ''
    ? input.trace_id
    : randomUUID();
  const agentRunId = typeof input.agent_run_id === 'string' ? input.agent_run_id.trim() : '';

  return {
    spec_version: 'nomad.event.v1',
    id: randomUUID(),
    session_id: sessionId,
    source: 'nomad-agent',
    type: 'permission.decided',
    timestamp: normalizeTimestamp(input.timestamp),
    payload: {
      request_event_id: requestEventId,
      ...(agentRunId ? { agent_run_id: agentRunId } : {}),
      decision,
      actor: typeof input.actor === 'string' && input.actor.trim() !== '' ? input.actor : 'unknown',
      reason: typeof input.reason === 'string' ? input.reason : ''
    },
    meta: {
      trace_id: traceId,
      risk_level: 'none'
    }
  };
}

module.exports = {
  isBypassPermissionsMode,
  isUserInputPermissionRequest,
  normalizeAgentHookEvent,
  normalizeClaudeHookEvent,
  normalizeCodexMcpEvent,
  normalizeCodexCliLine,
  buildPermissionDecisionEvent
};
