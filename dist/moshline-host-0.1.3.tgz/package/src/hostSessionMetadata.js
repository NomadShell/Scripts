'use strict';

const KNOWN_CAPABILITIES = new Set([
  'activity.read',
  'approval.respond',
  'chat.read',
  'chat.write',
  'usage.read',
  'usage.v2',
  'diff.read',
  'repository.read',
  'preview.read',
  'file.upload',
  'terminal.attach',
  'terminal.persist'
]);

function getEventID(event) {
  return event.event_id || event.id || null;
}

function getTimestamp(event) {
  return event?.timestamp || null;
}

function timestampMilliseconds(value) {
  let numericValue = null;
  if (typeof value === 'number' && Number.isFinite(value)) {
    numericValue = value;
  } else if (typeof value === 'string' && /^-?\d+(?:\.\d+)?$/.test(value.trim())) {
    numericValue = Number(value.trim());
  }
  if (numericValue !== null && Number.isFinite(numericValue)) {
    return Math.abs(numericValue) >= 100_000_000_000
      ? numericValue
      : numericValue * 1000;
  }
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function compareDecoratedEvents(left, right) {
  const leftTimestamp = timestampMilliseconds(getTimestamp(left.event));
  const rightTimestamp = timestampMilliseconds(getTimestamp(right.event));

  if (leftTimestamp !== null && rightTimestamp !== null) {
    const timestampOrder = leftTimestamp - rightTimestamp;
    if (timestampOrder !== 0) {
      return timestampOrder;
    }
  } else if (leftTimestamp !== null) {
    return -1;
  } else if (rightTimestamp !== null) {
    return 1;
  }

  return left.index - right.index;
}

function orderEvents(events) {
  return events
    .map((event, index) => ({ event, index }))
    .sort(compareDecoratedEvents)
    .map(({ event }) => event);
}

function isControlSource(source) {
  if (!source) {
    return true;
  }

  const normalized = source.toLowerCase();
  return normalized.startsWith('nomad')
    || normalized === 'bridge'
    || normalized === 'control-plane'
    || normalized.includes('helper');
}

function getAgentProvider(events) {
  const agentEvent = [...events]
    .reverse()
    .find((event) => event.source && !isControlSource(event.source));

  if (agentEvent) {
    return agentEvent.source;
  }

  const sourcedEvent = [...events].reverse().find((event) => event.source);
  return sourcedEvent ? sourcedEvent.source : 'unknown';
}

function isTurnFinishedEvent(event) {
  if (!event || typeof event !== 'object' || Array.isArray(event)) {
    return false;
  }
  if (event.type === 'task.step' && event.payload?.lifecycle === 'turn.finished') {
    return true;
  }
  const hookEventName = event.payload?.hook_event_name;
  return event.type === 'task.completed'
    && typeof hookEventName === 'string'
    && hookEventName.trim().toLowerCase() === 'stop';
}

function isHostLocalPermissionRequest(event) {
  if (!event || event.type !== 'permission.requested') {
    return false;
  }
  const scope = typeof event.payload?.approval_scope === 'string'
    ? event.payload.approval_scope.trim().toLowerCase()
    : '';
  if (scope === 'host_local') {
    return true;
  }
  const hookEventName = typeof event.payload?.hook_event_name === 'string'
    ? event.payload.hook_event_name.trim().toLowerCase().replace(/[._-]/g, '')
    : '';
  const requestID = typeof event.payload?.request_id === 'string'
    ? event.payload.request_id.trim()
    : '';
  return hookEventName === 'permissionrequest' && !requestID;
}

function normalizedPayloadString(event, keys) {
  for (const key of keys) {
    const value = event?.payload?.[key];
    if (typeof value === 'string' && value.trim() !== '') {
      return value.trim();
    }
  }
  return '';
}

function normalizedToolCommand(event) {
  const toolInput = event?.payload?.tool_input;
  const value = event?.payload?.command
    || (toolInput && typeof toolInput === 'object' && !Array.isArray(toolInput)
      ? (toolInput.command || toolInput.cmd)
      : '');
  return typeof value === 'string'
    ? value.replace(/\r\n/g, '\n').trim()
    : '';
}

function sameExecutionLane(request, candidate, { allowMissingBoundaryIdentity = false } = {}) {
  if (request?.source !== candidate?.source) {
    return false;
  }
  const requestTurn = normalizedPayloadString(request, ['turn_id']);
  const candidateTurn = normalizedPayloadString(candidate, ['turn_id']);
  const requestAgent = normalizedPayloadString(request, ['agent_id']);
  const candidateAgent = normalizedPayloadString(candidate, ['agent_id']);
  if (allowMissingBoundaryIdentity && !candidateTurn && !candidateAgent) {
    return true;
  }
  return requestTurn === candidateTurn && requestAgent === candidateAgent;
}

function toolProgressCorrelationKind(request, candidate) {
  if (!['tool.call', 'tool.result'].includes(candidate?.type)
    || !sameExecutionLane(request, candidate)) {
    return 'none';
  }
  const requestCallID = normalizedPayloadString(request, ['tool_use_id', 'tool_call_id', 'call_id']);
  const candidateCallID = normalizedPayloadString(candidate, ['tool_use_id', 'tool_call_id', 'call_id']);
  if (requestCallID || candidateCallID) {
    return requestCallID && candidateCallID && requestCallID === candidateCallID
      ? 'identifier'
      : 'none';
  }
  const requestCommand = normalizedToolCommand(request);
  const candidateCommand = normalizedToolCommand(candidate);
  if (!requestCommand || requestCommand !== candidateCommand) {
    return 'none';
  }
  const requestTool = normalizedPayloadString(request, ['tool_name', 'tool']);
  const candidateTool = normalizedPayloadString(candidate, ['tool_name', 'tool']);
  return !requestTool || requestTool === candidateTool ? 'fallback' : 'none';
}

function isCorrelatedBoundaryProgress(request, candidate) {
  if (!candidate || request?.source !== candidate.source) {
    return false;
  }
  const wholeTaskBoundary = ['task.completed', 'task.failed', 'task.aborted', 'session.ended']
    .includes(candidate.type) && !isTurnFinishedEvent(candidate);
  if (wholeTaskBoundary) {
    return true;
  }
  const turnBoundary = isTurnFinishedEvent(candidate)
    || (candidate.type === 'task.step' && candidate.payload?.lifecycle === 'work_item.completed');
  return turnBoundary
    && sameExecutionLane(request, candidate, { allowMissingBoundaryIdentity: true });
}

function resolvedPermissionRequestIDs(events) {
  const decisions = events.filter((event) => event.type === 'permission.decided');
  const resolved = new Set();
  let pendingHostLocalRequests = [];

  function resolvePending(requests) {
    const requestIDs = new Set(requests.map(getEventID).filter(Boolean));
    for (const requestID of requestIDs) {
      resolved.add(requestID);
    }
    pendingHostLocalRequests = pendingHostLocalRequests.filter(
      (request) => !requestIDs.has(getEventID(request))
    );
  }

  for (const event of events) {
    if (event.type === 'permission.requested') {
      const requestEventID = getEventID(event);
      const providerRequestID = normalizedPayloadString(event, ['request_id']);
      const explicitlyDecided = decisions.some((decision) => (
        normalizedPayloadString(decision, ['request_event_id']) === requestEventID
          || (providerRequestID
            && normalizedPayloadString(decision, ['request_id']) === providerRequestID)
      ));
      if (explicitlyDecided) {
        if (requestEventID) {
          resolved.add(requestEventID);
        }
      } else if (requestEventID && isHostLocalPermissionRequest(event)) {
        pendingHostLocalRequests.push(event);
      }
      continue;
    }

    if (['tool.call', 'tool.result'].includes(event.type)) {
      const identifierMatches = pendingHostLocalRequests.filter(
        (request) => toolProgressCorrelationKind(request, event) === 'identifier'
      );
      if (identifierMatches.length > 0) {
        resolvePending(identifierMatches);
        continue;
      }
      const fallbackMatches = pendingHostLocalRequests.filter(
        (request) => toolProgressCorrelationKind(request, event) === 'fallback'
      );
      if (fallbackMatches.length === 1) {
        resolvePending(fallbackMatches);
      }
      continue;
    }

    const boundaryMatches = pendingHostLocalRequests.filter(
      (request) => isCorrelatedBoundaryProgress(request, event)
    );
    if (boundaryMatches.length > 0) {
      resolvePending(boundaryMatches);
    }
  }
  return resolved;
}

function isStateEvent(event) {
  return isTurnFinishedEvent(event)
    || event.type === 'session.started'
    || event.type === 'task.started'
    || event.type === 'tool.call'
    || event.type === 'tool.result'
    || event.type === 'tool.started'
    || event.type === 'task.completed'
    || event.type === 'task.failed'
    || event.type === 'system.error';
}

function getStateFromEvent(event) {
  if (!event) {
    return 'idle';
  }

  if (isTurnFinishedEvent(event)) {
    return 'running';
  }

  if (event.type === 'task.completed') {
    return 'completed';
  }

  if (event.type === 'task.failed' || event.type === 'system.error') {
    return 'failed';
  }

  if (event.type === 'tool.call'
    || event.type === 'tool.result'
    || event.type === 'tool.started'
    || event.type === 'task.started'
    || event.type === 'session.started') {
    return 'running';
  }

  return 'idle';
}

function getLastValue(events, key) {
  const event = [...events].reverse().find((candidate) => candidate[key]);
  return event ? event[key] : null;
}

function normalizeTimestampValue(value) {
  const timestamp = timestampMilliseconds(value);
  if (timestamp !== null) {
    return new Date(timestamp).toISOString();
  }
  if (typeof value === 'string' && value.trim() !== '') {
    return value.trim();
  }
  return null;
}

function getPayloadValue(event, keys) {
  if (!event || !event.payload || typeof event.payload !== 'object' || Array.isArray(event.payload)) {
    return null;
  }
  for (const key of keys) {
    const value = event.payload[key];
    if (typeof value === 'string' && value.trim() !== '') {
      return value.trim();
    }
  }
  return null;
}

function getStructuredValue(event, keys) {
  if (!event || typeof event !== 'object' || Array.isArray(event)) {
    return null;
  }
  const containers = [event.payload, event.meta, event];
  for (const container of containers) {
    if (!container || typeof container !== 'object' || Array.isArray(container)) {
      continue;
    }
    for (const key of keys) {
      const value = container[key];
      if (typeof value === 'string' && value.trim() !== '') {
        return value.trim();
      }
    }
  }
  return null;
}

function getLatestStructuredValue(events, keys) {
  for (const event of [...events].reverse()) {
    const value = getStructuredValue(event, keys);
    if (value) {
      return value;
    }
  }
  return null;
}

function getLatestStructuredArray(events, key) {
  for (const event of [...events].reverse()) {
    const containers = [event?.payload, event?.meta, event];
    for (const container of containers) {
      if (!container || typeof container !== 'object' || Array.isArray(container)) {
        continue;
      }
      if (Array.isArray(container[key])) {
        return container[key];
      }
    }
  }
  return [];
}

function getLatestStructuredObject(events, key) {
  for (const event of [...events].reverse()) {
    const containers = [event?.payload, event?.meta, event];
    for (const container of containers) {
      const value = container && typeof container === 'object' && !Array.isArray(container)
        ? container[key]
        : null;
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        return value;
      }
    }
  }
  return null;
}

const USAGE_FRESHNESS_MS = 15 * 60 * 1000;

function nonNegativeNumber(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
    ? value
    : null;
}

function boundedFraction(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1
    ? value
    : null;
}

function normalizeUsagePace(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }
  const status = typeof value.status === 'string' ? value.status.trim().toLowerCase() : '';
  if (!['ahead', 'on_pace', 'behind', 'unknown'].includes(status)) {
    return null;
  }
  const pace = { status };
  const ratio = nonNegativeNumber(value.ratio);
  if (ratio !== null) {
    pace.ratio = ratio;
  }
  return pace;
}

function normalizeUsageWindow(value, fallbackCapturedAt) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }
  const id = typeof value.id === 'string' ? value.id.trim() : '';
  const label = typeof value.label === 'string' ? value.label.trim() : '';
  if (id === '' || label === '' || id.length > 128 || label.length > 128) {
    return null;
  }
  const window = { id, label };
  const numericFields = [
    ['duration_seconds', nonNegativeNumber(value.duration_seconds)],
    ['used', nonNegativeNumber(value.used)],
    ['remaining', nonNegativeNumber(value.remaining)],
    ['limit', nonNegativeNumber(value.limit)],
    ['used_fraction', boundedFraction(value.used_fraction)],
    ['remaining_fraction', boundedFraction(value.remaining_fraction)]
  ];
  for (const [key, normalized] of numericFields) {
    if (normalized !== null) {
      window[key] = normalized;
    }
  }
  const resetsAt = normalizeTimestampValue(value.resets_at);
  const capturedAt = normalizeTimestampValue(value.captured_at) || fallbackCapturedAt;
  if (resetsAt) {
    window.resets_at = resetsAt;
  }
  if (capturedAt) {
    window.captured_at = capturedAt;
  }
  const pace = normalizeUsagePace(value.pace);
  if (pace) {
    window.pace = pace;
  }
  const hasMeasure = window.used_fraction !== undefined
    || window.remaining_fraction !== undefined
    || (window.limit > 0 && (window.used !== undefined || window.remaining !== undefined));
  return hasMeasure ? window : null;
}

function normalizeUsage(value) {
  if (!value) {
    return null;
  }
  const usage = {};
  for (const key of [
    'context_used_tokens',
    'context_limit_tokens',
    'rate_limit_remaining',
    'rate_limit_limit'
  ]) {
    if (typeof value[key] === 'number' && Number.isFinite(value[key]) && value[key] >= 0) {
      usage[key] = value[key];
    }
  }
  const resetsAt = normalizeTimestampValue(value.rate_limit_resets_at);
  if (resetsAt) {
    usage.rate_limit_resets_at = resetsAt;
  }
  const schemaVersion = Number(value.schema_version);
  const capturedAt = normalizeTimestampValue(value.captured_at);
  const windows = Array.isArray(value.windows)
    ? value.windows
      .slice(0, 32)
      .map((window) => normalizeUsageWindow(window, capturedAt))
      .filter(Boolean)
    : [];
  if (schemaVersion >= 2 && windows.length > 0) {
    usage.schema_version = 2;
    for (const key of ['provider', 'account_id', 'account_label']) {
      if (typeof value[key] === 'string' && value[key].trim() !== '') {
        usage[key] = value[key].trim().slice(0, 256);
      }
    }
    if (capturedAt) {
      usage.captured_at = capturedAt;
    }
    usage.windows = windows;
  }
  return Object.keys(usage).length > 0 ? usage : null;
}

function usageIsFresh(usage, now, maxAgeMs = USAGE_FRESHNESS_MS) {
  if (!usage || usage.schema_version !== 2 || !Array.isArray(usage.windows)
    || usage.windows.length === 0) {
    return false;
  }
  const capturedAt = timestampMilliseconds(usage.captured_at);
  return capturedAt !== null && capturedAt <= now && now - capturedAt <= maxAgeMs;
}

function normalizePreview(value) {
  if (!value || !['http', 'https'].includes(value.scheme)) {
    return null;
  }
  const host = typeof value.host === 'string' ? value.host.trim().toLowerCase() : '';
  const port = Number(value.port);
  const previewPath = typeof value.path === 'string' && value.path.startsWith('/')
    ? value.path
    : '/';
  if (!/^[a-z0-9.-]+$/.test(host)
    || !Number.isInteger(port)
    || port < 1
    || port > 65535
    || previewPath.startsWith('//')) {
    return null;
  }
  return { scheme: value.scheme, host, port, path: previewPath };
}

function normalizeCapabilities(values) {
  const capabilities = [];
  const seen = new Set();
  for (const value of values) {
    if (typeof value !== 'string') {
      continue;
    }
    const normalized = value.trim().toLowerCase();
    if (!KNOWN_CAPABILITIES.has(normalized) || seen.has(normalized)) {
      continue;
    }
    seen.add(normalized);
    capabilities.push(normalized);
  }
  return capabilities;
}

function findLatestStructuredEvent(events, keys) {
  return [...events].reverse().find((event) => getStructuredValue(event, keys)) || null;
}

function projectNameFromCwd(cwd) {
  if (!cwd) {
    return null;
  }
  const segments = cwd.replace(/\\/g, '/').split('/').filter(Boolean);
  return segments.length > 0 ? segments[segments.length - 1] : null;
}

function buildTerminalTarget(tmuxSession, tmuxWindow, tmuxPane) {
  if (!tmuxSession) {
    return tmuxPane || null;
  }
  let target = tmuxSession;
  if (tmuxWindow) {
    target += `:${tmuxWindow}`;
  }
  if (tmuxPane) {
    target += `.${tmuxPane}`;
  }
  return target;
}

function buildTerminalRoute(events, surfaceID, multiplexer) {
  const routeEvent = surfaceID
    ? findLatestStructuredEvent(events, [
        'surface_id',
        'moshline_surface_id',
        'harness_surface'
      ])
    : findLatestStructuredEvent(events, [
        'multiplexer_kind',
        'multiplexer_session',
        'multiplexer_pane',
        'tmux_session',
        'tmux_pane'
      ]);
  const observedAt = normalizeTimestampValue(getTimestamp(routeEvent));
  const serverBootID = getStructuredValue(routeEvent, [
    'server_boot_id',
    'daemon_boot_id'
  ]);

  if (surfaceID) {
    return {
      kind: 'persistent_pty',
      confidence: 'observed',
      observed_at: observedAt,
      server_boot_id: serverBootID,
      surface_id: surfaceID,
      multiplexer
    };
  }
  if (multiplexer) {
    return {
      kind: multiplexer.kind,
      confidence: 'observed',
      observed_at: observedAt,
      server_boot_id: serverBootID,
      surface_id: null,
      multiplexer
    };
  }
  return {
    kind: 'unavailable',
    confidence: 'unavailable',
    observed_at: null,
    server_boot_id: null,
    surface_id: null,
    multiplexer: null
  };
}

function normalizeSummaryPreview(value) {
  if (typeof value !== 'string' || value.trim() === '') {
    return '';
  }
  const firstLine = value
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((line) => line.trim())
    .find(Boolean) || '';
  const normalized = firstLine
    .replace(/^#{1,6}\s+/, '')
    .replace(/^[-*]\s+/, '')
    .replace(/\*\*/g, '')
    .replace(/`/g, '')
    .trim();
  const characters = Array.from(normalized);
  return characters.length > 240
    ? `${characters.slice(0, 237).join('')}...`
    : characters.join('');
}

function getToolInputValue(event, keys) {
  const toolInput = event?.payload?.tool_input;
  if (!toolInput || typeof toolInput !== 'object' || Array.isArray(toolInput)) {
    return null;
  }
  for (const key of keys) {
    const value = toolInput[key];
    if (typeof value === 'string' && value.trim() !== '') {
      return value.trim();
    }
  }
  return null;
}

function summarizeEvent(event) {
  if (!event) {
    return 'No events received yet';
  }
  const toolName = getPayloadValue(event, ['tool_name', 'tool']) || 'Tool';
  if (event.type === 'tool.call') {
    return `${toolName} running`;
  }
  if (event.type === 'tool.result') {
    return `${toolName} finished`;
  }
  if (event.type === 'permission.requested') {
    const description = getToolInputValue(event, ['description', 'reason'])
      || getPayloadValue(event, ['description', 'summary', 'message', 'command']);
    if (description) {
      return normalizeSummaryPreview(description);
    }
  }
  if (event.type === 'permission.decided') {
    const decision = getPayloadValue(event, ['decision']);
    if (decision) {
      return `Permission ${decision.toLowerCase()}`;
    }
  }
  const payloadSummary = getPayloadValue(event, [
    'summary',
    'last_assistant_message',
    'message',
    'command',
    'step',
    'text',
    'detail'
  ]);
  if (payloadSummary) {
    return normalizeSummaryPreview(payloadSummary);
  }
  return event.type || 'Agent event received';
}

function projectHostSession(events, { now = Date.now() } = {}) {
  const ordered = orderEvents(events);
  const decidedRequestIDs = resolvedPermissionRequestIDs(ordered);
  const pendingCount = ordered
    .filter((event) => event.type === 'permission.requested')
    .filter((event) => !decidedRequestIDs.has(getEventID(event)))
    .length;

  const latestStateEvent = [...ordered].reverse().find(isStateEvent);
  const latestEvent = ordered.length > 0 ? ordered[ordered.length - 1] : null;
  const latestSummaryEvent = [...ordered].reverse().find((event) => event.type !== 'heartbeat') || latestEvent;
  let state = getStateFromEvent(latestStateEvent);
  if (pendingCount > 0) {
    state = 'waiting';
  }

  const cwd = getLatestStructuredValue(ordered, ['cwd', 'project_path']);
  const sessionID = getLastValue(ordered, 'session_id');
  const eventAgentRunID = getLatestStructuredValue(ordered, ['agent_run_id', 'run_id']);
  const agentRunID = eventAgentRunID || sessionID;
  const agentRunIDSource = eventAgentRunID
    ? 'event'
    : (sessionID ? 'session_fallback' : null);
  const providerSessionID = getLatestStructuredValue(ordered, [
    'provider_session_id',
    'agent_session_id',
    'claude_session_id',
    'codex_session_id'
  ]);
  const surfaceID = getLatestStructuredValue(ordered, [
    'surface_id',
    'moshline_surface_id',
    'harness_surface'
  ]);
  const tmuxSession = getLatestStructuredValue(ordered, [
    'tmux_session',
    'tmux_session_name',
    'multiplexer_session'
  ]);
  const tmuxWindow = getLatestStructuredValue(ordered, [
    'tmux_window',
    'tmux_window_name',
    'multiplexer_window'
  ]);
  const tmuxPane = getLatestStructuredValue(ordered, [
    'tmux_pane',
    'tmux_pane_id',
    'multiplexer_pane'
  ]);
  const explicitMultiplexerKind = getLatestStructuredValue(ordered, ['multiplexer_kind']);
  const multiplexerKind = explicitMultiplexerKind?.toLowerCase()
    || (tmuxSession || tmuxWindow || tmuxPane ? 'tmux' : null);
  const multiplexer = multiplexerKind
    ? {
        kind: multiplexerKind,
        socket: getLatestStructuredValue(ordered, ['multiplexer_socket', 'tmux_socket']),
        server_id: getLatestStructuredValue(ordered, ['multiplexer_server_id', 'tmux_server_id']),
        session: tmuxSession,
        window: tmuxWindow,
        pane: tmuxPane
      }
    : null;
  const terminalTarget = getLatestStructuredValue(ordered, ['terminal_target'])
    || buildTerminalTarget(tmuxSession, tmuxWindow, tmuxPane);
  let capabilities = normalizeCapabilities(getLatestStructuredArray(ordered, 'capabilities'));
  const usage = normalizeUsage(getLatestStructuredObject(ordered, 'usage'));
  if (capabilities.includes('usage.v2') && !usageIsFresh(usage, now)) {
    capabilities = capabilities.filter((capability) => capability !== 'usage.v2');
  }
  const preview = normalizePreview(getLatestStructuredObject(ordered, 'preview'));

  return {
    schema_version: 2,
    session_id: sessionID,
    agent_run_id: agentRunID,
    agent_run_id_source: agentRunIDSource,
    provider_session_id: providerSessionID,
    surface_id: surfaceID,
    provider: getAgentProvider(ordered),
    state,
    pending_count: pendingCount,
    last_event_at: normalizeTimestampValue(getLastValue(ordered, 'timestamp')),
    cwd,
    host_id: getLatestStructuredValue(ordered, ['host_id']),
    host_name: getLatestStructuredValue(ordered, ['host_name', 'hostname', 'host']),
    connection_id: getLatestStructuredValue(ordered, ['connection_id']),
    project_name: getLatestStructuredValue(ordered, ['project_name', 'project']) || projectNameFromCwd(cwd),
    tmux_session: tmuxSession,
    tmux_window: tmuxWindow,
    tmux_pane: tmuxPane,
    terminal_target: terminalTarget,
    capabilities,
    ...(usage ? { usage } : {}),
    ...(preview ? { preview } : {}),
    terminal_route: buildTerminalRoute(ordered, surfaceID, multiplexer),
    summary: summarizeEvent(latestSummaryEvent)
  };
}

module.exports = {
  isHostLocalPermissionRequest,
  isTurnFinishedEvent,
  projectHostSession
};
