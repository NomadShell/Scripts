const http = require('node:http');
const { createHash, createHmac, randomUUID, timingSafeEqual } = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const {
  isBypassPermissionsMode,
  isUserInputPermissionRequest,
  normalizeAgentHookEvent,
  normalizeClaudeHookEvent,
  normalizeCodexMcpEvent,
  buildPermissionDecisionEvent
} = require('./normalize');
const {
  buildClaudeSessionStartHookSettings,
  extractSessionIdFromHookPayload,
  installClaudeSessionStartHook
} = require('./claudeHooks');
const {
  appendSessionEvent,
  boundedSessionEvents,
  deleteSession,
  listSessionIds,
  listSessionEvents,
  listSessionEventsWithCursor,
  listSessionArtifacts,
  findPermissionDecisionEvent,
  findSessionEventById,
  loadSessionCursor,
  saveSessionCursor,
  purgeExpiredSessionCursors
} = require('./store');
const { createCodexSessionRunner } = require('./codexRunner');
const { resolveCodexLaunch, inspectCodexRuntime } = require('./codexCommand');
const { createPiRpcSessionRunner } = require('./piRpcRunner');
const { resolvePiRpcLaunch, inspectPiRuntime } = require('./piRpcCommand');
const { createPolicyEngine } = require('./policy');
const {
  getSupportedHookAgents,
  buildHookInstallPlan
} = require('./agentHookCatalog');
const {
  isHostLocalPermissionRequest,
  isTurnFinishedEvent,
  projectHostSession
} = require('./hostSessionMetadata');
const {
  HOST_SURFACE_CAPABILITIES,
  createHostSurfaceApi
} = require('./hostSurfaceApi');
const { createSurfaceRegistry } = require('./surfaceRegistry');
const { createAttachTicketStore } = require('./attachTicketStore');
const { createHostControlSocket } = require('./hostControlSocket');
const { createBoundedDiffReader } = require('./boundedDiff');
const { createBoundedRepositoryReader } = require('./boundedRepository');
const { createSessionUploadStore } = require('./sessionUploadStore');
const { createNotificationRoutingStore } = require('./notificationRouting');
const { createNotificationDestinationStore } = require('./notificationDestination');
const { createProductMetricStore } = require('./productMetrics');
const { loadNodePty } = require('./nodePtyRuntime');
const { createMultiplexerDiscovery } = require('./multiplexerDiscovery');
const { BoundedCache } = require('./boundedCache');
const {
  allowedTranscriptPath,
  readCodexTranscriptSnapshot
} = require('./codexTranscript');
const packageJson = require('../package.json');

const UNKNOWN_SESSION_ID = 'unknown-session';
const AGENT_RUNTIME_CODEX_CLI = 'codex_cli';
const AGENT_RUNTIME_PI_RPC = 'pi_rpc';
const PROVIDER_NON_MANUAL_APPROVAL_CONTEXTS = new Set([
  'provider_auto_review',
  'provider_full_access'
]);
const CODEX_APPROVAL_CONTEXT_CACHE_LIMIT = 256;

function normalizeAgentRuntime(value, fallback = AGENT_RUNTIME_CODEX_CLI) {
  const normalized = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (normalized === AGENT_RUNTIME_CODEX_CLI || normalized === AGENT_RUNTIME_PI_RPC) {
    return normalized;
  }
  return fallback;
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body)
  });
  res.end(body);
}

function sendText(res, status, contentType, body) {
  const text = typeof body === 'string' ? body : '';
  res.writeHead(status, {
    'content-type': contentType,
    'content-length': Buffer.byteLength(text)
  });
  res.end(text);
}

function isLoopbackAddress(remoteAddress) {
  if (typeof remoteAddress !== 'string' || remoteAddress.trim() === '') {
    return false;
  }
  const normalized = remoteAddress.trim().toLowerCase();
  return normalized === '127.0.0.1'
    || normalized === '::1'
    || normalized === '::ffff:127.0.0.1';
}

// decodeURIComponent throws URIError on malformed percent-encoding. Callers that
// decode a raw path segment must not let that reject the async request handler
// (an unhandled rejection leaves the response hanging and can terminate the
// daemon); return null so the route can answer 400 instead.
function safeDecodeURIComponent(value) {
  if (typeof value !== 'string') {
    return null;
  }
  try {
    return decodeURIComponent(value);
  } catch {
    return null;
  }
}

function readJsonBody(req, options = {}) {
  return new Promise((resolve, reject) => {
    let data = '';
    const maxBytes = Number.isFinite(options.maxBytes) ? options.maxBytes : 1024 * 1024;
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > maxBytes) {
        reject(new Error('payload too large'));
      }
    });
    req.on('end', () => {
      try {
        const parsed = data ? JSON.parse(data) : {};
        if (options.includeRaw === true) {
          resolve({ body: parsed, raw: data });
          return;
        }
        resolve(parsed);
      } catch {
        reject(new Error('invalid json'));
      }
    });
    req.on('error', reject);
  });
}

function readPersistedPolicyConfig(policyPath) {
  if (!policyPath || !fs.existsSync(policyPath)) {
    return {};
  }
  try {
    const raw = fs.readFileSync(policyPath, 'utf8');
    if (!raw.trim()) {
      return {};
    }
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {};
    }
    return parsed;
  } catch {
    return {};
  }
}

function writePersistedPolicyConfig(policyPath, config = {}) {
  const payload = {
    whitelist_commands: Array.isArray(config.whitelist_commands) ? config.whitelist_commands : [],
    enforce_high_risk_reason: config.enforce_high_risk_reason === true,
    security_alert_webhook_min_severity: normalizeSecurityAlertSeverity(
      config.security_alert_webhook_min_severity,
      'high'
    ),
    security_alert_webhook_code_allowlist: normalizeSecurityAlertCodeAllowlist(
      config.security_alert_webhook_code_allowlist
    ),
    security_alert_webhook_routes: normalizeSecurityAlertWebhookRoutes(
      config.security_alert_webhook_routes
    ),
    security_alert_escalation_enabled: config.security_alert_escalation_enabled === true,
    security_alert_escalation_interval_seconds: parseNonNegativeInt(
      config.security_alert_escalation_interval_seconds,
      0
    ),
    security_alert_escalation_ack_deadline_seconds: parseNonNegativeInt(
      config.security_alert_escalation_ack_deadline_seconds,
      900
    ),
    security_alert_escalation_min_severity: normalizeSecurityAlertSeverity(
      config.security_alert_escalation_min_severity,
      'high'
    ),
    security_alert_escalation_code_allowlist: normalizeSecurityAlertCodeAllowlist(
      config.security_alert_escalation_code_allowlist
    ),
    security_alert_escalation_actor: normalizeOptionalString(
      config.security_alert_escalation_actor,
      'nomad-auto'
    ),
    security_alert_escalation_note: typeof config.security_alert_escalation_note === 'string'
      ? config.security_alert_escalation_note.trim()
      : 'SLA breach',
    updated_at: new Date().toISOString()
  };
  fs.mkdirSync(path.dirname(policyPath), { recursive: true });
  const tempPath = `${policyPath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
  fs.renameSync(tempPath, policyPath);
}

function readPersistedKpiAnomalyDispatchConfig(configPath) {
  if (!configPath || !fs.existsSync(configPath)) {
    return {};
  }
  try {
    const raw = fs.readFileSync(configPath, 'utf8');
    if (!raw.trim()) {
      return {};
    }
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {};
    }
    return parsed;
  } catch {
    return {};
  }
}

function writePersistedKpiAnomalyDispatchConfig(configPath, config = {}) {
  if (!configPath) {
    return;
  }
  const payload = {
    enabled: parseBooleanInput(config.enabled, false),
    interval_seconds: parseNonNegativeInt(config.interval_seconds, 0),
    window_seconds: parsePositiveInt(config.window_seconds, 3600),
    baseline_window_seconds: parsePositiveInt(config.baseline_window_seconds, 86400),
    min_severity: normalizeSecurityAlertSeverity(config.min_severity, 'high'),
    code_allowlist: normalizeSecurityAlertCodeAllowlist(config.code_allowlist),
    dedupe_window_seconds: parseNonNegativeInt(config.dedupe_window_seconds, 1800),
    updated_at: new Date().toISOString()
  };
  fs.mkdirSync(path.dirname(configPath), { recursive: true });
  const tempPath = `${configPath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
  fs.renameSync(tempPath, configPath);
}

function parsePositiveInt(value, defaultValue) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return defaultValue;
  }
  return parsed;
}

function parseNonNegativeInt(value, defaultValue) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return defaultValue;
  }
  return parsed;
}

function parseNonNegativeIntInput(value) {
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || !Number.isInteger(value) || value < 0) {
      return null;
    }
    return value;
  }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!/^\d+$/.test(trimmed)) {
      return null;
    }
    const parsed = Number.parseInt(trimmed, 10);
    if (!Number.isFinite(parsed) || parsed < 0) {
      return null;
    }
    return parsed;
  }
  return null;
}

function parsePositiveIntInput(value) {
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || !Number.isInteger(value) || value <= 0) {
      return null;
    }
    return value;
  }
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!/^\d+$/.test(trimmed)) {
      return null;
    }
    const parsed = Number.parseInt(trimmed, 10);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return null;
    }
    return parsed;
  }
  return null;
}

function parseUnitIntervalInput(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  const parsed = Number.parseFloat(String(value).trim());
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1) {
    return null;
  }
  return parsed;
}

function parseBooleanInput(value, defaultValue = false) {
  if (typeof value === 'boolean') {
    return value;
  }
  if (typeof value === 'number') {
    if (value === 1) {
      return true;
    }
    if (value === 0) {
      return false;
    }
    return defaultValue;
  }
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (['1', 'true', 'yes', 'on'].includes(normalized)) {
      return true;
    }
    if (['0', 'false', 'no', 'off'].includes(normalized)) {
      return false;
    }
  }
  return defaultValue;
}

function normalizeOptionalString(value, defaultValue = '') {
  if (typeof value !== 'string') {
    return defaultValue;
  }
  const trimmed = value.trim();
  return trimmed === '' ? defaultValue : trimmed;
}

function notificationProviderLabel(source) {
  const provider = normalizeOptionalString(source, '').toLowerCase();
  if (provider === 'codex') {
    return 'Codex';
  }
  if (provider === 'claude') {
    return 'Claude';
  }
  return 'Agent';
}

function notificationTitle(event) {
  const payload = event?.payload && typeof event.payload === 'object' && !Array.isArray(event.payload)
    ? event.payload
    : {};
  const cwd = normalizeOptionalString(payload.cwd, '');
  const configuredProject = normalizeOptionalString(payload.project_name || payload.project, '');
  const project = configuredProject && configuredProject.toLowerCase() !== 'default'
    ? configuredProject
    : (cwd ? path.basename(cwd) : '');
  const provider = notificationProviderLabel(event?.source);
  return project ? `${project} · ${provider}` : `Moshline · ${provider}`;
}

function notificationPreview(value, fallback) {
  const text = normalizeOptionalString(value, '');
  if (!text) {
    return fallback;
  }
  const firstLine = text
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((line) => line.trim())
    .find(Boolean) || fallback;
  const normalized = firstLine
    .replace(/^#{1,6}\s+/, '')
    .replace(/^[-*]\s+/, '')
    .replace(/\*\*/g, '')
    .replace(/`/g, '')
    .trim();
  const characters = Array.from(normalized || fallback);
  return characters.length > 240
    ? `${characters.slice(0, 237).join('')}...`
    : characters.join('');
}

function firstQuestionText(toolInput) {
  if (!Array.isArray(toolInput?.questions)) {
    return '';
  }
  for (const question of toolInput.questions) {
    const value = typeof question === 'string' ? question : question?.question;
    const normalized = normalizeOptionalString(value, '');
    if (normalized) {
      return normalized;
    }
  }
  return '';
}

function codexAmbientResultKind(value) {
  const text = normalizeOptionalString(value, '');
  if (!text) {
    return '';
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return '';
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return '';
  }
  const keys = Object.keys(parsed);
  if (keys.length !== 1 || !['suggestions', 'exclude'].includes(keys[0])) {
    return '';
  }
  return Array.isArray(parsed[keys[0]]) ? keys[0] : '';
}

function codexAmbientPromptKind(value) {
  const prompt = normalizeOptionalString(value, '');
  if (prompt.includes('Generate 0 to 3 hyperpersonalized suggestions for what this user can do with Codex')) {
    return 'suggestions';
  }
  if (prompt.includes('expert at upholding safety and compliance standards for Codex ambient suggestions')) {
    return 'exclude';
  }
  return '';
}

function isCodexAmbientPrompt(value, resultKind) {
  return codexAmbientPromptKind(value) === resultKind;
}

function isInternalCodexAmbientSession(events) {
  return Array.isArray(events) && events.some((event) => event?.source === 'codex'
    && event.type === 'task.started'
    && event.payload?.transcript_path === null
    && codexAmbientPromptKind(event.payload?.prompt) !== '');
}

const KPI_SESSION_SORT_FIELDS = new Set([
  'total_events',
  'last_timestamp',
  'task_completed',
  'task_failed',
  'approval_decided',
  'approval_pending',
  'system_errors',
  'session_id'
]);

const KPI_SESSION_QUERY_PRESETS = Object.freeze({
  all: {
    sort_by: 'total_events',
    sort_order: 'desc'
  },
  recent: {
    sort_by: 'last_timestamp',
    sort_order: 'desc'
  },
  errors: {
    sort_by: 'system_errors',
    sort_order: 'desc'
  },
  pending: {
    sort_by: 'approval_pending',
    sort_order: 'desc'
  }
});

const KPI_SESSION_PROFILE_PRESET_RAW_VALUES = new Set(['all', 'recent', 'errors', 'pending']);
const KPI_SESSION_PROFILE_SORT_FIELD_RAW_VALUES = new Set([
  'totalEvents',
  'lastTimestamp',
  'taskCompleted',
  'taskFailed',
  'approvalDecided',
  'approvalPending',
  'systemErrors'
]);
const KPI_SESSION_PROFILE_SORT_ORDER_RAW_VALUES = new Set(['asc', 'desc']);
const KPI_SESSION_PROFILE_PAGE_LIMIT_VALUES = new Set([20, 50, 100]);

function normalizeKpiSessionSortBy(value, defaultValue = 'total_events') {
  const normalizedDefault = KPI_SESSION_SORT_FIELDS.has(defaultValue)
    ? defaultValue
    : 'total_events';
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!raw) {
    return normalizedDefault;
  }
  if (KPI_SESSION_SORT_FIELDS.has(raw)) {
    return raw;
  }
  return normalizedDefault;
}

function normalizeKpiSessionSortOrder(value, defaultValue = 'desc') {
  const normalizedDefault = defaultValue === 'asc' ? 'asc' : 'desc';
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (raw === 'asc' || raw === 'desc') {
    return raw;
  }
  return normalizedDefault;
}

function resolveKpiSessionPreset(value) {
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!raw || !Object.prototype.hasOwnProperty.call(KPI_SESSION_QUERY_PRESETS, raw)) {
    return {
      preset_applied: 'all',
      ...KPI_SESSION_QUERY_PRESETS.all
    };
  }
  return {
    preset_applied: raw,
    ...KPI_SESSION_QUERY_PRESETS[raw]
  };
}

const SECURITY_ALERT_SEVERITY_RANK = Object.freeze({
  none: 0,
  low: 1,
  medium: 2,
  high: 3,
  critical: 4
});

function normalizeSecurityAlertSeverity(value, defaultSeverity = 'high') {
  const normalizedDefault = typeof defaultSeverity === 'string' ? defaultSeverity.toLowerCase() : 'high';
  const raw = typeof value === 'string' ? value.trim().toLowerCase() : '';
  if (!raw) {
    return normalizedDefault;
  }
  if (Object.prototype.hasOwnProperty.call(SECURITY_ALERT_SEVERITY_RANK, raw)) {
    return raw;
  }
  return normalizedDefault;
}

function normalizeSecurityAlertCodeAllowlist(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  const normalized = value
    .map((item) => (typeof item === 'string' ? item.trim().toLowerCase() : ''))
    .filter(Boolean);
  return Array.from(new Set(normalized));
}

function normalizeSecurityAlertWebhookRoute(route, index) {
  if (!route || typeof route !== 'object' || Array.isArray(route)) {
    return null;
  }
  const webhookURL = typeof route.webhook_url === 'string'
    ? route.webhook_url.trim()
    : '';
  if (!webhookURL) {
    return null;
  }
  const name = typeof route.name === 'string' && route.name.trim() !== ''
    ? route.name.trim()
    : `route-${index + 1}`;
  const minSeverity = normalizeSecurityAlertSeverity(route.min_severity, 'high');
  const codeAllowlist = normalizeSecurityAlertCodeAllowlist(route.code_allowlist);
  const enabled = typeof route.enabled === 'boolean' ? route.enabled : true;
  return {
    name,
    webhook_url: webhookURL,
    min_severity: minSeverity,
    code_allowlist: codeAllowlist,
    enabled
  };
}

function normalizeSecurityAlertWebhookRoutes(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return value
    .map((route, index) => normalizeSecurityAlertWebhookRoute(route, index))
    .filter(Boolean);
}

function shouldDispatchSecurityAlertWebhook({
  alertSeverity,
  minimumSeverity,
  alertCode,
  codeAllowlist
}) {
  const alertLevel = normalizeSecurityAlertSeverity(alertSeverity, 'high');
  const minLevel = normalizeSecurityAlertSeverity(minimumSeverity, 'high');
  if (SECURITY_ALERT_SEVERITY_RANK[alertLevel] < SECURITY_ALERT_SEVERITY_RANK[minLevel]) {
    return false;
  }

  const normalizedCodeAllowlist = normalizeSecurityAlertCodeAllowlist(codeAllowlist);
  if (normalizedCodeAllowlist.length === 0) {
    return true;
  }
  if (normalizedCodeAllowlist.includes('*')) {
    return true;
  }
  const normalizedCode = typeof alertCode === 'string' ? alertCode.trim().toLowerCase() : '';
  if (!normalizedCode) {
    return false;
  }
  return normalizedCodeAllowlist.includes(normalizedCode);
}

function parseSecurityAlertSeverityInput(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const normalized = value.trim().toLowerCase();
  if (!normalized) {
    return null;
  }
  if (!Object.prototype.hasOwnProperty.call(SECURITY_ALERT_SEVERITY_RANK, normalized)) {
    return null;
  }
  return normalized;
}

function parseSecurityAlertCodeAllowlistInput(value) {
  if (!Array.isArray(value)) {
    return null;
  }
  return normalizeSecurityAlertCodeAllowlist(value);
}

function parseSecurityAlertWebhookRoutesInput(value) {
  if (!Array.isArray(value)) {
    return null;
  }
  const routes = [];
  for (let i = 0; i < value.length; i += 1) {
    const route = value[i];
    if (!route || typeof route !== 'object' || Array.isArray(route)) {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}]`
      };
    }

    const webhookURL = typeof route.webhook_url === 'string'
      ? route.webhook_url.trim()
      : '';
    if (!webhookURL) {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}].webhook_url`
      };
    }

    if (Object.prototype.hasOwnProperty.call(route, 'enabled')
      && typeof route.enabled !== 'boolean') {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}].enabled`
      };
    }

    if (Object.prototype.hasOwnProperty.call(route, 'code_allowlist')
      && !Array.isArray(route.code_allowlist)) {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}].code_allowlist`
      };
    }

    const minSeverity = Object.prototype.hasOwnProperty.call(route, 'min_severity')
      ? parseSecurityAlertSeverityInput(route.min_severity)
      : 'high';
    if (!minSeverity) {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}].min_severity`
      };
    }

    const normalized = normalizeSecurityAlertWebhookRoute({
      name: route.name,
      webhook_url: webhookURL,
      min_severity: minSeverity,
      code_allowlist: Array.isArray(route.code_allowlist) ? route.code_allowlist : [],
      enabled: typeof route.enabled === 'boolean' ? route.enabled : true
    }, i);
    if (!normalized) {
      return {
        ok: false,
        error: `invalid security_alert_webhook_routes[${i}]`
      };
    }
    routes.push(normalized);
  }
  return {
    ok: true,
    routes
  };
}

function parseSecurityAlertWebhookRoutesFromEnv(rawValue) {
  if (typeof rawValue !== 'string' || rawValue.trim() === '') {
    return [];
  }
  try {
    const parsed = JSON.parse(rawValue);
    return normalizeSecurityAlertWebhookRoutes(parsed);
  } catch {
    return [];
  }
}

function appendPolicyAuditRecord(auditPath, record = {}) {
  if (!auditPath) {
    return;
  }
  fs.mkdirSync(path.dirname(auditPath), { recursive: true });
  fs.appendFileSync(auditPath, `${JSON.stringify(record)}\n`, 'utf8');
}

function listPolicyAuditRecords(auditPath, { limit = 50 } = {}) {
  if (!auditPath || !fs.existsSync(auditPath)) {
    return [];
  }
  try {
    const raw = fs.readFileSync(auditPath, 'utf8');
    const events = raw
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
    return events.slice(-limit);
  } catch {
    return [];
  }
}

function buildPolicyAuditSummary(records, {
  windowSeconds = 86400,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const filtered = records.filter((record) => {
    const ts = typeof record?.timestamp === 'number' ? record.timestamp : 0;
    return ts >= startTimestamp && ts <= endTimestamp;
  });

  const actionCounts = {};
  const statusCounts = {};
  let authenticatedCount = 0;
  let unauthenticatedCount = 0;

  for (const record of filtered) {
    if (typeof record?.action === 'string' && record.action) {
      actionCounts[record.action] = (actionCounts[record.action] || 0) + 1;
    }

    const statusRaw = record?.meta?.status;
    if (Number.isFinite(statusRaw)) {
      const statusKey = String(statusRaw);
      statusCounts[statusKey] = (statusCounts[statusKey] || 0) + 1;
    }

    if (record?.meta?.authenticated === true) {
      authenticatedCount += 1;
    } else if (record?.meta?.authenticated === false) {
      unauthenticatedCount += 1;
    }
  }

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_events: filtered.length,
    action_counts: actionCounts,
    status_counts: statusCounts,
    authenticated_count: authenticatedCount,
    unauthenticated_count: unauthenticatedCount
  };
}

function appendSecurityAlertRecord(alertPath, alert = {}) {
  if (!alertPath) {
    return;
  }
  fs.mkdirSync(path.dirname(alertPath), { recursive: true });
  fs.appendFileSync(alertPath, `${JSON.stringify(alert)}\n`, 'utf8');
}

function appendSecurityAlertAckRecord(ackPath, record = {}) {
  if (!ackPath) {
    return;
  }
  fs.mkdirSync(path.dirname(ackPath), { recursive: true });
  fs.appendFileSync(ackPath, `${JSON.stringify(record)}\n`, 'utf8');
}

function appendSecurityAlertEscalationRecord(escalationPath, record = {}) {
  if (!escalationPath) {
    return;
  }
  fs.mkdirSync(path.dirname(escalationPath), { recursive: true });
  fs.appendFileSync(escalationPath, `${JSON.stringify(record)}\n`, 'utf8');
}

function normalizeSecurityAlertRecord(record, index = 0) {
  const type = typeof record?.type === 'string' && record.type.trim() !== ''
    ? record.type.trim()
    : 'security.alert';
  const code = typeof record?.code === 'string' && record.code.trim() !== ''
    ? record.code.trim()
    : 'unknown';
  const severity = normalizeSecurityAlertSeverity(record?.severity, 'high');
  const timestamp = Number.isFinite(record?.timestamp)
    ? Math.floor(record.timestamp)
    : Math.floor(Date.now() / 1000);
  const detail = record?.detail && typeof record.detail === 'object' && !Array.isArray(record.detail)
    ? record.detail
    : {};
  const id = typeof record?.id === 'string' && record.id.trim() !== ''
    ? record.id.trim()
    : `legacy-${createHash('sha256')
      .update(JSON.stringify({ type, code, severity, timestamp, detail, index }))
      .digest('hex')
      .slice(0, 20)}`;

  return {
    ...record,
    id,
    type,
    code,
    severity,
    timestamp,
    detail
  };
}

function buildSecurityAlertAckStateMap(records = []) {
  const map = new Map();
  for (const record of records) {
    if (!record || record.action !== 'ack') {
      continue;
    }
    const alertId = typeof record.alert_id === 'string' ? record.alert_id.trim() : '';
    if (!alertId) {
      continue;
    }
    const timestamp = Number.isFinite(record.timestamp) ? Math.floor(record.timestamp) : 0;
    const current = map.get(alertId);
    if (!current || timestamp >= current.timestamp) {
      map.set(alertId, {
        id: typeof record.id === 'string' ? record.id : '',
        alert_id: alertId,
        action: 'ack',
        actor: typeof record.actor === 'string' ? record.actor : '',
        note: typeof record.note === 'string' ? record.note : '',
        timestamp
      });
    }
  }
  return map;
}

function buildSecurityAlertEscalationStateMap(records = []) {
  const map = new Map();
  for (const record of records) {
    if (!record || record.action !== 'escalate') {
      continue;
    }
    const alertId = typeof record.alert_id === 'string' ? record.alert_id.trim() : '';
    if (!alertId) {
      continue;
    }
    const timestamp = Number.isFinite(record.timestamp) ? Math.floor(record.timestamp) : 0;
    const current = map.get(alertId);
    if (!current || timestamp >= current.timestamp) {
      map.set(alertId, {
        id: typeof record.id === 'string' ? record.id : '',
        alert_id: alertId,
        action: 'escalate',
        actor: typeof record.actor === 'string' ? record.actor : '',
        note: typeof record.note === 'string' ? record.note : '',
        reason: typeof record.reason === 'string' ? record.reason : '',
        timestamp
      });
    }
  }
  return map;
}

function listSecurityAlerts(
  alertPath,
  {
    ackStateByAlertId = new Map(),
    escalationStateByAlertId = new Map(),
    limit = 50
  } = {}
) {
  const records = listPolicyAuditRecords(alertPath, { limit: Number.MAX_SAFE_INTEGER });
  const alerts = records.map((record, index) => normalizeSecurityAlertRecord(record, index));
  const enriched = alerts.map((alert) => {
    const ack = ackStateByAlertId.get(alert.id);
    const escalation = escalationStateByAlertId.get(alert.id);
    if (!ack) {
      return {
        ...alert,
        acknowledged: false,
        acknowledged_at: null,
        acknowledged_by: null,
        ack_note: null,
        ack_event_id: null,
        escalated: escalation ? true : false,
        escalated_at: escalation ? escalation.timestamp : null,
        escalated_by: escalation ? (escalation.actor || null) : null,
        escalation_note: escalation ? (escalation.note || null) : null,
        escalation_reason: escalation ? (escalation.reason || null) : null,
        escalation_event_id: escalation ? (escalation.id || null) : null
      };
    }
    return {
      ...alert,
      acknowledged: true,
      acknowledged_at: ack.timestamp,
      acknowledged_by: ack.actor || null,
      ack_note: ack.note || null,
      ack_event_id: ack.id || null,
      escalated: escalation ? true : false,
      escalated_at: escalation ? escalation.timestamp : null,
      escalated_by: escalation ? (escalation.actor || null) : null,
      escalation_note: escalation ? (escalation.note || null) : null,
      escalation_reason: escalation ? (escalation.reason || null) : null,
      escalation_event_id: escalation ? (escalation.id || null) : null
    };
  });
  return enriched.slice(-limit);
}

function buildSecurityAlertSummary(records, {
  windowSeconds = 86400,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const filtered = records.filter((record) => {
    const ts = typeof record?.timestamp === 'number' ? record.timestamp : 0;
    return ts >= startTimestamp && ts <= endTimestamp;
  });

  const severityCounts = {};
  const codeCounts = {};
  let acknowledgedCount = 0;
  let unacknowledgedCount = 0;
  let escalatedCount = 0;
  let unescalatedCount = 0;

  for (const record of filtered) {
    if (typeof record?.severity === 'string' && record.severity.trim() !== '') {
      const severityKey = record.severity.trim().toLowerCase();
      severityCounts[severityKey] = (severityCounts[severityKey] || 0) + 1;
    }

    if (typeof record?.code === 'string' && record.code.trim() !== '') {
      const codeKey = record.code.trim();
      codeCounts[codeKey] = (codeCounts[codeKey] || 0) + 1;
    }

    if (record?.acknowledged === true) {
      acknowledgedCount += 1;
    } else {
      unacknowledgedCount += 1;
    }

    if (record?.escalated === true) {
      escalatedCount += 1;
    } else {
      unescalatedCount += 1;
    }
  }

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_alerts: filtered.length,
    severity_counts: severityCounts,
    code_counts: codeCounts,
    acknowledged_count: acknowledgedCount,
    unacknowledged_count: unacknowledgedCount,
    escalated_count: escalatedCount,
    unescalated_count: unescalatedCount
  };
}

function loadEnrichedSecurityAlertsForKpi(dataDir) {
  const securityAlertPath = path.join(dataDir, 'audit', 'security-alerts.jsonl');
  const securityAlertAckPath = path.join(dataDir, 'audit', 'security-alert-acks.jsonl');
  const securityAlertEscalationPath = path.join(dataDir, 'audit', 'security-alert-escalations.jsonl');
  const ackStateByAlertId = buildSecurityAlertAckStateMap(
    listPolicyAuditRecords(securityAlertAckPath, { limit: Number.MAX_SAFE_INTEGER })
  );
  const escalationStateByAlertId = buildSecurityAlertEscalationStateMap(
    listPolicyAuditRecords(securityAlertEscalationPath, { limit: Number.MAX_SAFE_INTEGER })
  );
  return listSecurityAlerts(securityAlertPath, {
    ackStateByAlertId,
    escalationStateByAlertId,
    limit: Number.MAX_SAFE_INTEGER
  });
}

function applySecurityAlertSummaryToKpi(summary, alertSummary) {
  if (!summary?.reliability || !alertSummary) {
    return;
  }
  summary.reliability.security_alerts_total = Number.isFinite(alertSummary.total_alerts)
    ? Math.trunc(alertSummary.total_alerts)
    : 0;
  summary.reliability.security_alerts_high = Number.isFinite(alertSummary?.severity_counts?.high)
    ? Math.trunc(alertSummary.severity_counts.high)
    : 0;
  summary.reliability.security_alerts_critical = Number.isFinite(alertSummary?.severity_counts?.critical)
    ? Math.trunc(alertSummary.severity_counts.critical)
    : 0;
  summary.reliability.security_alerts_unacknowledged = Number.isFinite(alertSummary.unacknowledged_count)
    ? Math.trunc(alertSummary.unacknowledged_count)
    : 0;
  summary.reliability.security_alerts_escalated = Number.isFinite(alertSummary.escalated_count)
    ? Math.trunc(alertSummary.escalated_count)
    : 0;
}

function safeDecodeSessionIdFromFile(fileName) {
  const baseName = fileName.endsWith('.jsonl') ? fileName.slice(0, -6) : fileName;
  try {
    return decodeURIComponent(baseName);
  } catch {
    return baseName;
  }
}

function incrementCounter(counter, key) {
  if (typeof key !== 'string' || key.trim() === '') {
    return;
  }
  const normalizedKey = key.trim();
  counter[normalizedKey] = (counter[normalizedKey] || 0) + 1;
}

function permissionReferenceKey(event, value) {
  const reference = normalizeOptionalString(value, '');
  if (!reference) {
    return '';
  }
  const sessionId = normalizeOptionalString(event?.session_id, UNKNOWN_SESSION_ID);
  return `${sessionId}\u0000${reference}`;
}

function buildHostLocalPermissionReferences(events) {
  const requestEventIds = new Set();
  const providerRequestIds = new Set();
  for (const event of events) {
    if (!isHostLocalPermissionRequest(event)) {
      continue;
    }
    const requestEventId = permissionReferenceKey(event, event.id || event.event_id);
    const providerRequestId = permissionReferenceKey(event, event.payload?.request_id);
    if (requestEventId) {
      requestEventIds.add(requestEventId);
    }
    if (providerRequestId) {
      providerRequestIds.add(providerRequestId);
    }
  }
  return { requestEventIds, providerRequestIds };
}

function isHostLocalPermissionDecision(event, references) {
  if (event?.type !== 'permission.decided') {
    return false;
  }
  const requestEventId = permissionReferenceKey(event, event.payload?.request_event_id);
  const providerRequestId = permissionReferenceKey(event, event.payload?.request_id);
  return Boolean(
    (requestEventId && references.requestEventIds.has(requestEventId))
      || (providerRequestId && references.providerRequestIds.has(providerRequestId))
  );
}

function buildSessionsSummary(dataDir, {
  windowSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const eventsPath = path.join(dataDir, 'events');
  if (!fs.existsSync(eventsPath)) {
    return {
      window_seconds: windowSeconds,
      start_timestamp: startTimestamp,
      end_timestamp: endTimestamp,
      total_events: 0,
      total_sessions: 0,
      active_sessions: 0,
      source_counts: {},
      type_counts: {},
      risk_counts: {},
      permission: {
        requested: 0,
        decided: 0,
        approved: 0,
        denied: 0,
        pending: 0
      }
    };
  }

  const sourceCounts = {};
  const typeCounts = {};
  const riskCounts = {};
  const permission = {
    requested: 0,
    decided: 0,
    approved: 0,
    denied: 0,
    pending: 0
  };
  const sessionState = new Map();
  let totalEvents = 0;

  const eventRecords = loadKpiEventRecords(dataDir);
  const hostLocalPermissionReferences = buildHostLocalPermissionReferences(eventRecords);
  for (const event of eventRecords) {
    const timestamp = Number.isFinite(event.timestamp)
      ? Math.floor(event.timestamp)
      : null;
    if (timestamp === null || timestamp < startTimestamp || timestamp > endTimestamp) {
      continue;
    }

    totalEvents += 1;
    incrementCounter(sourceCounts, typeof event.source === 'string' ? event.source : '');
    incrementCounter(typeCounts, typeof event.type === 'string' ? event.type : '');
    incrementCounter(riskCounts, typeof event?.meta?.risk_level === 'string' ? event.meta.risk_level : 'none');

    if (event.type === 'permission.requested' && !isHostLocalPermissionRequest(event)) {
      permission.requested += 1;
    } else if (event.type === 'permission.decided'
      && !isHostLocalPermissionDecision(event, hostLocalPermissionReferences)) {
      permission.decided += 1;
      const decision = typeof event?.payload?.decision === 'string'
        ? event.payload.decision.trim().toLowerCase()
        : '';
      if (decision === 'approved') {
        permission.approved += 1;
      } else if (decision === 'denied') {
        permission.denied += 1;
      }
    }

    const sessionId = normalizeOptionalString(event.session_id, UNKNOWN_SESSION_ID);
    const current = sessionState.get(sessionId);
    if (!current || timestamp >= current.last_timestamp) {
      sessionState.set(sessionId, {
        last_timestamp: timestamp,
        last_type: typeof event.type === 'string' ? event.type : ''
      });
    }
  }

  permission.pending = Math.max(0, permission.requested - permission.decided);
  const activeSessions = Array.from(sessionState.values())
    .filter((item) => item.last_type !== 'session.ended').length;

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_events: totalEvents,
    total_sessions: sessionState.size,
    active_sessions: activeSessions,
    source_counts: sourceCounts,
    type_counts: typeCounts,
    risk_counts: riskCounts,
    permission
  };
}

function roundMetric(value, digits = 4) {
  if (!Number.isFinite(value)) {
    return null;
  }
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function percentile(values, p) {
  if (!Array.isArray(values) || values.length === 0) {
    return null;
  }
  const sorted = [...values].sort((a, b) => a - b);
  const rank = Math.max(0, Math.min(sorted.length - 1, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[rank];
}

function createEmptyKpiSummary({
  windowSeconds,
  startTimestamp,
  endTimestamp
}) {
  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    connection: {
      started: 0,
      ended: 0,
      ended_ok: 0,
      ended_nonzero: 0,
      success_rate: null
    },
    approval: {
      requested: 0,
      decided: 0,
      approved: 0,
      denied: 0,
      pending: 0,
      decision_rate: null,
      average_latency_ms: null,
      p95_latency_ms: null
    },
    task: {
      started: 0,
      completed: 0,
      failed: 0,
      aborted: 0,
      completion_rate: null
    },
    reliability: {
      system_errors: 0,
      session_end_nonzero: 0,
      cursor_conflicts: 0,
      cursor_conflict_retries: 0,
      cursor_conflicts_unresolved: 0,
      cursor_conflict_recovery_rate: null,
      security_alerts_total: 0,
      security_alerts_high: 0,
      security_alerts_critical: 0,
      security_alerts_unacknowledged: 0,
      security_alerts_escalated: 0
    }
  };
}

function loadKpiEventRecords(dataDir) {
  const eventsPath = path.join(dataDir, 'events');
  if (!fs.existsSync(eventsPath)) {
    return [];
  }
  const records = [];
  const fileNames = fs.readdirSync(eventsPath).filter((entry) => entry.endsWith('.jsonl'));
  for (const fileName of fileNames) {
    const fallbackSessionId = safeDecodeSessionIdFromFile(fileName);
    const filePath = path.join(eventsPath, fileName);
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content
      .split('\n')
      .map((line) => line.trim())
      .filter(Boolean);
    for (const line of lines) {
      let event = null;
      try {
        event = JSON.parse(line);
      } catch {
        event = null;
      }
      if (!event || typeof event !== 'object') {
        continue;
      }
      const normalizedSessionId = typeof event.session_id === 'string' && event.session_id.trim() !== ''
        ? event.session_id.trim()
        : fallbackSessionId;
      event = {
        ...event,
        session_id: normalizedSessionId
      };
      records.push(event);
    }
  }
  return records;
}

function cursorOpsFilePath(dataDir) {
  return path.join(dataDir, 'metrics', 'cursor-ops.jsonl');
}

function appendCursorOperationRecord(dataDir, record = {}) {
  const filePath = cursorOpsFilePath(dataDir);
  const timestampMs = Number.isFinite(record.timestamp_ms)
    ? Math.trunc(record.timestamp_ms)
    : Date.now();
  const payload = {
    timestamp: Math.floor(timestampMs / 1000),
    timestamp_ms: timestampMs,
    session_id: normalizeOptionalString(record.session_id, 'unknown-session'),
    outcome: record.outcome === 'conflict' ? 'conflict' : 'success',
    if_match_provided: record.if_match_provided === true
  };
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
}

function loadCursorOperationRecords(dataDir) {
  const filePath = cursorOpsFilePath(dataDir);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return content
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index) => {
      try {
        const parsed = JSON.parse(line);
        if (!parsed || typeof parsed !== 'object') {
          return null;
        }
        const timestampMs = Number.isFinite(parsed.timestamp_ms)
          ? Math.trunc(parsed.timestamp_ms)
          : (Number.isFinite(parsed.timestamp) ? Math.trunc(parsed.timestamp) * 1000 : null);
        const timestamp = Number.isFinite(parsed.timestamp)
          ? Math.trunc(parsed.timestamp)
          : (Number.isFinite(timestampMs) ? Math.floor(timestampMs / 1000) : null);
        if (!Number.isFinite(timestampMs) || !Number.isFinite(timestamp)) {
          return null;
        }
        return {
          session_id: normalizeOptionalString(parsed.session_id, 'unknown-session'),
          outcome: parsed.outcome === 'conflict' ? 'conflict' : 'success',
          if_match_provided: parsed.if_match_provided === true,
          timestamp,
          timestamp_ms: timestampMs,
          _index: index
        };
      } catch {
        return null;
      }
    })
    .filter((record) => record !== null)
    .sort((left, right) => {
      if (left.timestamp_ms !== right.timestamp_ms) {
        return left.timestamp_ms - right.timestamp_ms;
      }
      return left._index - right._index;
    });
}

function uiActionsFilePath(dataDir) {
  return path.join(dataDir, 'metrics', 'ui-actions.jsonl');
}

function appendUiActionRecord(dataDir, record = {}) {
  const filePath = uiActionsFilePath(dataDir);
  const timestamp = Number.isFinite(record.timestamp)
    ? Math.floor(record.timestamp)
    : Math.floor(Date.now() / 1000);
  const payload = {
    event_id: normalizeOptionalString(record.event_id, randomUUID()),
    action: normalizeOptionalString(record.action, ''),
    screen: normalizeOptionalString(record.screen, 'unknown'),
    flow_id: normalizeOptionalString(record.flow_id, ''),
    session_id: normalizeOptionalString(record.session_id, ''),
    timestamp
  };
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
  return payload;
}

function loadUiActionRecords(dataDir) {
  const filePath = uiActionsFilePath(dataDir);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return content
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index) => {
      try {
        const parsed = JSON.parse(line);
        if (!parsed || typeof parsed !== 'object') {
          return null;
        }
        const action = normalizeOptionalString(parsed.action, '');
        const timestamp = Number.isFinite(parsed.timestamp)
          ? Math.floor(parsed.timestamp)
          : null;
        if (!action || !Number.isFinite(timestamp)) {
          return null;
        }
        return {
          event_id: normalizeOptionalString(parsed.event_id, ''),
          action,
          screen: normalizeOptionalString(parsed.screen, 'unknown'),
          flow_id: normalizeOptionalString(parsed.flow_id, ''),
          session_id: normalizeOptionalString(parsed.session_id, ''),
          timestamp,
          _index: index
        };
      } catch {
        return null;
      }
    })
    .filter((record) => record !== null)
    .sort((left, right) => {
      if (left.timestamp !== right.timestamp) {
        return left.timestamp - right.timestamp;
      }
      return left._index - right._index;
    });
}

function buildUiActionSummary(dataDir, {
  windowSeconds = 3600,
  limit = 10,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const safeLimit = Math.max(1, Math.min(limit, 50));
  const actionCounts = {};
  const transitionCounts = {};
  const flowTimeline = new Map();
  const records = loadUiActionRecords(dataDir);
  const filtered = records.filter((record) => (
    record.timestamp >= startTimestamp && record.timestamp <= endTimestamp
  ));

  for (const record of filtered) {
    actionCounts[record.action] = (actionCounts[record.action] || 0) + 1;
    const flowId = record.flow_id || `session:${record.session_id || 'unknown'}`;
    if (!flowTimeline.has(flowId)) {
      flowTimeline.set(flowId, []);
    }
    flowTimeline.get(flowId).push(record);
  }

  for (const flowRecords of flowTimeline.values()) {
    for (let index = 1; index < flowRecords.length; index += 1) {
      const transition = `${flowRecords[index - 1].action}->${flowRecords[index].action}`;
      transitionCounts[transition] = (transitionCounts[transition] || 0) + 1;
    }
  }

  const topActions = Object.entries(actionCounts)
    .map(([action, count]) => ({ action, count }))
    .sort((left, right) => {
      if (right.count !== left.count) {
        return right.count - left.count;
      }
      return left.action.localeCompare(right.action);
    })
    .slice(0, safeLimit);

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_actions: filtered.length,
    flow_count: flowTimeline.size,
    action_counts: actionCounts,
    transition_counts: transitionCounts,
    top_actions: topActions
  };
}

function incrementIssueCounter(counter, key) {
  if (!counter || typeof counter !== 'object') {
    return;
  }
  if (typeof key !== 'string' || key.trim() === '') {
    return;
  }
  const normalizedKey = key.trim();
  counter[normalizedKey] = (counter[normalizedKey] || 0) + 1;
}

function appendReplayConsistencyIssue(sessionIssues, summaryIssueCounts, sessionId, issueCode) {
  const normalizedSessionId = normalizeOptionalString(sessionId, 'unknown-session');
  const normalizedIssueCode = normalizeOptionalString(issueCode, '');
  if (!normalizedIssueCode) {
    return;
  }
  incrementIssueCounter(summaryIssueCounts, normalizedIssueCode);
  if (!sessionIssues.has(normalizedSessionId)) {
    sessionIssues.set(normalizedSessionId, {
      session_id: normalizedSessionId,
      issue_count: 0,
      issue_counts: {}
    });
  }
  const state = sessionIssues.get(normalizedSessionId);
  state.issue_count += 1;
  incrementIssueCounter(state.issue_counts, normalizedIssueCode);
}

function buildReplayConsistencySummary(dataDir, {
  windowSeconds = 3600,
  limit = 10,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const safeLimit = Math.max(1, Math.min(limit, 100));
  const eventsPath = path.join(dataDir, 'events');
  const cursorsPath = path.join(dataDir, 'cursors');
  const sessionIssues = new Map();
  const issueCounts = {};
  const eventsBySession = new Map();
  const sessionsWithEventFile = new Set();

  const summary = {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    sessions_scanned: 0,
    event_lines_scanned: 0,
    event_lines_in_window: 0,
    malformed_event_lines: 0,
    events_missing_id: 0,
    duplicate_event_ids: 0,
    cursor_files_scanned: 0,
    malformed_cursor_files: 0,
    orphan_cursor_files: 0,
    cursor_missing_event: 0,
    issue_counts: {},
    affected_sessions: []
  };

  if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter((entry) => entry.endsWith('.jsonl'));
    for (const fileName of eventFiles) {
      const fallbackSessionId = safeDecodeSessionIdFromFile(fileName);
      const filePath = path.join(eventsPath, fileName);
      summary.sessions_scanned += 1;
      sessionsWithEventFile.add(fallbackSessionId);

      const eventIds = new Set();
      eventsBySession.set(fallbackSessionId, eventIds);

      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);

      for (const line of lines) {
        summary.event_lines_scanned += 1;
        let event = null;
        try {
          event = JSON.parse(line);
        } catch {
          summary.malformed_event_lines += 1;
          appendReplayConsistencyIssue(
            sessionIssues,
            issueCounts,
            fallbackSessionId,
            'event.malformed_json_line'
          );
          continue;
        }

        if (!event || typeof event !== 'object') {
          summary.malformed_event_lines += 1;
          appendReplayConsistencyIssue(
            sessionIssues,
            issueCounts,
            fallbackSessionId,
            'event.invalid_payload'
          );
          continue;
        }

        const eventTimestamp = Number.isFinite(event.timestamp)
          ? Math.floor(event.timestamp)
          : null;
        if (eventTimestamp !== null
          && eventTimestamp >= startTimestamp
          && eventTimestamp <= endTimestamp) {
          summary.event_lines_in_window += 1;
        }

        const sessionId = normalizeOptionalString(event.session_id, fallbackSessionId);
        if (!eventsBySession.has(sessionId)) {
          eventsBySession.set(sessionId, new Set());
        }
        const sessionEventIds = eventsBySession.get(sessionId);
        const eventId = normalizeOptionalString(event.id, '');
        if (!eventId) {
          summary.events_missing_id += 1;
          appendReplayConsistencyIssue(
            sessionIssues,
            issueCounts,
            sessionId,
            'event.missing_id'
          );
          continue;
        }
        if (sessionEventIds.has(eventId)) {
          summary.duplicate_event_ids += 1;
          appendReplayConsistencyIssue(
            sessionIssues,
            issueCounts,
            sessionId,
            'event.duplicate_id'
          );
          continue;
        }
        sessionEventIds.add(eventId);
      }
    }
  }

  if (fs.existsSync(cursorsPath)) {
    const cursorFiles = fs.readdirSync(cursorsPath).filter((entry) => entry.endsWith('.json'));
    for (const fileName of cursorFiles) {
      const sessionIdFromName = safeDecodeSessionIdFromFile(fileName);
      const filePath = path.join(cursorsPath, fileName);
      summary.cursor_files_scanned += 1;

      let cursorState = null;
      try {
        const raw = fs.readFileSync(filePath, 'utf8');
        cursorState = raw.trim() ? JSON.parse(raw) : {};
      } catch {
        summary.malformed_cursor_files += 1;
        appendReplayConsistencyIssue(
          sessionIssues,
          issueCounts,
          sessionIdFromName,
          'cursor.malformed_json'
        );
        continue;
      }

      if (!cursorState || typeof cursorState !== 'object' || Array.isArray(cursorState)) {
        summary.malformed_cursor_files += 1;
        appendReplayConsistencyIssue(
          sessionIssues,
          issueCounts,
          sessionIdFromName,
          'cursor.invalid_payload'
        );
        continue;
      }

      const sessionId = normalizeOptionalString(cursorState.session_id, sessionIdFromName);
      const hasSessionEventFile = sessionsWithEventFile.has(sessionId);
      if (!hasSessionEventFile) {
        summary.orphan_cursor_files += 1;
        appendReplayConsistencyIssue(
          sessionIssues,
          issueCounts,
          sessionId,
          'cursor.orphan_file'
        );
      }

      const cursorValue = normalizeOptionalString(cursorState.cursor, '');
      if (!cursorValue || !hasSessionEventFile) {
        continue;
      }
      const sessionEventIds = eventsBySession.get(sessionId);
      if (!sessionEventIds || !sessionEventIds.has(cursorValue)) {
        summary.cursor_missing_event += 1;
        appendReplayConsistencyIssue(
          sessionIssues,
          issueCounts,
          sessionId,
          'cursor.points_to_missing_event'
        );
      }
    }
  }

  summary.issue_counts = issueCounts;
  summary.affected_sessions = Array.from(sessionIssues.values())
    .sort((left, right) => {
      if (right.issue_count !== left.issue_count) {
        return right.issue_count - left.issue_count;
      }
      return left.session_id.localeCompare(right.session_id);
    })
    .slice(0, safeLimit);
  return summary;
}

function accumulateCursorOperationKpi(summary, cursorRecords, {
  startTimestamp,
  endTimestamp
}) {
  const pendingConflictBySession = new Map();

  for (const record of cursorRecords) {
    if (record.timestamp < startTimestamp || record.timestamp > endTimestamp) {
      continue;
    }
    const sessionId = record.session_id;
    if (record.outcome === 'conflict') {
      summary.reliability.cursor_conflicts += 1;
      const pendingCount = pendingConflictBySession.get(sessionId) ?? 0;
      pendingConflictBySession.set(sessionId, pendingCount + 1);
      continue;
    }
    if (record.outcome === 'success' && record.if_match_provided === true) {
      const pendingCount = pendingConflictBySession.get(sessionId) ?? 0;
      if (pendingCount > 0) {
        summary.reliability.cursor_conflict_retries += 1;
        pendingConflictBySession.set(sessionId, pendingCount - 1);
      }
    }
  }

  for (const pendingCount of pendingConflictBySession.values()) {
    if (pendingCount > 0) {
      summary.reliability.cursor_conflicts_unresolved += pendingCount;
    }
  }
  if (summary.reliability.cursor_conflicts > 0) {
    summary.reliability.cursor_conflict_recovery_rate = roundMetric(
      summary.reliability.cursor_conflict_retries / summary.reliability.cursor_conflicts
    );
  }
}

function accumulateKpiSummaryFromRecords(summary, eventRecords, {
  startTimestamp,
  endTimestamp
}) {
  const permissionRequestTimestampById = new Map();
  const approvalLatencies = [];
  const hostLocalPermissionReferences = buildHostLocalPermissionReferences(eventRecords);

  for (const event of eventRecords) {
    const timestamp = Number.isFinite(event.timestamp)
      ? Math.floor(event.timestamp)
      : null;
    if (timestamp === null || timestamp < startTimestamp || timestamp > endTimestamp) {
      continue;
    }
    const type = typeof event.type === 'string' ? event.type : '';
    if (type === 'session.started') {
      summary.connection.started += 1;
    } else if (type === 'session.ended') {
      summary.connection.ended += 1;
      const code = Number.isFinite(event?.payload?.code) ? Math.trunc(event.payload.code) : 0;
      if (code === 0) {
        summary.connection.ended_ok += 1;
      } else {
        summary.connection.ended_nonzero += 1;
        summary.reliability.session_end_nonzero += 1;
      }
    } else if (type === 'permission.requested' && !isHostLocalPermissionRequest(event)) {
      summary.approval.requested += 1;
      if (typeof event.id === 'string' && event.id.trim() !== '') {
        permissionRequestTimestampById.set(event.id.trim(), timestamp);
      }
    } else if (type === 'permission.decided'
      && !isHostLocalPermissionDecision(event, hostLocalPermissionReferences)) {
      summary.approval.decided += 1;
      const decision = typeof event?.payload?.decision === 'string'
        ? event.payload.decision.trim().toLowerCase()
        : '';
      if (decision === 'approved') {
        summary.approval.approved += 1;
      } else if (decision === 'denied') {
        summary.approval.denied += 1;
      }

      const requestEventId = typeof event?.payload?.request_event_id === 'string'
        ? event.payload.request_event_id.trim()
        : '';
      const requestTimestamp = permissionRequestTimestampById.get(requestEventId);
      if (Number.isFinite(requestTimestamp)) {
        approvalLatencies.push(Math.max(0, (timestamp - requestTimestamp) * 1000));
      }
    } else if (type === 'task.started') {
      summary.task.started += 1;
    } else if (type === 'task.completed' && !isTurnFinishedEvent(event)) {
      summary.task.completed += 1;
    } else if (type === 'task.failed') {
      summary.task.failed += 1;
    } else if (type === 'task.aborted') {
      summary.task.aborted += 1;
    } else if (type === 'system.error') {
      summary.reliability.system_errors += 1;
    }
  }

  if (summary.connection.ended > 0) {
    summary.connection.success_rate = roundMetric(
      summary.connection.ended_ok / summary.connection.ended
    );
  }
  summary.approval.pending = Math.max(0, summary.approval.requested - summary.approval.decided);
  if (summary.approval.requested > 0) {
    summary.approval.decision_rate = roundMetric(summary.approval.decided / summary.approval.requested, 4);
  }
  if (approvalLatencies.length > 0) {
    const totalLatency = approvalLatencies.reduce((acc, value) => acc + value, 0);
    summary.approval.average_latency_ms = roundMetric(totalLatency / approvalLatencies.length, 2);
    summary.approval.p95_latency_ms = percentile(approvalLatencies, 95);
  }
  const taskTerminalCount = summary.task.completed + summary.task.failed + summary.task.aborted;
  if (taskTerminalCount > 0) {
    summary.task.completion_rate = roundMetric(summary.task.completed / taskTerminalCount);
  }
}

function buildKpiSummary(dataDir, {
  windowSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const summary = createEmptyKpiSummary({
    windowSeconds,
    startTimestamp,
    endTimestamp
  });
  const eventRecords = loadKpiEventRecords(dataDir);
  const cursorOperationRecords = loadCursorOperationRecords(dataDir);
  const securityAlerts = loadEnrichedSecurityAlertsForKpi(dataDir);
  accumulateKpiSummaryFromRecords(summary, eventRecords, { startTimestamp, endTimestamp });
  accumulateCursorOperationKpi(summary, cursorOperationRecords, { startTimestamp, endTimestamp });
  applySecurityAlertSummaryToKpi(
    summary,
    buildSecurityAlertSummary(securityAlerts, { windowSeconds, nowTimestamp })
  );
  return summary;
}

function countUnresolvedHighRiskSecurityAlerts(dataDir, {
  windowSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const records = loadEnrichedSecurityAlertsForKpi(dataDir);
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  return records.filter((record) => {
    const timestamp = Number.isFinite(record?.timestamp) ? record.timestamp : 0;
    if (timestamp < startTimestamp || timestamp > endTimestamp) {
      return false;
    }
    const severity = normalizeSecurityAlertSeverity(record?.severity, 'low');
    return SECURITY_ALERT_SEVERITY_RANK[severity] >= SECURITY_ALERT_SEVERITY_RANK.high
      && record?.acknowledged !== true;
  }).length;
}

function buildKpiBetaGates(dataDir, {
  windowSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000),
  crashFreeSessionRate = null,
  thresholds = {}
} = {}) {
  const kpi = buildKpiSummary(dataDir, { windowSeconds, nowTimestamp });
  const effectiveThresholds = {
    min_connection_success_rate: Number.isFinite(thresholds.min_connection_success_rate)
      ? thresholds.min_connection_success_rate
      : 0.95,
    min_approval_decision_rate: Number.isFinite(thresholds.min_approval_decision_rate)
      ? thresholds.min_approval_decision_rate
      : 0.95,
    max_approval_average_latency_ms: Number.isFinite(thresholds.max_approval_average_latency_ms)
      ? thresholds.max_approval_average_latency_ms
      : 3000,
    max_approval_p95_latency_ms: Number.isFinite(thresholds.max_approval_p95_latency_ms)
      ? thresholds.max_approval_p95_latency_ms
      : 8000,
    min_task_completion_rate: Number.isFinite(thresholds.min_task_completion_rate)
      ? thresholds.min_task_completion_rate
      : 0.85,
    max_cursor_conflicts_unresolved: Number.isFinite(thresholds.max_cursor_conflicts_unresolved)
      ? Math.trunc(thresholds.max_cursor_conflicts_unresolved)
      : 0,
    max_unresolved_high_risk_security_alerts: Number.isFinite(thresholds.max_unresolved_high_risk_security_alerts)
      ? Math.trunc(thresholds.max_unresolved_high_risk_security_alerts)
      : 0,
    min_crash_free_session_rate: Number.isFinite(thresholds.min_crash_free_session_rate)
      ? thresholds.min_crash_free_session_rate
      : 0.995
  };
  const unresolvedHighRiskSecurityAlerts = countUnresolvedHighRiskSecurityAlerts(dataDir, {
    windowSeconds,
    nowTimestamp
  });

  const checks = [];

  function addMinGate(id, label, currentValue, thresholdValue, source) {
    let status = 'unknown';
    if (Number.isFinite(currentValue)) {
      status = currentValue >= thresholdValue ? 'pass' : 'fail';
    }
    checks.push({
      id,
      label,
      source,
      comparator: '>=',
      current_value: Number.isFinite(currentValue) ? currentValue : null,
      threshold_value: thresholdValue,
      status
    });
  }

  function addMaxGate(id, label, currentValue, thresholdValue, source) {
    let status = 'unknown';
    if (Number.isFinite(currentValue)) {
      status = currentValue <= thresholdValue ? 'pass' : 'fail';
    }
    checks.push({
      id,
      label,
      source,
      comparator: '<=',
      current_value: Number.isFinite(currentValue) ? currentValue : null,
      threshold_value: thresholdValue,
      status
    });
  }

  addMinGate(
    'connection.success_rate',
    'Connection success rate',
    kpi.connection.success_rate,
    effectiveThresholds.min_connection_success_rate,
    'metrics/kpi.connection.success_rate'
  );
  addMinGate(
    'approval.decision_rate',
    'Approval decision rate',
    kpi.approval.decision_rate,
    effectiveThresholds.min_approval_decision_rate,
    'metrics/kpi.approval.decision_rate'
  );
  addMaxGate(
    'approval.average_latency_ms',
    'Approval average latency',
    kpi.approval.average_latency_ms,
    effectiveThresholds.max_approval_average_latency_ms,
    'metrics/kpi.approval.average_latency_ms'
  );
  addMaxGate(
    'approval.p95_latency_ms',
    'Approval P95 latency',
    kpi.approval.p95_latency_ms,
    effectiveThresholds.max_approval_p95_latency_ms,
    'metrics/kpi.approval.p95_latency_ms'
  );
  addMinGate(
    'task.completion_rate',
    'Task completion rate',
    kpi.task.completion_rate,
    effectiveThresholds.min_task_completion_rate,
    'metrics/kpi.task.completion_rate'
  );
  addMaxGate(
    'reliability.cursor_conflicts_unresolved',
    'Unresolved cursor conflicts',
    kpi.reliability.cursor_conflicts_unresolved,
    effectiveThresholds.max_cursor_conflicts_unresolved,
    'metrics/kpi.reliability.cursor_conflicts_unresolved'
  );
  addMaxGate(
    'security.unresolved_high_risk_alerts',
    'Unresolved high-risk security alerts',
    unresolvedHighRiskSecurityAlerts,
    effectiveThresholds.max_unresolved_high_risk_security_alerts,
    'security/alerts/summary.high_or_critical_unacknowledged'
  );
  addMinGate(
    'app.crash_free_sessions',
    'Crash-free sessions',
    crashFreeSessionRate,
    effectiveThresholds.min_crash_free_session_rate,
    'external.crash_free_session_rate'
  );

  const passCount = checks.filter((item) => item.status === 'pass').length;
  const failCount = checks.filter((item) => item.status === 'fail').length;
  const unknownCount = checks.filter((item) => item.status === 'unknown').length;
  let overallStatus = 'pass';
  if (failCount > 0) {
    overallStatus = 'fail';
  } else if (unknownCount > 0) {
    overallStatus = 'pass_with_unknown';
  }

  return {
    window_seconds: windowSeconds,
    start_timestamp: kpi.start_timestamp,
    end_timestamp: kpi.end_timestamp,
    thresholds: effectiveThresholds,
    external_evidence: {
      crash_free_session_rate: Number.isFinite(crashFreeSessionRate) ? crashFreeSessionRate : null,
      unresolved_high_risk_security_alerts: unresolvedHighRiskSecurityAlerts
    },
    checks,
    pass_count: passCount,
    fail_count: failCount,
    unknown_count: unknownCount,
    overall_status: overallStatus,
    kpi
  };
}

function buildKpiAnomalySummary(dataDir, {
  windowSeconds = 3600,
  baselineWindowSeconds = 86400,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const current = buildKpiSummary(dataDir, {
    windowSeconds,
    nowTimestamp
  });
  const baseline = buildKpiSummary(dataDir, {
    windowSeconds: baselineWindowSeconds,
    nowTimestamp
  });
  const alerts = [];

  function pushAlert({
    code,
    severity,
    metric,
    currentValue,
    baselineValue = null,
    thresholdValue = null,
    direction = 'up',
    message
  }) {
    alerts.push({
      id: `${code}:${current.end_timestamp}`,
      code,
      severity,
      metric,
      current_value: currentValue,
      baseline_value: baselineValue,
      threshold_value: thresholdValue,
      direction,
      message
    });
  }

  const unresolvedCursorConflicts = current.reliability.cursor_conflicts_unresolved;
  if (unresolvedCursorConflicts > 0) {
    pushAlert({
      code: 'kpi.cursor_conflicts.unresolved',
      severity: 'high',
      metric: 'reliability.cursor_conflicts_unresolved',
      currentValue: unresolvedCursorConflicts,
      baselineValue: baseline.reliability.cursor_conflicts_unresolved,
      thresholdValue: 0,
      message: `unresolved cursor conflicts detected (${unresolvedCursorConflicts})`
    });
  }

  const criticalSecurityAlerts = current.reliability.security_alerts_critical;
  if (criticalSecurityAlerts > 0) {
    pushAlert({
      code: 'kpi.security_alerts.critical',
      severity: 'critical',
      metric: 'reliability.security_alerts_critical',
      currentValue: criticalSecurityAlerts,
      baselineValue: baseline.reliability.security_alerts_critical,
      thresholdValue: 0,
      message: `critical security alerts detected (${criticalSecurityAlerts})`
    });
  }

  const baselineP95Latency = baseline.approval.p95_latency_ms;
  const currentP95Latency = current.approval.p95_latency_ms;
  if (Number.isFinite(currentP95Latency) && Number.isFinite(baselineP95Latency)) {
    const thresholdValue = Math.max(2000, baselineP95Latency * 1.5);
    if (currentP95Latency >= thresholdValue) {
      pushAlert({
        code: 'kpi.approval_latency.p95_spike',
        severity: 'medium',
        metric: 'approval.p95_latency_ms',
        currentValue: currentP95Latency,
        baselineValue: baselineP95Latency,
        thresholdValue,
        message: `approval p95 latency spike (${Math.round(currentP95Latency)}ms)`
      });
    }
  }

  alerts.sort((left, right) => {
    const leftSeverity = normalizeSecurityAlertSeverity(left.severity, 'low');
    const rightSeverity = normalizeSecurityAlertSeverity(right.severity, 'low');
    const leftRank = SECURITY_ALERT_SEVERITY_RANK[leftSeverity] ?? 0;
    const rightRank = SECURITY_ALERT_SEVERITY_RANK[rightSeverity] ?? 0;
    if (leftRank !== rightRank) {
      return rightRank - leftRank;
    }
    return left.code.localeCompare(right.code);
  });

  return {
    window_seconds: windowSeconds,
    baseline_window_seconds: baselineWindowSeconds,
    start_timestamp: current.start_timestamp,
    end_timestamp: current.end_timestamp,
    total_alerts: alerts.length,
    alerts
  };
}

function kpiAnomalyDispatchAuditFilePath(dataDir) {
  return path.join(dataDir, 'metrics', 'kpi-anomaly-dispatch.jsonl');
}

function kpiAnomalyFingerprint(alert = {}) {
  const code = typeof alert.code === 'string' && alert.code.trim() !== ''
    ? alert.code.trim()
    : 'unknown';
  const severity = normalizeSecurityAlertSeverity(alert.severity, 'low');
  const metric = typeof alert.metric === 'string' && alert.metric.trim() !== ''
    ? alert.metric.trim()
    : 'unknown';
  return `${code}|${severity}|${metric}`;
}

function appendKpiAnomalyDispatchAuditRecord(dataDir, record = {}) {
  const filePath = kpiAnomalyDispatchAuditFilePath(dataDir);
  const timestamp = Number.isFinite(record.timestamp)
    ? Math.floor(record.timestamp)
    : Math.floor(Date.now() / 1000);
  const payload = {
    timestamp,
    fingerprint: typeof record.fingerprint === 'string' ? record.fingerprint : '',
    code: typeof record.code === 'string' ? record.code : '',
    severity: normalizeSecurityAlertSeverity(record.severity, 'low'),
    metric: typeof record.metric === 'string' ? record.metric : '',
    current_value: Number.isFinite(record.current_value) ? Number(record.current_value) : null,
    status: typeof record.status === 'string' ? record.status : 'dispatched',
    reason: typeof record.reason === 'string' ? record.reason : '',
    dedupe_window_seconds: Number.isFinite(record.dedupe_window_seconds)
      ? Math.max(0, Math.floor(record.dedupe_window_seconds))
      : 0
  };
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.appendFileSync(filePath, `${JSON.stringify(payload)}\n`, 'utf8');
}

function loadRecentKpiAnomalyDispatchState(dataDir, {
  sinceTimestamp = 0
} = {}) {
  const records = listKpiAnomalyDispatchAuditRecords(dataDir);
  const map = new Map();
  for (const record of records) {
    if (record.status !== 'dispatched') {
      continue;
    }
    const timestamp = Number.isFinite(record.timestamp) ? Math.floor(record.timestamp) : null;
    if (!Number.isFinite(timestamp) || timestamp < sinceTimestamp) {
      continue;
    }
    const fingerprint = typeof record.fingerprint === 'string' ? record.fingerprint : '';
    if (!fingerprint) {
      continue;
    }
    const current = map.get(fingerprint);
    if (!current || timestamp >= current.timestamp) {
      map.set(fingerprint, {
        timestamp,
        current_value: Number.isFinite(record.current_value) ? Number(record.current_value) : null
      });
    }
  }
  return map;
}

function listKpiAnomalyDispatchAuditRecords(dataDir) {
  const filePath = kpiAnomalyDispatchAuditFilePath(dataDir);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return content
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      let parsed = null;
      try {
        parsed = JSON.parse(line);
      } catch {
        parsed = null;
      }
      if (!parsed || typeof parsed !== 'object') {
        return null;
      }
      return {
        timestamp: Number.isFinite(parsed.timestamp) ? Math.floor(parsed.timestamp) : 0,
        fingerprint: typeof parsed.fingerprint === 'string' ? parsed.fingerprint : '',
        code: typeof parsed.code === 'string' ? parsed.code : 'unknown',
        severity: normalizeSecurityAlertSeverity(parsed.severity, 'low'),
        metric: typeof parsed.metric === 'string' ? parsed.metric : '',
        current_value: Number.isFinite(parsed.current_value) ? Number(parsed.current_value) : null,
        status: typeof parsed.status === 'string' ? parsed.status : 'dispatched',
        reason: typeof parsed.reason === 'string' ? parsed.reason : '',
        dedupe_window_seconds: Number.isFinite(parsed.dedupe_window_seconds)
          ? Math.max(0, Math.floor(parsed.dedupe_window_seconds))
          : 0
      };
    })
    .filter(Boolean);
}

function buildKpiAnomalyDispatchSummary(dataDir, {
  windowSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const records = listKpiAnomalyDispatchAuditRecords(dataDir).filter((record) => {
    return Number.isFinite(record.timestamp)
      && record.timestamp >= startTimestamp
      && record.timestamp <= endTimestamp;
  });

  const statusCounts = {
    dispatched: 0,
    suppressed: 0,
    failed: 0
  };
  const codeCounts = {};
  const reasonCounts = {};
  const severityCounts = {};

  for (const record of records) {
    if (Object.prototype.hasOwnProperty.call(statusCounts, record.status)) {
      statusCounts[record.status] += 1;
    }
    codeCounts[record.code] = (codeCounts[record.code] || 0) + 1;
    if (record.reason) {
      reasonCounts[record.reason] = (reasonCounts[record.reason] || 0) + 1;
    }
    severityCounts[record.severity] = (severityCounts[record.severity] || 0) + 1;
  }

  const dispatchAttempts = statusCounts.dispatched + statusCounts.failed;
  const dispatchSuccessRate = dispatchAttempts > 0
    ? roundMetric(statusCounts.dispatched / dispatchAttempts, 4)
    : null;

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_records: records.length,
    dispatched_count: statusCounts.dispatched,
    suppressed_count: statusCounts.suppressed,
    failed_count: statusCounts.failed,
    dispatch_success_rate: dispatchSuccessRate,
    code_counts: codeCounts,
    reason_counts: reasonCounts,
    severity_counts: severityCounts
  };
}

async function dispatchKpiAnomalyAlerts({
  dataDir,
  summary,
  webhookURL,
  webhookSender,
  minSeverity = 'high',
  codeAllowlist = [],
  dedupeWindowSeconds = 0,
  respectDedupe = false,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  if (!summary || typeof summary !== 'object' || !Array.isArray(summary.alerts)) {
    return [];
  }
  if (!dataDir || typeof dataDir !== 'string') {
    return [];
  }
  if (!webhookURL || typeof webhookURL !== 'string') {
    return [];
  }
  if (typeof webhookSender !== 'function') {
    return [];
  }

  const records = [];
  const normalizedMinSeverity = normalizeSecurityAlertSeverity(minSeverity, 'high');
  const normalizedCodeAllowlist = normalizeSecurityAlertCodeAllowlist(codeAllowlist);
  const normalizedDedupeWindowSeconds = Number.isFinite(dedupeWindowSeconds)
    ? Math.max(0, Math.floor(dedupeWindowSeconds))
    : 0;
  const dedupeEnabled = respectDedupe === true && normalizedDedupeWindowSeconds > 0;
  const dedupeStateByFingerprint = dedupeEnabled
    ? loadRecentKpiAnomalyDispatchState(dataDir, {
        sinceTimestamp: nowTimestamp - normalizedDedupeWindowSeconds
      })
    : new Map();

  for (const alert of summary.alerts) {
    const shouldDispatch = shouldDispatchSecurityAlertWebhook({
      alertSeverity: alert?.severity,
      minimumSeverity: normalizedMinSeverity,
      alertCode: alert?.code,
      codeAllowlist: normalizedCodeAllowlist
    });
    if (!shouldDispatch) {
      continue;
    }

    const fingerprint = kpiAnomalyFingerprint(alert);
    const currentValue = Number.isFinite(alert?.current_value)
      ? Number(alert.current_value)
      : null;
    const previousDispatch = dedupeStateByFingerprint.get(fingerprint);
    if (dedupeEnabled && previousDispatch) {
      const previousValue = Number.isFinite(previousDispatch.current_value)
        ? Number(previousDispatch.current_value)
        : null;
      const shouldSuppress = !(
        Number.isFinite(currentValue)
        && Number.isFinite(previousValue)
        && currentValue > previousValue
      );
      if (shouldSuppress) {
        const suppressedRecord = {
          code: alert.code,
          severity: alert.severity,
          metric: alert.metric,
          status: 'suppressed',
          reason: 'duplicate_in_dedupe_window'
        };
        records.push(suppressedRecord);
        try {
          appendKpiAnomalyDispatchAuditRecord(dataDir, {
            timestamp: nowTimestamp,
            fingerprint,
            code: alert.code,
            severity: alert.severity,
            metric: alert.metric,
            current_value: currentValue,
            status: 'suppressed',
            reason: suppressedRecord.reason,
            dedupe_window_seconds: normalizedDedupeWindowSeconds
          });
        } catch {
          // best-effort audit persistence
        }
        continue;
      }
    }

    const payload = {
      type: 'kpi.anomaly.alert',
      timestamp: nowTimestamp,
      alert,
      summary: {
        window_seconds: summary.window_seconds,
        baseline_window_seconds: summary.baseline_window_seconds,
        total_alerts: summary.total_alerts
      }
    };

    try {
      await webhookSender(webhookURL, payload);
      const dispatchedRecord = {
        code: alert.code,
        severity: alert.severity,
        metric: alert.metric,
        status: 'dispatched'
      };
      records.push(dispatchedRecord);
      dedupeStateByFingerprint.set(fingerprint, {
        timestamp: nowTimestamp,
        current_value: currentValue
      });
      try {
        appendKpiAnomalyDispatchAuditRecord(dataDir, {
          timestamp: nowTimestamp,
          fingerprint,
          code: alert.code,
          severity: alert.severity,
          metric: alert.metric,
          current_value: currentValue,
          status: 'dispatched',
          dedupe_window_seconds: normalizedDedupeWindowSeconds
        });
      } catch {
        // best-effort audit persistence
      }
    } catch (error) {
      const failedRecord = {
        code: alert.code,
        severity: alert.severity,
        metric: alert.metric,
        status: 'failed',
        error: error?.message || 'dispatch failed'
      };
      records.push(failedRecord);
      try {
        appendKpiAnomalyDispatchAuditRecord(dataDir, {
          timestamp: nowTimestamp,
          fingerprint,
          code: alert.code,
          severity: alert.severity,
          metric: alert.metric,
          current_value: currentValue,
          status: 'failed',
          reason: failedRecord.error,
          dedupe_window_seconds: normalizedDedupeWindowSeconds
        });
      } catch {
        // best-effort audit persistence
      }
    }
  }
  return records;
}

function buildKpiTimeseries(dataDir, {
  windowSeconds = 86400,
  bucketSeconds = 3600,
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const effectiveBucketSeconds = Math.max(1, Math.min(bucketSeconds, windowSeconds));
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const bucketCount = Math.max(1, Math.ceil(windowSeconds / effectiveBucketSeconds));
  const eventRecords = loadKpiEventRecords(dataDir);
  const cursorOperationRecords = loadCursorOperationRecords(dataDir);
  const securityAlerts = loadEnrichedSecurityAlertsForKpi(dataDir);
  const buckets = [];

  for (let index = 0; index < bucketCount; index += 1) {
    const bucketStart = startTimestamp + (index * effectiveBucketSeconds);
    const bucketEnd = Math.min(bucketStart + effectiveBucketSeconds - 1, endTimestamp);
    const summary = createEmptyKpiSummary({
      windowSeconds: bucketEnd - bucketStart + 1,
      startTimestamp: bucketStart,
      endTimestamp: bucketEnd
    });
    accumulateKpiSummaryFromRecords(summary, eventRecords, {
      startTimestamp: bucketStart,
      endTimestamp: bucketEnd
    });
    accumulateCursorOperationKpi(summary, cursorOperationRecords, {
      startTimestamp: bucketStart,
      endTimestamp: bucketEnd
    });
    applySecurityAlertSummaryToKpi(
      summary,
      buildSecurityAlertSummary(securityAlerts, {
        windowSeconds: bucketEnd - bucketStart + 1,
        nowTimestamp: bucketEnd
      })
    );
    buckets.push({
      start_timestamp: bucketStart,
      end_timestamp: bucketEnd,
      kpi: summary
    });
  }

  return {
    window_seconds: windowSeconds,
    bucket_seconds: effectiveBucketSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    buckets
  };
}

function kpiSessionSortValue(session, sortBy) {
  switch (sortBy) {
    case 'last_timestamp':
      return session.last_timestamp;
    case 'task_completed':
      return session.kpi?.task?.completed ?? 0;
    case 'task_failed':
      return session.kpi?.task?.failed ?? 0;
    case 'approval_decided':
      return session.kpi?.approval?.decided ?? 0;
    case 'approval_pending':
      return session.kpi?.approval?.pending ?? 0;
    case 'system_errors':
      return session.kpi?.reliability?.system_errors ?? 0;
    case 'session_id':
      return session.session_id;
    case 'total_events':
    default:
      return session.total_events;
  }
}

function buildKpiSessionsBreakdown(dataDir, {
  windowSeconds = 3600,
  limit = 20,
  offset = 0,
  source = 'all',
  risk = 'all',
  search = '',
  sortBy = 'total_events',
  sortOrder = 'desc',
  presetApplied = 'all',
  nowTimestamp = Math.floor(Date.now() / 1000)
} = {}) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const maxSessions = Math.max(1, Math.min(limit, 100));
  const startOffset = Math.max(0, offset);
  const normalizedSource = typeof source === 'string' ? source.trim().toLowerCase() : 'all';
  const normalizedRisk = typeof risk === 'string' ? risk.trim().toLowerCase() : 'all';
  const normalizedSearch = typeof search === 'string' ? search.trim().toLowerCase() : '';
  const normalizedSortBy = normalizeKpiSessionSortBy(sortBy, 'total_events');
  const normalizedSortOrder = normalizeKpiSessionSortOrder(sortOrder, 'desc');
  const sortDirection = normalizedSortOrder === 'asc' ? 1 : -1;
  const eventRecords = loadKpiEventRecords(dataDir);
  const sessionRecords = new Map();

  for (const event of eventRecords) {
    const timestamp = Number.isFinite(event.timestamp)
      ? Math.floor(event.timestamp)
      : null;
    if (timestamp === null || timestamp < startTimestamp || timestamp > endTimestamp) {
      continue;
    }

    const sessionId = typeof event.session_id === 'string' && event.session_id.trim() !== ''
      ? event.session_id.trim()
      : 'unknown-session';
    if (!sessionRecords.has(sessionId)) {
      sessionRecords.set(sessionId, {
        session_id: sessionId,
        records: [],
        total_events: 0,
        last_timestamp: timestamp,
        source_counts: {},
        type_counts: {},
        risk_counts: {}
      });
    }

    const session = sessionRecords.get(sessionId);
    session.records.push(event);
    session.total_events += 1;
    session.last_timestamp = Math.max(session.last_timestamp, timestamp);
    incrementCounter(session.source_counts, typeof event.source === 'string' ? event.source : '');
    incrementCounter(session.type_counts, typeof event.type === 'string' ? event.type : '');
    incrementCounter(session.risk_counts, typeof event?.meta?.risk_level === 'string' ? event.meta.risk_level : 'none');
  }

  const filteredSessions = Array.from(sessionRecords.values())
    .map((session) => {
      const summary = createEmptyKpiSummary({
        windowSeconds,
        startTimestamp,
        endTimestamp
      });
      accumulateKpiSummaryFromRecords(summary, session.records, {
        startTimestamp,
        endTimestamp
      });
      return {
        session_id: session.session_id,
        last_timestamp: session.last_timestamp,
        total_events: session.total_events,
        source_counts: session.source_counts,
        type_counts: session.type_counts,
        risk_counts: session.risk_counts,
        kpi: summary
      };
    })
    .filter((session) => {
      if (normalizedSearch && !session.session_id.toLowerCase().includes(normalizedSearch)) {
        return false;
      }
      if (normalizedSource !== 'all') {
        const hasSource = Object.keys(session.source_counts).some((item) => item.toLowerCase() === normalizedSource);
        if (!hasSource) {
          return false;
        }
      }
      if (normalizedRisk !== 'all') {
        const hasRisk = Object.keys(session.risk_counts).some((item) => item.toLowerCase() === normalizedRisk);
        if (!hasRisk) {
          return false;
        }
      }
      return true;
    })
    .sort((left, right) => {
      const leftValue = kpiSessionSortValue(left, normalizedSortBy);
      const rightValue = kpiSessionSortValue(right, normalizedSortBy);
      if (typeof leftValue === 'string' || typeof rightValue === 'string') {
        const compare = String(leftValue).localeCompare(String(rightValue));
        if (compare !== 0) {
          return compare * sortDirection;
        }
      } else if (leftValue !== rightValue) {
        return (leftValue - rightValue) * sortDirection;
      }

      if (right.total_events !== left.total_events) {
        return right.total_events - left.total_events;
      }
      if (right.last_timestamp !== left.last_timestamp) {
        return right.last_timestamp - left.last_timestamp;
      }
      return left.session_id.localeCompare(right.session_id);
    });
  const totalSessions = filteredSessions.length;
  const sessions = filteredSessions.slice(startOffset, startOffset + maxSessions);
  const nextOffset = startOffset + sessions.length < totalSessions
    ? startOffset + sessions.length
    : null;

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    total_sessions: totalSessions,
    limit: maxSessions,
    offset: startOffset,
    next_offset: nextOffset,
    preset_applied: presetApplied,
    sort_by: normalizedSortBy,
    sort_order: normalizedSortOrder,
    sessions
  };
}

function normalizeKpiSessionProfileQuery(query = {}) {
  const idRaw = typeof query.id === 'string' ? query.id.trim() : '';
  const nameRaw = typeof query.name === 'string' ? query.name.trim() : '';
  const searchTextRaw = typeof query.searchText === 'string' ? query.searchText.trim() : '';
  const sourceRaw = typeof query.source === 'string' ? query.source.trim().toLowerCase() : '';
  const riskRaw = typeof query.risk === 'string' ? query.risk.trim().toLowerCase() : '';
  const presetRaw = typeof query.presetRaw === 'string' ? query.presetRaw.trim() : '';
  const sortFieldRaw = typeof query.sortFieldRaw === 'string' ? query.sortFieldRaw.trim() : '';
  const sortOrderRaw = typeof query.sortOrderRaw === 'string' ? query.sortOrderRaw.trim() : '';
  const parsedPageLimit = parsePositiveInt(query.pageLimit, 20);

  return {
    id: idRaw || randomUUID(),
    name: nameRaw || 'Untitled',
    searchText: searchTextRaw,
    source: sourceRaw || 'all',
    risk: riskRaw || 'all',
    presetRaw: KPI_SESSION_PROFILE_PRESET_RAW_VALUES.has(presetRaw) ? presetRaw : 'all',
    sortFieldRaw: KPI_SESSION_PROFILE_SORT_FIELD_RAW_VALUES.has(sortFieldRaw)
      ? sortFieldRaw
      : 'totalEvents',
    sortOrderRaw: KPI_SESSION_PROFILE_SORT_ORDER_RAW_VALUES.has(sortOrderRaw) ? sortOrderRaw : 'desc',
    pageLimit: KPI_SESSION_PROFILE_PAGE_LIMIT_VALUES.has(parsedPageLimit) ? parsedPageLimit : 20
  };
}

function parseKpiSessionProfileQueriesInput(value) {
  if (!Array.isArray(value)) {
    return {
      ok: false,
      error: 'invalid queries'
    };
  }
  const queries = [];
  for (const item of value) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      return {
        ok: false,
        error: 'invalid queries'
      };
    }
    queries.push(normalizeKpiSessionProfileQuery(item));
  }
  return {
    ok: true,
    queries
  };
}

function readPersistedKpiSessionProfile(profilePath) {
  if (!profilePath || !fs.existsSync(profilePath)) {
    return {
      queries: [],
      updated_at: null
    };
  }
  try {
    const raw = fs.readFileSync(profilePath, 'utf8');
    if (!raw.trim()) {
      return {
        queries: [],
        updated_at: null
      };
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return {
        queries: parsed
          .filter((item) => item && typeof item === 'object' && !Array.isArray(item))
          .map((item) => normalizeKpiSessionProfileQuery(item)),
        updated_at: null
      };
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {
        queries: [],
        updated_at: null
      };
    }
    return {
      queries: Array.isArray(parsed.queries)
        ? parsed.queries
          .filter((item) => item && typeof item === 'object' && !Array.isArray(item))
          .map((item) => normalizeKpiSessionProfileQuery(item))
        : [],
      updated_at: typeof parsed.updated_at === 'string' && parsed.updated_at.trim() !== ''
        ? parsed.updated_at
        : null
    };
  } catch {
    return {
      queries: [],
      updated_at: null
    };
  }
}

function writePersistedKpiSessionProfile(profilePath, queries = []) {
  const payload = {
    queries: Array.isArray(queries)
      ? queries.map((item) => normalizeKpiSessionProfileQuery(item))
      : [],
    updated_at: new Date().toISOString()
  };
  fs.mkdirSync(path.dirname(profilePath), { recursive: true });
  const tempPath = `${profilePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
  fs.renameSync(tempPath, profilePath);
  return payload;
}

function mergeKpiSessionProfileQueries(existing = [], incoming = []) {
  const existingNormalized = Array.isArray(existing)
    ? existing.map((item) => normalizeKpiSessionProfileQuery(item))
    : [];
  const incomingNormalized = Array.isArray(incoming)
    ? incoming.map((item) => normalizeKpiSessionProfileQuery(item))
    : [];
  const incomingIds = new Set(incomingNormalized.map((item) => item.id));
  const retainedExisting = existingNormalized.filter((item) => !incomingIds.has(item.id));
  return [...incomingNormalized, ...retainedExisting];
}

function timingSafeHexEqual(actualHex, expectedHex) {
  if (typeof actualHex !== 'string' || typeof expectedHex !== 'string') {
    return false;
  }
  if (!/^[a-fA-F0-9]{64}$/.test(actualHex) || !/^[a-fA-F0-9]{64}$/.test(expectedHex)) {
    return false;
  }
  const actualBuffer = Buffer.from(actualHex, 'hex');
  const expectedBuffer = Buffer.from(expectedHex, 'hex');
  if (actualBuffer.length !== expectedBuffer.length) {
    return false;
  }
  return timingSafeEqual(actualBuffer, expectedBuffer);
}

function createBridgeServer(options = {}) {
  const host = options.host || '127.0.0.1';
  const port = Number.isFinite(options.port) ? options.port : 24000;
  const dataDir = options.dataDir || path.join(process.cwd(), 'data');
  const codexTranscriptReader = typeof options.codexTranscriptReader === 'function'
    ? options.codexTranscriptReader
    : readCodexTranscriptSnapshot;
  const codexTranscriptHome = typeof options.home === 'string' && options.home.trim() !== ''
    ? options.home
    : os.homedir();
  const configuredCodexHome = options.codexHome ?? process.env.CODEX_HOME;
  const codexHome = typeof configuredCodexHome === 'string' && configuredCodexHome.trim() !== ''
    ? configuredCodexHome
    : undefined;
  const codexApprovalContextCache = new Map();
  const consoleDir = path.join(__dirname, 'console');
  const policyPath = typeof options.policyPath === 'string' && options.policyPath.trim() !== ''
    ? options.policyPath
    : path.join(dataDir, 'policy.json');
  const policyAuditPath = typeof options.policyAuditPath === 'string' && options.policyAuditPath.trim() !== ''
    ? options.policyAuditPath
    : path.join(dataDir, 'audit', 'policy-config.jsonl');
  const securityAlertPath = typeof options.securityAlertPath === 'string' && options.securityAlertPath.trim() !== ''
    ? options.securityAlertPath
    : path.join(dataDir, 'audit', 'security-alerts.jsonl');
  const securityAlertAckPath = typeof options.securityAlertAckPath === 'string' && options.securityAlertAckPath.trim() !== ''
    ? options.securityAlertAckPath
    : path.join(dataDir, 'audit', 'security-alert-acks.jsonl');
  const securityAlertEscalationPath = typeof options.securityAlertEscalationPath === 'string'
    && options.securityAlertEscalationPath.trim() !== ''
    ? options.securityAlertEscalationPath
    : path.join(dataDir, 'audit', 'security-alert-escalations.jsonl');
  const kpiSessionProfilePath = typeof options.kpiSessionProfilePath === 'string'
    && options.kpiSessionProfilePath.trim() !== ''
    ? options.kpiSessionProfilePath
    : path.join(dataDir, 'profiles', 'kpi-session-queries.json');
  const kpiAnomalyDispatchConfigPath = typeof options.kpiAnomalyDispatchConfigPath === 'string'
    && options.kpiAnomalyDispatchConfigPath.trim() !== ''
    ? options.kpiAnomalyDispatchConfigPath
    : path.join(dataDir, 'profiles', 'kpi-anomaly-dispatch.json');
  const policyConfigSigningSecret = typeof options.policyConfigSigningSecret === 'string'
    ? options.policyConfigSigningSecret
    : (typeof process.env.BRIDGE_POLICY_CONFIG_SIGNING_SECRET === 'string'
        ? process.env.BRIDGE_POLICY_CONFIG_SIGNING_SECRET
        : '');
  const policyConfigReplayWindowSeconds = parsePositiveInt(
    options.policyConfigReplayWindowSeconds ?? process.env.BRIDGE_POLICY_CONFIG_REPLAY_WINDOW_SECONDS,
    300
  );
  const cursorMaxAgeSeconds = parseNonNegativeInt(
    options.cursorMaxAgeSeconds ?? process.env.BRIDGE_CURSOR_MAX_AGE_SECONDS,
    604800
  );
  const policyConfigNonceCache = new Map();
  const agentRuntime = normalizeAgentRuntime(
    options.agentRuntime ?? process.env.BRIDGE_AGENT_RUNTIME,
    AGENT_RUNTIME_CODEX_CLI
  );
  const bridgeVersion = normalizeOptionalString(options.bridgeVersion, packageJson.version || 'unknown');
  const serverBootID = normalizeOptionalString(options.serverBootID, randomUUID());
  const hostToken = typeof options.hostToken === 'string'
    ? options.hostToken
    : (process.env.MOSHLINE_HOST_TOKEN || process.env.BRIDGE_HOST_TOKEN || '');
  const configuredHostID = normalizeOptionalString(options.hostID, os.hostname());
  const configuredAdvertisedAddress = normalizeOptionalString(options.advertisedAddress, host);
  const ownsSurfaceRegistry = !options.surfaceRegistry
    && (hostToken !== '' || options.ptyFactory);
  const surfaceRegistry = options.surfaceRegistry || (ownsSurfaceRegistry
    ? createSurfaceRegistry({
        serverBootID,
        ptyFactory: options.ptyFactory || loadNodePty(),
        surfaceIDFactory: options.surfaceIDFactory,
        now: options.surfaceNow
      })
    : null);
  const attachTicketStore = options.attachTicketStore || (surfaceRegistry
    ? createAttachTicketStore({
        ttlMs: options.attachTicketTTLms,
        now: options.attachTicketNow,
        randomBytesFactory: options.attachTicketRandomBytesFactory
      })
    : null);
  const controlSocketPath = normalizeOptionalString(
    options.controlSocketPath,
    surfaceRegistry ? (process.env.MOSHLINE_CONTROL_SOCKET || path.join(dataDir, 'moshline-host.sock')) : ''
  );
  const hostControlSocket = controlSocketPath && surfaceRegistry && attachTicketStore
    ? createHostControlSocket({
        socketPath: controlSocketPath,
        serverBootID,
        surfaceRegistry,
        attachTicketStore
      })
    : null;
  const multiplexerDiscovery = options.multiplexerDiscovery || createMultiplexerDiscovery();
  const boundedRepositoryReader = options.boundedRepositoryReader
    || createBoundedRepositoryReader();
  const sessionUploadStore = options.sessionUploadStore || createSessionUploadStore();
  const multiplexerCapabilities = [...new Set(
    (typeof multiplexerDiscovery.capabilities === 'function'
      ? multiplexerDiscovery.capabilities()
      : [])
      .filter((capability) => typeof capability === 'string'
        && capability.startsWith('multiplexer.'))
  )].sort();
  const repositoryCapabilities = typeof boundedRepositoryReader.selfCheck === 'function'
    && typeof boundedRepositoryReader.list === 'function'
    && typeof boundedRepositoryReader.read === 'function'
    ? ['files.read']
    : [];
  const uploadCapabilities = typeof sessionUploadStore.capabilities === 'function'
    ? sessionUploadStore.capabilities()
      .filter((capability) => typeof capability === 'string'
        && capability.startsWith('file.upload.'))
    : [];
  const hostCapabilities = [...new Set([
    ...HOST_SURFACE_CAPABILITIES,
    ...repositoryCapabilities,
    ...uploadCapabilities,
    ...multiplexerCapabilities
  ])];
  const hostSurfaceApi = createHostSurfaceApi({
    hostToken,
    serverBootID,
    surfaceRegistry,
    attachTicketStore,
    hostDescriptor: {
      host_id: configuredHostID,
      host_name: normalizeOptionalString(options.hostName, os.hostname()),
      address: configuredAdvertisedAddress,
      ssh_port: parsePositiveInt(options.sshPort, 22)
    },
    hostCapabilities,
    readJsonBody,
    sendJson
  });
  const boundedDiffReader = options.boundedDiffReader || createBoundedDiffReader();
  const notificationRoutingStore = options.notificationRoutingStore || createNotificationRoutingStore({
    filePath: path.join(dataDir, 'notification-rules.json')
  });
  const notificationDestinationStore = options.notificationDestinationStore
    || createNotificationDestinationStore({
      filePath: path.join(dataDir, 'notification-destination.json')
    });
  const productMetricStore = options.productMetricStore || createProductMetricStore({
    filePath: path.join(dataDir, 'metrics', 'product-events.jsonl')
  });
  const isConflictingPermissionDecision = (existingEvent, requestedDecision) => {
    const existing = typeof existingEvent?.payload?.decision === 'string'
      ? existingEvent.payload.decision.trim()
      : '';
    const requested = typeof requestedDecision === 'string' ? requestedDecision.trim() : '';
    return allowedDecisionSet.has(existing)
      && allowedDecisionSet.has(requested)
      && existing !== requested;
  };
  const recordIdempotencyViolation = (requestEventId) => {
    productMetricStore.append({
      event_id: randomUUID(),
      type: 'approval.idempotency_violation',
      timestamp: Math.floor(Date.now() / 1000),
      installation_id: configuredHostID,
      host_id: configuredHostID,
      flow_id: typeof requestEventId === 'string' ? requestEventId.trim() : null
    });
  };
  const codexRunnerFactory = options.codexRunnerFactory || createCodexSessionRunner;
  const codexLaunchResolver = options.codexLaunchResolver || resolveCodexLaunch;
  const codexRuntimeInspector = options.codexRuntimeInspector || inspectCodexRuntime;
  const piRunnerFactory = options.piRunnerFactory || createPiRpcSessionRunner;
  const piLaunchResolver = options.piLaunchResolver || resolvePiRpcLaunch;
  const piRuntimeInspector = options.piRuntimeInspector || inspectPiRuntime;
  const allowedDecisionSet = new Set(['approved', 'denied']);
  const allowedRuntimeCommandTypeSet = new Set(['prompt', 'steer', 'follow_up', 'abort', 'get_state']);
  const messageRequiredRuntimeCommandTypeSet = new Set(['prompt', 'steer', 'follow_up']);
  const optionPolicy = options.policy || {};
  const persistedPolicy = readPersistedPolicyConfig(policyPath);
  const persistedKpiAnomalyDispatchConfig = readPersistedKpiAnomalyDispatchConfig(
    kpiAnomalyDispatchConfigPath
  );
  const initialWhitelistCommands = Array.isArray(optionPolicy.whitelistCommands)
    ? optionPolicy.whitelistCommands
    : (Array.isArray(persistedPolicy.whitelist_commands) ? persistedPolicy.whitelist_commands : []);
  const initialEnforceHighRiskReason = typeof optionPolicy.enforceHighRiskReason === 'boolean'
    ? optionPolicy.enforceHighRiskReason
    : (persistedPolicy.enforce_high_risk_reason === true);
  const policyEngine = createPolicyEngine({
    ...optionPolicy,
    whitelistCommands: initialWhitelistCommands,
    enforceHighRiskReason: initialEnforceHighRiskReason
  });
  const codexSessions = new Map();
  const codexSessionAliasToBridgeSessionId = new Map();
  const storedHostSessionCache = new BoundedCache(parsePositiveInt(
    options.storedHostSessionCacheLimit
      ?? process.env.BRIDGE_STORED_SESSION_CACHE_LIMIT,
    256
  ));
  const approvalSessionByEventID = new BoundedCache(4096);
  const approvalDecisionByRequestEventID = new BoundedCache(4096);
  const approvalRelayActiveUntilByEventID = new BoundedCache(4096);
  const approvalDecisionWaiters = new Map();
  const onPermissionRequested = typeof options.onPermissionRequested === 'function'
    ? options.onPermissionRequested
    : null;
  let notificationWebhookURL = typeof options.notificationWebhookURL === 'string'
    ? options.notificationWebhookURL.trim()
    : (typeof process.env.BRIDGE_NOTIFICATION_WEBHOOK_URL === 'string'
        ? process.env.BRIDGE_NOTIFICATION_WEBHOOK_URL.trim()
        : notificationDestinationStore.get());
  const notificationWebhookSecret = typeof options.notificationWebhookSecret === 'string'
    ? options.notificationWebhookSecret
    : (typeof process.env.BRIDGE_NOTIFICATION_WEBHOOK_SECRET === 'string'
        ? process.env.BRIDGE_NOTIFICATION_WEBHOOK_SECRET
        : '');
  const notificationWebhookSender = typeof options.notificationWebhookSender === 'function'
    ? options.notificationWebhookSender
    : async (url, payload, requestOptions = {}) => {
      const headers = {
        'content-type': 'application/json',
        ...(requestOptions.headers || {})
      };
      const body = typeof requestOptions.body === 'string'
        ? requestOptions.body
        : JSON.stringify(payload);
      const response = await fetch(url, {
        method: 'POST',
        headers,
        body
      });
      if (!response.ok) {
        throw new Error(`notification webhook failed: HTTP ${response.status}`);
      }
    };
  const securityAlertWebhookURL = typeof options.securityAlertWebhookURL === 'string'
    ? options.securityAlertWebhookURL.trim()
    : (typeof process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_URL === 'string'
        ? process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_URL.trim()
        : '');
  let securityAlertWebhookMinSeverity = normalizeSecurityAlertSeverity(
    options.securityAlertWebhookMinSeverity
      ?? persistedPolicy.security_alert_webhook_min_severity
      ?? process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_MIN_SEVERITY,
    'high'
  );
  let securityAlertWebhookCodeAllowlist = normalizeSecurityAlertCodeAllowlist(
    Array.isArray(options.securityAlertWebhookCodeAllowlist)
      ? options.securityAlertWebhookCodeAllowlist
      : (Array.isArray(persistedPolicy.security_alert_webhook_code_allowlist)
          ? persistedPolicy.security_alert_webhook_code_allowlist
          : (typeof process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_CODE_ALLOWLIST === 'string'
              ? process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_CODE_ALLOWLIST.split(',')
              : []))
  );
  let securityAlertWebhookRoutes = normalizeSecurityAlertWebhookRoutes(
    Array.isArray(options.securityAlertWebhookRoutes)
      ? options.securityAlertWebhookRoutes
      : (Array.isArray(persistedPolicy.security_alert_webhook_routes)
          ? persistedPolicy.security_alert_webhook_routes
          : parseSecurityAlertWebhookRoutesFromEnv(process.env.BRIDGE_SECURITY_ALERT_WEBHOOK_ROUTES))
  );
  const securityAlertWebhookSender = typeof options.securityAlertWebhookSender === 'function'
    ? options.securityAlertWebhookSender
    : async (url, payload) => {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error(`security alert webhook failed: HTTP ${response.status}`);
      }
    };
  const metricsAnomalyWebhookURL = typeof options.metricsAnomalyWebhookURL === 'string'
    ? options.metricsAnomalyWebhookURL.trim()
    : (typeof process.env.BRIDGE_METRICS_ANOMALY_WEBHOOK_URL === 'string'
        ? process.env.BRIDGE_METRICS_ANOMALY_WEBHOOK_URL.trim()
        : '');
  const metricsAnomalyWebhookSender = typeof options.metricsAnomalyWebhookSender === 'function'
    ? options.metricsAnomalyWebhookSender
    : async (url, payload) => {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error(`metrics anomaly webhook failed: HTTP ${response.status}`);
      }
    };
  let metricsAnomalyDispatchEnabled = parseBooleanInput(
    options.metricsAnomalyDispatchEnabled
      ?? persistedKpiAnomalyDispatchConfig.enabled
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_ENABLED,
    false
  );
  let metricsAnomalyDispatchIntervalSeconds = parseNonNegativeInt(
    options.metricsAnomalyDispatchIntervalSeconds
      ?? persistedKpiAnomalyDispatchConfig.interval_seconds
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_INTERVAL_SECONDS,
    0
  );
  let metricsAnomalyDispatchWindowSeconds = parsePositiveInt(
    options.metricsAnomalyDispatchWindowSeconds
      ?? persistedKpiAnomalyDispatchConfig.window_seconds
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_WINDOW_SECONDS,
    3600
  );
  let metricsAnomalyDispatchBaselineWindowSeconds = parsePositiveInt(
    options.metricsAnomalyDispatchBaselineWindowSeconds
      ?? persistedKpiAnomalyDispatchConfig.baseline_window_seconds
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_BASELINE_WINDOW_SECONDS,
    86400
  );
  let metricsAnomalyDispatchMinSeverity = normalizeSecurityAlertSeverity(
    options.metricsAnomalyDispatchMinSeverity
      ?? persistedKpiAnomalyDispatchConfig.min_severity
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_MIN_SEVERITY,
    'high'
  );
  let metricsAnomalyDispatchCodeAllowlist = normalizeSecurityAlertCodeAllowlist(
    Array.isArray(options.metricsAnomalyDispatchCodeAllowlist)
      ? options.metricsAnomalyDispatchCodeAllowlist
      : (Array.isArray(persistedKpiAnomalyDispatchConfig.code_allowlist)
          ? persistedKpiAnomalyDispatchConfig.code_allowlist
      : (typeof process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_CODE_ALLOWLIST === 'string'
          ? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_CODE_ALLOWLIST.split(',')
          : []))
  );
  let metricsAnomalyDispatchDedupeWindowSeconds = parseNonNegativeInt(
    options.metricsAnomalyDispatchDedupeWindowSeconds
      ?? persistedKpiAnomalyDispatchConfig.dedupe_window_seconds
      ?? process.env.BRIDGE_METRICS_ANOMALY_DISPATCH_DEDUPE_WINDOW_SECONDS,
    1800
  );
  const securityAlertEscalationWebhookURL = typeof options.securityAlertEscalationWebhookURL === 'string'
    ? options.securityAlertEscalationWebhookURL.trim()
    : (typeof process.env.BRIDGE_SECURITY_ALERT_ESCALATION_WEBHOOK_URL === 'string'
        ? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_WEBHOOK_URL.trim()
        : '');
  const securityAlertEscalationWebhookSender = typeof options.securityAlertEscalationWebhookSender === 'function'
    ? options.securityAlertEscalationWebhookSender
    : async (url, payload) => {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error(`security alert escalation webhook failed: HTTP ${response.status}`);
      }
    };
  let securityAlertEscalationEnabled = parseBooleanInput(
    options.securityAlertEscalationEnabled
      ?? persistedPolicy.security_alert_escalation_enabled
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_ENABLED,
    false
  );
  let securityAlertEscalationIntervalSeconds = parseNonNegativeInt(
    options.securityAlertEscalationIntervalSeconds
      ?? persistedPolicy.security_alert_escalation_interval_seconds
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_INTERVAL_SECONDS,
    0
  );
  let securityAlertEscalationAckDeadlineSeconds = parseNonNegativeInt(
    options.securityAlertEscalationAckDeadlineSeconds
      ?? persistedPolicy.security_alert_escalation_ack_deadline_seconds
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_ACK_DEADLINE_SECONDS,
    900
  );
  let securityAlertEscalationMinSeverity = normalizeSecurityAlertSeverity(
    options.securityAlertEscalationMinSeverity
      ?? persistedPolicy.security_alert_escalation_min_severity
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_MIN_SEVERITY,
    'high'
  );
  let securityAlertEscalationCodeAllowlist = normalizeSecurityAlertCodeAllowlist(
    Array.isArray(options.securityAlertEscalationCodeAllowlist)
      ? options.securityAlertEscalationCodeAllowlist
      : (Array.isArray(persistedPolicy.security_alert_escalation_code_allowlist)
          ? persistedPolicy.security_alert_escalation_code_allowlist
          : (typeof process.env.BRIDGE_SECURITY_ALERT_ESCALATION_CODE_ALLOWLIST === 'string'
              ? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_CODE_ALLOWLIST.split(',')
              : []))
  );
  let securityAlertEscalationActor = normalizeOptionalString(
    options.securityAlertEscalationActor
      ?? persistedPolicy.security_alert_escalation_actor
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_ACTOR,
    'nomad-auto'
  );
  let securityAlertEscalationNote = typeof (
    options.securityAlertEscalationNote
      ?? persistedPolicy.security_alert_escalation_note
      ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_NOTE
  ) === 'string'
    ? (
      options.securityAlertEscalationNote
        ?? persistedPolicy.security_alert_escalation_note
        ?? process.env.BRIDGE_SECURITY_ALERT_ESCALATION_NOTE
    ).trim()
    : 'SLA breach';
  let securityAlertEscalationTimer = null;
  let metricsAnomalyDispatchTimer = null;
  let runtimeBaseUrl = `http://${host}:${port}`;

  function normalizeRuntimeSessionId(value, defaultValue = UNKNOWN_SESSION_ID) {
    return normalizeOptionalString(value, defaultValue);
  }

  function setCodexSessionAlias(bridgeSessionId, codexSessionId) {
    const normalizedBridgeSessionId = normalizeOptionalString(bridgeSessionId, '');
    const normalizedCodexSessionId = normalizeOptionalString(codexSessionId, '');
    if (!normalizedBridgeSessionId
      || !normalizedCodexSessionId
      || normalizedCodexSessionId === normalizedBridgeSessionId
      || normalizedCodexSessionId === UNKNOWN_SESSION_ID) {
      return;
    }
    const entry = codexSessions.get(normalizedBridgeSessionId);
    if (!entry) {
      return;
    }
    const previousCodexSessionId = normalizeOptionalString(entry.codex_session_id, '');
    if (previousCodexSessionId
      && previousCodexSessionId !== normalizedCodexSessionId
      && codexSessionAliasToBridgeSessionId.get(previousCodexSessionId) === normalizedBridgeSessionId) {
      codexSessionAliasToBridgeSessionId.delete(previousCodexSessionId);
    }
    entry.codex_session_id = normalizedCodexSessionId;
    codexSessionAliasToBridgeSessionId.set(normalizedCodexSessionId, normalizedBridgeSessionId);
  }

  function clearCodexSessionAliases(bridgeSessionId) {
    const normalizedBridgeSessionId = normalizeOptionalString(bridgeSessionId, '');
    if (!normalizedBridgeSessionId) {
      return;
    }
    const entry = codexSessions.get(normalizedBridgeSessionId);
    if (!entry) {
      return;
    }
    const codexSessionId = normalizeOptionalString(entry.codex_session_id, '');
    if (codexSessionId
      && codexSessionAliasToBridgeSessionId.get(codexSessionId) === normalizedBridgeSessionId) {
      codexSessionAliasToBridgeSessionId.delete(codexSessionId);
    }
  }

  function resolveCodexSessionLookup(sessionKey) {
    const normalizedSessionKey = normalizeOptionalString(sessionKey, '');
    if (!normalizedSessionKey) {
      return null;
    }

    if (codexSessions.has(normalizedSessionKey)) {
      return {
        bridge_session_id: normalizedSessionKey,
        entry: codexSessions.get(normalizedSessionKey)
      };
    }

    const bridgedSessionId = codexSessionAliasToBridgeSessionId.get(normalizedSessionKey);
    if (!bridgedSessionId || !codexSessions.has(bridgedSessionId)) {
      return null;
    }
    return {
      bridge_session_id: bridgedSessionId,
      entry: codexSessions.get(bridgedSessionId)
    };
  }

  function buildCodexSessionRuntimePayload(bridgeSessionId, entry) {
    const normalizedBridgeSessionId = normalizeRuntimeSessionId(bridgeSessionId);
    const codexSessionId = normalizeOptionalString(entry?.codex_session_id, '');
    const piSessionId = normalizeOptionalString(entry?.pi_session_id, '');
    const sessionFile = normalizeOptionalString(entry?.session_file, '');
    const runtime = normalizeAgentRuntime(entry?.runtime, AGENT_RUNTIME_CODEX_CLI);
    return {
      session_id: normalizedBridgeSessionId,
      bridge_session_id: normalizedBridgeSessionId,
      codex_session_id: codexSessionId || null,
      pi_session_id: piSessionId || null,
      session_file: sessionFile || null,
      provider: runtime,
      runtime,
      pid: entry.runner.pid(),
      running: entry.runner.isRunning(),
      mode: entry.mode || 'cli',
      command: entry.command || '',
      args: Array.isArray(entry.args) ? entry.args : [],
      cwd: entry.cwd || '',
      mcp_subcommand: entry.mcp_subcommand || null,
      started_at: Number.isFinite(entry.started_at) ? entry.started_at : null
    };
  }

  function buildHostSessionSnapshot(sessionId, metadata) {
    const resolvedSessionId = normalizeRuntimeSessionId(metadata.session_id || sessionId);
    const provider = normalizeOptionalString(metadata.provider, 'unknown');
    const state = normalizeOptionalString(metadata.state, 'idle');
    const lastEventTimestamp = Date.parse(metadata.last_event_at || '');
    const hostName = normalizeOptionalString(metadata.host_name, os.hostname());
    const hostId = normalizeOptionalString(metadata.host_id, process.env.NOMAD_HOST_ID || hostName);
    const capabilities = Array.isArray(metadata.capabilities)
      ? [...metadata.capabilities]
      : [];
    if (capabilities.includes('repository.read')
      && boundedRepositoryReader.selfCheck(metadata.cwd)
      && !capabilities.includes('files.read')) {
      capabilities.push('files.read');
    }
    return {
      schema_version: 2,
      session_id: resolvedSessionId,
      bridge_session_id: resolvedSessionId,
      agent_run_id: normalizeOptionalString(metadata.agent_run_id, resolvedSessionId),
      provider_session_id: normalizeOptionalString(metadata.provider_session_id, null),
      surface_id: normalizeOptionalString(metadata.surface_id, null),
      provider,
      runtime: provider,
      running: state === 'running' || state === 'waiting',
      mode: 'host-helper',
      command: '',
      args: [],
      cwd: normalizeOptionalString(metadata.cwd, ''),
      started_at: Number.isFinite(lastEventTimestamp) ? Math.floor(lastEventTimestamp / 1000) : null,
      state,
      pending_count: Number.isFinite(metadata.pending_count) ? metadata.pending_count : 0,
      last_event_at: normalizeOptionalString(metadata.last_event_at, null),
      last_event_summary: normalizeOptionalString(metadata.summary, ''),
      host_id: hostId || null,
      host_name: hostName || null,
      connection_id: normalizeOptionalString(metadata.connection_id, null),
      project_name: normalizeOptionalString(metadata.project_name, null),
      tmux_session: normalizeOptionalString(metadata.tmux_session, null),
      tmux_window: normalizeOptionalString(metadata.tmux_window, null),
      tmux_pane: normalizeOptionalString(metadata.tmux_pane, null),
      terminal_target: normalizeOptionalString(metadata.terminal_target, null),
      capabilities,
      ...(metadata.usage ? { usage: metadata.usage } : {}),
      terminal_route: metadata.terminal_route || {
        kind: 'unavailable',
        confidence: 'unavailable',
        observed_at: null,
        server_boot_id: null,
        surface_id: null,
        multiplexer: null
      }
    };
  }

  function verifyHostSessionMetadata(metadata) {
    const route = metadata?.terminal_route;
    if (!surfaceRegistry || !route || route.kind !== 'persistent_pty') {
      return metadata;
    }
    const surfaceId = normalizeOptionalString(metadata.surface_id, '');
    const sessionId = normalizeOptionalString(metadata.session_id, '');
    const registered = surfaceId ? surfaceRegistry.get(surfaceId) : null;
    if (!registered
      || registered.state !== 'running'
      || registered.surface_id !== route.surface_id
      || registered.server_boot_id !== serverBootID
      // Only the session that first claimed this daemon-owned surface may earn a
      // verified route to it. A session reporting another session's surface_id
      // (e.g. an inherited MOSHLINE_SURFACE_ID) stays at observed confidence, so
      // Open Terminal can never attach to a PTY the session does not own.
      || !sessionId
      || registered.claimed_session_id !== sessionId) {
      return metadata;
    }
    return {
      ...metadata,
      terminal_route: {
        ...route,
        confidence: 'verified',
        observed_at: registered.updated_at || route.observed_at,
        server_boot_id: serverBootID,
        surface_id: registered.surface_id
      }
    };
  }

  function projectStoredHostSession(events) {
    return projectHostSession(events, { requireExplicitManualApproval: true });
  }

  function makeStoredHostSessionCacheEntry(events) {
    const metadata = projectStoredHostSession(events);
    const retainsEvents = metadata.state !== 'completed' && metadata.state !== 'failed';
    return {
      metadata,
      is_internal_ambient: isInternalCodexAmbientSession(events),
      events: retainsEvents ? boundedSessionEvents(events, 1000) : null
    };
  }

  function loadStoredHostSession(sessionId) {
    const cached = storedHostSessionCache.get(sessionId);
    if (cached) {
      return cached;
    }
    const events = listSessionEvents(dataDir, sessionId, { limit: 1000 });
    if (events.length === 0) {
      return null;
    }
    const entry = makeStoredHostSessionCacheEntry(events);
    storedHostSessionCache.set(sessionId, entry);
    return entry;
  }

  function storedHostSessionMetadata(sessionId) {
    return loadStoredHostSession(sessionId)?.metadata ?? projectStoredHostSession([]);
  }

  function approvalDecisionPayload(event) {
    if (!event || event.type !== 'permission.decided') {
      return null;
    }
    const decision = normalizeOptionalString(event.payload?.decision, '').toLowerCase();
    if (!allowedDecisionSet.has(decision)) {
      return null;
    }
    return {
      ok: true,
      decision,
      actor: normalizeOptionalString(event.payload?.actor, 'unknown'),
      reason: normalizeOptionalString(event.payload?.reason, '')
    };
  }

  function isBridgeRelayPermissionRequest(event) {
    return event?.type === 'permission.requested'
      && normalizeOptionalString(event.payload?.approval_scope, '').toLowerCase() === 'bridge_relay';
  }

  function approvalRelayDeadlineMilliseconds(event) {
    const parsed = Date.parse(normalizeOptionalString(event?.payload?.relay_expires_at, ''));
    return Number.isFinite(parsed) ? parsed : Date.now() + (110 * 1000);
  }

  function renewApprovalRelayLease(requestEventID, event) {
    if (!isBridgeRelayPermissionRequest(event) || isHostLocalPermissionRequest(event)) {
      approvalRelayActiveUntilByEventID.set(requestEventID, 0);
      return false;
    }
    const activeUntil = Math.min(
      approvalRelayDeadlineMilliseconds(event),
      Date.now() + 30_000
    );
    approvalRelayActiveUntilByEventID.set(requestEventID, activeUntil);
    return activeUntil > Date.now();
  }

  function isApprovalRelayActive(requestEventID, event) {
    if (!isBridgeRelayPermissionRequest(event) || isHostLocalPermissionRequest(event)) {
      return false;
    }
    const activeUntil = approvalRelayActiveUntilByEventID.get(requestEventID);
    return Number.isFinite(activeUntil) && activeUntil > Date.now();
  }

  function settleApprovalDecisionWaiters(requestEventID, decision) {
    const waiters = approvalDecisionWaiters.get(requestEventID);
    if (!waiters) {
      return;
    }
    approvalDecisionWaiters.delete(requestEventID);
    for (const settle of waiters) {
      settle(decision);
    }
  }

  function waitForApprovalDecision(requestEventID, waitMilliseconds, { signal } = {}) {
    const existing = approvalDecisionByRequestEventID.get(requestEventID);
    if (existing) {
      return Promise.resolve(existing);
    }
    if (waitMilliseconds <= 0 || signal?.aborted) {
      return Promise.resolve(null);
    }
    return new Promise((resolve) => {
      let timer = null;
      let settled = false;
      const settle = (decision) => {
        if (settled) {
          return;
        }
        settled = true;
        if (timer) {
          clearTimeout(timer);
        }
        signal?.removeEventListener('abort', onAbort);
        const waiters = approvalDecisionWaiters.get(requestEventID);
        waiters?.delete(settle);
        if (waiters?.size === 0) {
          approvalDecisionWaiters.delete(requestEventID);
        }
        resolve(decision);
      };
      const onAbort = () => settle(null);
      timer = setTimeout(() => settle(null), waitMilliseconds);
      signal?.addEventListener('abort', onAbort, { once: true });
      const waiters = approvalDecisionWaiters.get(requestEventID) || new Set();
      waiters.add(settle);
      approvalDecisionWaiters.set(requestEventID, waiters);
      const racedDecision = approvalDecisionByRequestEventID.get(requestEventID);
      if (racedDecision) {
        settle(racedDecision);
      }
    });
  }

  function releaseApprovalDecisionWaiters() {
    for (const waiters of approvalDecisionWaiters.values()) {
      for (const settle of waiters) {
        settle(null);
      }
    }
    approvalDecisionWaiters.clear();
  }

  function appendStoredSessionEvent(event, { settleApprovalRelay = false } = {}) {
    appendSessionEvent(dataDir, event);
    const sessionId = normalizeRuntimeSessionId(event?.session_id, '');
    if (!sessionId) {
      return;
    }
    const eventID = normalizeOptionalString(event?.id || event?.event_id, '');
    if (event?.type === 'permission.requested' && eventID) {
      approvalSessionByEventID.set(eventID, sessionId);
      if (isBridgeRelayPermissionRequest(event)) {
        // The relay is activated only when the blocking hook starts polling.
        // Merely accepting the event is not enough: the hook may disconnect
        // before reading this response and immediately fall back to the host.
        approvalRelayActiveUntilByEventID.set(eventID, 0);
      }
    } else if (settleApprovalRelay && event?.type === 'permission.decided') {
      const requestEventID = normalizeOptionalString(event.payload?.request_event_id, '');
      const decision = approvalDecisionPayload(event);
      const requestEvent = requestEventID
        ? findSessionEventById(dataDir, sessionId, requestEventID)
        : null;
      if (requestEvent?.type === 'permission.requested' && decision) {
        approvalRelayActiveUntilByEventID.set(requestEventID, 0);
        approvalDecisionByRequestEventID.set(requestEventID, decision);
        settleApprovalDecisionWaiters(requestEventID, decision);
      }
    }
    const cached = storedHostSessionCache.get(sessionId);
    if (!cached || !Array.isArray(cached.events)) {
      storedHostSessionCache.delete(sessionId);
      return;
    }
    storedHostSessionCache.set(
      sessionId,
      makeStoredHostSessionCacheEntry([...cached.events, event])
    );
  }

  function buildHostSessionSnapshots() {
    const managedSessionIds = new Set(codexSessions.keys());
    return listSessionIds(dataDir)
      .filter((sessionId) => !managedSessionIds.has(sessionId))
      .map((sessionId) => {
        const cached = loadStoredHostSession(sessionId);
        if (!cached || cached.is_internal_ambient) {
          return null;
        }
        const metadata = verifyHostSessionMetadata(cached.metadata);
        return buildHostSessionSnapshot(sessionId, metadata);
      })
      .filter(Boolean);
  }

  function ingestCodexRunnerEvent(bridgeSessionId, runtimeGeneration, event) {
    const normalizedBridgeSessionId = normalizeRuntimeSessionId(bridgeSessionId);
    const entry = codexSessions.get(normalizedBridgeSessionId);
    if (!entry
      || entry.runtime_generation !== runtimeGeneration
      || !event
      || typeof event !== 'object'
      || Array.isArray(event)) {
      return;
    }

    const observedSessionId = normalizeOptionalString(event.session_id, '');
    if (observedSessionId
      && observedSessionId !== normalizedBridgeSessionId
      && observedSessionId !== UNKNOWN_SESSION_ID) {
      setCodexSessionAlias(normalizedBridgeSessionId, observedSessionId);
    }
    const codexSessionId = normalizeOptionalString(entry.codex_session_id, '');
    const mergedMeta = event.meta && typeof event.meta === 'object' && !Array.isArray(event.meta)
      ? { ...event.meta }
      : {};
    if (codexSessionId) {
      mergedMeta.codex_session_id = codexSessionId;
    }
    const storedEvent = {
      ...event,
      session_id: normalizedBridgeSessionId,
      meta: mergedMeta
    };
    if (storedEvent.type === 'permission.requested') {
      const requestId = normalizeOptionalString(storedEvent.payload?.request_id, '');
      const requestEventId = normalizeOptionalString(storedEvent.id, '');
      if (requestId && requestEventId) {
        entry.outstandingElicitationByRequestId.set(requestId, requestEventId);
        entry.respondedDecisionByRequestId.delete(requestId);
      }
    }
    appendAndDispatch(storedEvent);
  }

  function appendCodexLifecycleEvent(sessionId, eventType, payload = {}, traceId) {
    const event = normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: eventType,
      payload,
      trace_id: traceId
    });
    appendAndDispatch(event);
    return event;
  }

  function buildPermissionNotificationPayload(event) {
    const payload = event.payload && typeof event.payload === 'object' && !Array.isArray(event.payload)
      ? event.payload
      : {};
    const toolInput = payload.tool_input && typeof payload.tool_input === 'object'
      && !Array.isArray(payload.tool_input)
      ? payload.tool_input
      : {};
    const command = normalizeOptionalString(
      payload.command || toolInput.command || toolInput.cmd,
      ''
    );
    const cwd = normalizeOptionalString(payload.cwd, '');
    const riskLevel = normalizeOptionalString(payload.risk_level || event.meta?.risk_level, '');
    const provider = normalizeOptionalString(event.source, '');
    const agentRunId = normalizeOptionalString(
      payload.agent_run_id || event.meta?.agent_run_id || event.agent_run_id,
      ''
    );
    const userFacingDescription = normalizeOptionalString(
      toolInput.description || payload.description || payload.message || payload.summary || payload.text,
      ''
    );
    const questionDetail = firstQuestionText(toolInput);
    const permissionDetail = userFacingDescription || questionDetail || command || 'Permission required';
    const isHostLocalApproval = isHostLocalPermissionRequest(event);
    const isBypassModeException = isBypassPermissionsMode(event.source, payload);
    const isUserInputRequest = isUserInputPermissionRequest(payload);
    const message = isHostLocalApproval
      ? (isUserInputRequest
        ? `Answer on Mac: ${permissionDetail}`
        : (isBypassModeException
          ? `Safety check on Mac: ${permissionDetail}`
          : `Confirm on Mac: ${permissionDetail}`))
      : `Approval required: ${permissionDetail}`;
    const notificationPayload = {
      title: notificationTitle(event),
      message,
      // Relayable requests carry request_event_id below and become actionable
      // APNS notifications. Host-local provider prompts stay read-only.
      category: isHostLocalApproval ? 'local_approval_required' : 'approval_update',
      session_id: event.session_id,
      host_id: normalizeOptionalString(payload.host_id, configuredHostID),
      provider,
      bridge_base_url: runtimeBaseUrl
    };
    if (agentRunId) {
      notificationPayload.agent_run_id = agentRunId;
    }
    const requestId = normalizeOptionalString(payload.request_id, '');
    if (requestId) {
      notificationPayload.request_id = requestId;
    }
    if (command) {
      notificationPayload.command = command;
    }
    if (cwd) {
      notificationPayload.cwd = cwd;
    }
    if (riskLevel) {
      notificationPayload.risk_level = riskLevel;
    }
    if (!isHostLocalApproval && normalizeOptionalString(event.id, '')) {
      notificationPayload.request_event_id = event.id;
    }
    return notificationPayload;
  }

  function tryAutoApproveWhitelistedPermission(event) {
    if (event.type !== 'permission.requested') {
      return false;
    }
    if (isHostLocalPermissionRequest(event)) {
      return false;
    }
    if (!event.payload || typeof event.payload !== 'object') {
      return false;
    }

    const policy = event.payload.policy;
    if (!policy || typeof policy !== 'object') {
      return false;
    }
    if (policy.requires_confirmation !== false) {
      return false;
    }

    const matchedRule = typeof policy.matched_rule === 'string' && policy.matched_rule.trim() !== ''
      ? policy.matched_rule
      : 'whitelist.command';
    const reason = `auto-approved by policy ${matchedRule}`;
    const requestId = typeof event.payload.request_id === 'string'
      ? event.payload.request_id.trim()
      : '';
    if (!requestId) {
      if (!isBridgeRelayPermissionRequest(event)) {
        return false;
      }
      const decisionEvent = buildPermissionDecisionEvent(event.session_id, {
        request_event_id: event.id,
        decision: 'approved',
        actor: 'policy',
        reason
      });
      appendStoredSessionEvent(decisionEvent, { settleApprovalRelay: true });
      return true;
    }

    const lookup = resolveCodexSessionLookup(event.session_id);
    if (!lookup) {
      return false;
    }
    const { bridge_session_id: bridgeSessionId, entry } = lookup;
    if (entry.respondedDecisionByRequestId.has(requestId)) {
      return true;
    }
    if (typeof entry.runner.respondElicitation !== 'function') {
      return false;
    }

    const accepted = entry.runner.respondElicitation(requestId, 'approved', reason);
    if (!accepted) {
      return false;
    }

    const decisionEvent = normalizeCodexMcpEvent({
      session_id: bridgeSessionId,
      event_type: 'permission_decision',
      payload: {
        request_id: requestId,
        request_event_id: event.id,
        decision: 'approved',
        actor: 'policy',
        reason,
        policy_rule: matchedRule
      }
    });
    appendStoredSessionEvent(decisionEvent);
    entry.outstandingElicitationByRequestId.delete(requestId);
    entry.respondedDecisionByRequestId.set(requestId, decisionEvent.id);
    return true;
  }

  function dispatchPermissionRequested(event) {
    if (event.type !== 'permission.requested') {
      const isTurnFinished = isTurnFinishedEvent(event);
      const routingEvent = isTurnFinished
        ? { ...event, type: 'task.completed' }
        : event;
      if ((!['task.completed', 'task.failed', 'session.ended'].includes(event.type) && !isTurnFinished)
        || !notificationWebhookURL
        || !notificationRoutingStore.shouldPush(routingEvent)) {
        return;
      }
      if ((isTurnFinished && event.payload?.background_work_active === true)
        || isInternalCodexAmbientTurnFinished(event)) {
        return;
      }
      const fallback = event.type === 'task.failed' ? 'Agent task failed' : 'Agent task completed';
      const rawSummary = event.payload?.summary
        || event.payload?.message
        || event.payload?.text
        || event.payload?.last_assistant_message
        || event.payload?.task_subject;
      if (isTurnFinished && !normalizeOptionalString(rawSummary, '')) {
        return;
      }
      const summary = notificationPreview(rawSummary, fallback);
      const payload = {
        title: notificationTitle(event),
        message: summary,
        category: isTurnFinished
          ? 'task_update'
          : (event.type === 'task.failed' ? 'task_failed' : 'task_completed'),
        session_id: event.session_id,
        host_id: normalizeOptionalString(event.payload?.host_id, configuredHostID),
        provider: normalizeOptionalString(event.source, ''),
        bridge_base_url: runtimeBaseUrl
      };
      notificationWebhookSender(
        notificationWebhookURL,
        payload,
        buildNotificationWebhookRequestOptions(payload)
      ).catch(() => {});
      return;
    }
    if (tryAutoApproveWhitelistedPermission(event)) {
      return;
    }
    if (event.payload?.requires_manual_approval === false
      && PROVIDER_NON_MANUAL_APPROVAL_CONTEXTS.has(event.payload?.approval_context)) {
      return;
    }
    // Approval requests are action-blocking: a routing rule must never silently
    // suppress them, or the agent stalls forever with no push and no
    // escalation. Notification muting applies to informational events only.
    const payload = buildPermissionNotificationPayload(event);
    const webhookRequestOptions = buildNotificationWebhookRequestOptions(payload);
    if (onPermissionRequested) {
      try {
        onPermissionRequested(event, payload);
      } catch {
        // ignore callback failures in optional hook
      }
    }
    if (notificationWebhookURL) {
      notificationWebhookSender(notificationWebhookURL, payload, webhookRequestOptions).catch(() => {});
    }
  }

  function isInternalCodexAmbientTurnFinished(event) {
    if (event.type !== 'task.step'
      || event.payload?.lifecycle !== 'turn.finished'
      || event.source !== 'codex'
      || event.payload?.transcript_path !== null) {
      return false;
    }
    const resultKind = codexAmbientResultKind(event.payload?.last_assistant_message);
    if (!resultKind) {
      return false;
    }
    const sessionEvents = listSessionEvents(dataDir, event.session_id, { limit: 1000 });
    return sessionEvents.some((sessionEvent) => sessionEvent.source === 'codex'
      && sessionEvent.type === 'task.started'
      && isCodexAmbientPrompt(sessionEvent.payload?.prompt, resultKind));
  }

  function buildNotificationWebhookRequestOptions(payload) {
    const body = JSON.stringify(payload);
    const headers = {
      'content-type': 'application/json'
    };
    const requestOptions = { headers, body };

    if (!notificationWebhookSecret) {
      return requestOptions;
    }

    const timestamp = Math.floor(Date.now() / 1000);
    const nonce = randomUUID();
    const signature = createHmac('sha256', notificationWebhookSecret)
      .update(`${timestamp}.${nonce}.${body}`)
      .digest('hex');

    headers['x-nomad-signature-version'] = 'v1';
    headers['x-nomad-timestamp'] = String(timestamp);
    headers['x-nomad-nonce'] = nonce;
    headers['x-nomad-signature'] = signature;

    requestOptions.algorithm = 'hmac-sha256-v1';
    requestOptions.timestamp = timestamp;
    requestOptions.nonce = nonce;
    requestOptions.signature = signature;
    return requestOptions;
  }

  // Event ingestion and session-metadata routes are reachable on whatever
  // interface the daemon binds to. Local agent hooks reach the bridge over
  // loopback and need no token; any non-loopback caller (a LAN peer that could
  // otherwise forge permission/approval events into a paired phone) must
  // present the host bearer token. This keeps forged events out of the Inbox
  // even when the operator binds the bridge to a non-loopback address.
  function requireLocalOrAuthenticated(req, res) {
    const remoteIp = req.socket?.remoteAddress || '';
    if (isLoopbackAddress(remoteIp)) {
      return true;
    }
    return hostSurfaceApi.authenticate(req, res);
  }

  function rejectHookApprovalDecision(event, res) {
    if (event?.type !== 'permission.decided') {
      return false;
    }
    sendJson(res, 409, {
      ok: false,
      error: 'approval decisions must use an approval response endpoint'
    });
    return true;
  }

  function appendAndDispatch(event, { settleApprovalRelay = false } = {}) {
    const evaluatedEvent = policyEngine.evaluateEvent(event);
    appendStoredSessionEvent(evaluatedEvent, { settleApprovalRelay });
    bindSurfaceSessionFromEvent(evaluatedEvent);
    dispatchPermissionRequested(evaluatedEvent);
  }

  function serverVerifiedAgentHookBody(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return body;
    }
    const source = typeof body.agent === 'string' ? body.agent.trim().toLowerCase() : '';
    if (source !== 'codex') {
      return body;
    }
    const rawPayload = body.payload && typeof body.payload === 'object'
      && !Array.isArray(body.payload)
      ? body.payload
      : {};
    const payload = { ...rawPayload };
    // This field crosses an HTTP trust boundary. Always discard the caller's
    // value and rebuild it from the local, session-bound Codex transcript.
    delete payload.verified_codex_turn_context;
    const eventType = typeof body.event_type === 'string' ? body.event_type.trim() : '';
    const isPermissionRequest = ['PermissionRequest', 'permission_request', 'permission.requested']
      .includes(eventType);
    if (!isPermissionRequest) {
      return { ...body, payload };
    }
    const transcriptPath = typeof payload.transcript_path === 'string'
      ? payload.transcript_path.trim()
      : '';
    const turnId = typeof payload.turn_id === 'string' ? payload.turn_id.trim() : '';
    const sessionId = typeof body.session_id === 'string' ? body.session_id.trim() : '';
    const agentId = typeof payload.agent_id === 'string' ? payload.agent_id.trim() : '';
    if (!transcriptPath || !turnId || !sessionId) {
      return { ...body, payload };
    }
    const transcriptIdentity = codexTranscriptIdentity(transcriptPath);
    if (!transcriptIdentity) {
      return { ...body, payload };
    }
    const cacheKey = JSON.stringify([
      transcriptIdentity.path,
      sessionId,
      agentId,
      turnId
    ]);
    let snapshot = cachedCodexApprovalSnapshot(cacheKey, transcriptIdentity);
    if (!snapshot) {
      try {
        snapshot = codexTranscriptReader(transcriptIdentity.path, {
          home: codexTranscriptHome,
          ...(codexHome ? { codexHome } : {}),
          sessionId,
          ...(agentId ? { agentId } : {}),
          turnId,
          deepApprovalScan: true
        });
      } catch {
        snapshot = null;
      }
    }
    const isVerified = snapshot?.transcriptPath === transcriptIdentity.path
      && snapshot?.sessionId === sessionId
      && (!agentId || snapshot?.agentId === agentId)
      && snapshot?.approvalContext;
    if (isVerified) {
      if (!codexApprovalContextCache.has(cacheKey)) {
        cacheCodexApprovalSnapshot(cacheKey, transcriptIdentity, snapshot);
      }
      payload.verified_codex_turn_context = snapshot.approvalContext;
    }
    return { ...body, payload };
  }

  function codexTranscriptIdentity(transcriptPath) {
    const canonicalPath = allowedTranscriptPath(transcriptPath, {
      home: codexTranscriptHome,
      ...(codexHome ? { codexHome } : {})
    });
    if (!canonicalPath) {
      return null;
    }
    try {
      const stat = fs.statSync(canonicalPath);
      if (!stat.isFile()) {
        return null;
      }
      return {
        path: canonicalPath,
        device: String(stat.dev),
        inode: String(stat.ino),
        birthtimeMs: stat.birthtimeMs,
        size: stat.size
      };
    } catch {
      return null;
    }
  }

  function cachedCodexApprovalSnapshot(cacheKey, identity) {
    const cached = codexApprovalContextCache.get(cacheKey);
    if (!cached) {
      return null;
    }
    const matchesIdentity = cached.device === identity.device
      && cached.inode === identity.inode
      && cached.birthtimeMs === identity.birthtimeMs
      && identity.size >= cached.verifiedSize;
    if (!matchesIdentity) {
      codexApprovalContextCache.delete(cacheKey);
      return null;
    }
    // Map insertion order is the LRU order. Refresh hits so active turns stay
    // cached while old completed turns age out at a fixed memory bound.
    codexApprovalContextCache.delete(cacheKey);
    codexApprovalContextCache.set(cacheKey, cached);
    return cached.snapshot;
  }

  function cacheCodexApprovalSnapshot(cacheKey, identity, snapshot) {
    codexApprovalContextCache.set(cacheKey, {
      device: identity.device,
      inode: identity.inode,
      birthtimeMs: identity.birthtimeMs,
      verifiedSize: identity.size,
      snapshot
    });
    while (codexApprovalContextCache.size > CODEX_APPROVAL_CONTEXT_CACHE_LIMIT) {
      const oldestKey = codexApprovalContextCache.keys().next().value;
      codexApprovalContextCache.delete(oldestKey);
    }
  }

  // Sticky-bind a daemon-owned surface to the first session that reports it, so
  // verifyHostSessionMetadata can reject cross-session surface claims.
  function bindSurfaceSessionFromEvent(event) {
    if (!surfaceRegistry) {
      return;
    }
    const surfaceId = normalizeOptionalString(
      event?.payload?.surface_id || event?.meta?.surface_id || event?.surface_id,
      ''
    );
    const sessionId = normalizeOptionalString(event?.session_id, '');
    if (surfaceId && sessionId) {
      surfaceRegistry.claimSession(surfaceId, sessionId);
    }
  }

  function normalizeReason(value) {
    if (typeof value !== 'string') {
      return '';
    }
    return value.trim();
  }

  function permissionAgentRunBindingError(sessionId, body) {
    const requestEvent = findSessionEventById(dataDir, sessionId, body?.request_event_id);
    const submittedAgentRunId = normalizeOptionalString(body?.agent_run_id, '');
    if (!requestEvent || requestEvent.type !== 'permission.requested') {
      return 'approval request not found';
    }
    if (isHostLocalPermissionRequest(requestEvent)) {
      return 'approval must be confirmed on the host';
    }
    const expectedAgentRunId = normalizeOptionalString(
      requestEvent?.payload?.agent_run_id
        || requestEvent?.meta?.agent_run_id
        || requestEvent?.agent_run_id,
      ''
    );
    // Only enforce the binding when the client actually asserted an agent run.
    // A decision that omits agent_run_id (older iOS builds, CLI/curl callers)
    // must still be accepted and left to the idempotency layer, rather than
    // 409'd out of ever approving.
    if (!expectedAgentRunId || !submittedAgentRunId) {
      return null;
    }
    return submittedAgentRunId === expectedAgentRunId ? null : 'agent run mismatch';
  }

  function managedElicitationBindingError({
    entry,
    sessionId,
    requestId,
    requestEventId
  }) {
    if (!requestEventId) {
      return 'missing request_event_id';
    }
    const requestEvent = findSessionEventById(dataDir, sessionId, requestEventId);
    if (!requestEvent || requestEvent.type !== 'permission.requested') {
      return 'approval request not found';
    }
    const eventRequestId = normalizeOptionalString(requestEvent.payload?.request_id, '');
    if (!eventRequestId || eventRequestId !== requestId) {
      return 'approval request does not match provider request';
    }
    if (entry.outstandingElicitationByRequestId.get(requestId) === requestEventId) {
      return null;
    }
    const respondedEventId = entry.respondedDecisionByRequestId.get(requestId);
    const respondedEvent = respondedEventId
      ? findSessionEventById(dataDir, sessionId, respondedEventId)
      : null;
    if (normalizeOptionalString(respondedEvent?.payload?.request_event_id, '') === requestEventId) {
      return null;
    }
    return 'provider request is not outstanding in the current runtime';
  }

  function resolveRiskLevelForRequestEvent(sessionId, requestEventId) {
    if (typeof requestEventId !== 'string' || requestEventId.trim() === '') {
      return null;
    }
    const requestEvent = findSessionEventById(dataDir, sessionId, requestEventId);
    if (!requestEvent || requestEvent.type !== 'permission.requested') {
      return null;
    }
    const payloadRisk = requestEvent?.payload?.policy?.risk_level;
    if (typeof payloadRisk === 'string' && payloadRisk.trim() !== '') {
      return payloadRisk.trim().toLowerCase();
    }
    const metaRisk = requestEvent?.meta?.risk_level;
    if (typeof metaRisk === 'string' && metaRisk.trim() !== '') {
      return metaRisk.trim().toLowerCase();
    }
    return 'none';
  }

  function requiresApprovalReason({ sessionId, decision, requestEventId }) {
    if (!policyEngine.enforceHighRiskReason()) {
      return false;
    }
    if (decision !== 'approved') {
      return false;
    }

    const riskLevel = resolveRiskLevelForRequestEvent(sessionId, requestEventId);
    if (riskLevel === null) {
      return true;
    }
    return riskLevel === 'high' || riskLevel === 'critical';
  }

  function appendPolicyGateRejectionEvent(sessionId, payload = {}) {
    const event = {
      spec_version: 'nomad.event.v1',
      id: randomUUID(),
      session_id: typeof sessionId === 'string' && sessionId.trim() !== ''
        ? sessionId
        : 'unknown-session',
      source: 'nomad-agent',
      type: 'system.error',
      timestamp: Math.floor(Date.now() / 1000),
      payload: {
        code: 'policy.reason_required',
        message: 'Approval reason required for high-risk request',
        ...payload
      },
      meta: {
        trace_id: randomUUID(),
        risk_level: 'high'
      }
    };
    appendStoredSessionEvent(event);
    dispatchSecurityAlert({
      type: 'security.alert',
      code: 'policy.reason_required',
      severity: 'high',
      timestamp: event.timestamp,
      detail: {
        session_id: event.session_id,
        request_id: event?.payload?.request_id || null,
        request_event_id: event?.payload?.request_event_id || null,
        endpoint: event?.payload?.endpoint || null,
        decision: event?.payload?.decision || null,
        trace_id: event?.meta?.trace_id || null
      }
    });
    return event;
  }

  function appendPolicyAudit(action, payload = {}, meta = {}) {
    const record = {
      id: randomUUID(),
      action,
      timestamp: Math.floor(Date.now() / 1000),
      payload,
      meta
    };
    appendPolicyAuditRecord(policyAuditPath, record);
    dispatchSecurityAlertForPolicyAudit(record);
    return record;
  }

  function dispatchSecurityAlertForPolicyAudit(record) {
    if (!record || record.action !== 'policy.config.rejected') {
      return;
    }
    const status = Number.isFinite(record?.meta?.status) ? record.meta.status : null;
    if (status === null || status < 401) {
      return;
    }
    const alertPayload = {
      type: 'security.alert',
      code: 'policy.config.rejected',
      severity: status >= 500 ? 'critical' : 'high',
      timestamp: record.timestamp,
      detail: {
        audit_id: record.id,
        status,
        error: record?.payload?.error || '',
        remote_ip: record?.meta?.remote_ip || '',
        authenticated: record?.meta?.authenticated === true
      }
    };
    dispatchSecurityAlert(alertPayload);
  }

  function dispatchSecurityAlert(alertPayload) {
    if (!alertPayload || typeof alertPayload !== 'object') {
      return;
    }
    const normalizedAlert = normalizeSecurityAlertRecord(alertPayload);
    appendSecurityAlertRecord(securityAlertPath, normalizedAlert);

    const destinations = new Set();
    if (securityAlertWebhookURL
      && shouldDispatchSecurityAlertWebhook({
        alertSeverity: normalizedAlert.severity,
        minimumSeverity: securityAlertWebhookMinSeverity,
        alertCode: normalizedAlert.code,
        codeAllowlist: securityAlertWebhookCodeAllowlist
      })) {
      destinations.add(securityAlertWebhookURL);
    }

    for (const route of securityAlertWebhookRoutes) {
      if (!route || route.enabled === false) {
        continue;
      }
      if (!shouldDispatchSecurityAlertWebhook({
        alertSeverity: normalizedAlert.severity,
        minimumSeverity: route.min_severity,
        alertCode: normalizedAlert.code,
        codeAllowlist: route.code_allowlist
      })) {
        continue;
      }
      destinations.add(route.webhook_url);
    }

    for (const destinationURL of destinations) {
      securityAlertWebhookSender(destinationURL, normalizedAlert).catch(() => {});
    }
  }

  function executeSecurityAlertEscalation({
    ackDeadlineSeconds = 900,
    minSeverity = 'high',
    codeAllowlist = [],
    actor = 'nomad-auto',
    note = 'SLA breach',
    nowTimestamp = Math.floor(Date.now() / 1000)
  } = {}) {
    const normalizedAckDeadlineSeconds = Number.isFinite(ackDeadlineSeconds)
      ? Math.max(0, Math.floor(ackDeadlineSeconds))
      : 900;
    const normalizedMinSeverity = normalizeSecurityAlertSeverity(minSeverity, 'high');
    const normalizedCodeAllowlist = normalizeSecurityAlertCodeAllowlist(codeAllowlist);
    const normalizedActor = typeof actor === 'string' && actor.trim() !== ''
      ? actor.trim()
      : 'nomad-auto';
    const normalizedNote = typeof note === 'string' ? note.trim() : '';

    const ackStateByAlertId = buildSecurityAlertAckStateMap(
      listPolicyAuditRecords(securityAlertAckPath, { limit: Number.MAX_SAFE_INTEGER })
    );
    const escalationStateByAlertId = buildSecurityAlertEscalationStateMap(
      listPolicyAuditRecords(securityAlertEscalationPath, { limit: Number.MAX_SAFE_INTEGER })
    );
    const alerts = listSecurityAlerts(securityAlertPath, {
      ackStateByAlertId,
      escalationStateByAlertId,
      limit: Number.MAX_SAFE_INTEGER
    });

    const candidates = alerts.filter((alert) => {
      const ageSeconds = Math.max(0, nowTimestamp - (Number.isFinite(alert.timestamp) ? alert.timestamp : nowTimestamp));
      if (ageSeconds < normalizedAckDeadlineSeconds) {
        return false;
      }
      if (alert.acknowledged === true) {
        return false;
      }
      if (alert.escalated === true) {
        return false;
      }
      return shouldDispatchSecurityAlertWebhook({
        alertSeverity: alert.severity,
        minimumSeverity: normalizedMinSeverity,
        alertCode: alert.code,
        codeAllowlist: normalizedCodeAllowlist
      });
    });

    const records = [];
    for (const alert of candidates) {
      const record = {
        id: randomUUID(),
        action: 'escalate',
        alert_id: alert.id,
        actor: normalizedActor,
        note: normalizedNote,
        reason: 'ack_timeout',
        timestamp: nowTimestamp
      };
      appendSecurityAlertEscalationRecord(securityAlertEscalationPath, record);
      records.push(record);

      if (securityAlertEscalationWebhookURL) {
        securityAlertEscalationWebhookSender(securityAlertEscalationWebhookURL, {
          type: 'security.alert.escalated',
          timestamp: nowTimestamp,
          alert,
          escalation: record
        }).catch(() => {});
      }
    }

    return {
      ack_deadline_seconds: normalizedAckDeadlineSeconds,
      min_severity: normalizedMinSeverity,
      code_allowlist: normalizedCodeAllowlist,
      escalated_count: records.length,
      records
    };
  }

  function stopSecurityAlertEscalationScheduler() {
    if (securityAlertEscalationTimer) {
      clearInterval(securityAlertEscalationTimer);
      securityAlertEscalationTimer = null;
    }
  }

  function refreshSecurityAlertEscalationScheduler() {
    stopSecurityAlertEscalationScheduler();
    if (!securityAlertEscalationEnabled || securityAlertEscalationIntervalSeconds <= 0) {
      return;
    }

    securityAlertEscalationTimer = setInterval(() => {
      executeSecurityAlertEscalation({
        ackDeadlineSeconds: securityAlertEscalationAckDeadlineSeconds,
        minSeverity: securityAlertEscalationMinSeverity,
        codeAllowlist: securityAlertEscalationCodeAllowlist,
        actor: securityAlertEscalationActor,
        note: securityAlertEscalationNote
      });
    }, securityAlertEscalationIntervalSeconds * 1000);
    if (typeof securityAlertEscalationTimer.unref === 'function') {
      securityAlertEscalationTimer.unref();
    }
  }

  async function executeMetricsAnomalyDispatchTick({
    windowSeconds = metricsAnomalyDispatchWindowSeconds,
    baselineWindowSeconds = metricsAnomalyDispatchBaselineWindowSeconds,
    minSeverity = metricsAnomalyDispatchMinSeverity,
    codeAllowlist = metricsAnomalyDispatchCodeAllowlist,
    dedupeWindowSeconds = metricsAnomalyDispatchDedupeWindowSeconds
  } = {}) {
    const summary = buildKpiAnomalySummary(dataDir, {
      windowSeconds,
      baselineWindowSeconds
    });
    const records = await dispatchKpiAnomalyAlerts({
      dataDir,
      summary,
      webhookURL: metricsAnomalyWebhookURL,
      webhookSender: metricsAnomalyWebhookSender,
      minSeverity,
      codeAllowlist,
      dedupeWindowSeconds,
      respectDedupe: true
    });
    return {
      summary,
      records,
      dispatched_count: records.filter((item) => item.status === 'dispatched').length
    };
  }

  function stopMetricsAnomalyDispatchScheduler() {
    if (metricsAnomalyDispatchTimer) {
      clearInterval(metricsAnomalyDispatchTimer);
      metricsAnomalyDispatchTimer = null;
    }
  }

  function refreshMetricsAnomalyDispatchScheduler() {
    stopMetricsAnomalyDispatchScheduler();
    if (!metricsAnomalyDispatchEnabled || metricsAnomalyDispatchIntervalSeconds <= 0) {
      return;
    }
    if (!metricsAnomalyWebhookURL) {
      return;
    }

    metricsAnomalyDispatchTimer = setInterval(() => {
      executeMetricsAnomalyDispatchTick().catch(() => {});
    }, metricsAnomalyDispatchIntervalSeconds * 1000);
    if (typeof metricsAnomalyDispatchTimer.unref === 'function') {
      metricsAnomalyDispatchTimer.unref();
    }
  }

  function buildMetricsAnomalyDispatchConfigPayload() {
    return {
      enabled: metricsAnomalyDispatchEnabled,
      interval_seconds: metricsAnomalyDispatchIntervalSeconds,
      window_seconds: metricsAnomalyDispatchWindowSeconds,
      baseline_window_seconds: metricsAnomalyDispatchBaselineWindowSeconds,
      min_severity: metricsAnomalyDispatchMinSeverity,
      code_allowlist: metricsAnomalyDispatchCodeAllowlist,
      dedupe_window_seconds: metricsAnomalyDispatchDedupeWindowSeconds,
      webhook_url: metricsAnomalyWebhookURL || null,
      scheduler_running: metricsAnomalyDispatchTimer !== null,
      config_path: kpiAnomalyDispatchConfigPath
    };
  }

  function persistMetricsAnomalyDispatchConfig() {
    writePersistedKpiAnomalyDispatchConfig(kpiAnomalyDispatchConfigPath, {
      enabled: metricsAnomalyDispatchEnabled,
      interval_seconds: metricsAnomalyDispatchIntervalSeconds,
      window_seconds: metricsAnomalyDispatchWindowSeconds,
      baseline_window_seconds: metricsAnomalyDispatchBaselineWindowSeconds,
      min_severity: metricsAnomalyDispatchMinSeverity,
      code_allowlist: metricsAnomalyDispatchCodeAllowlist,
      dedupe_window_seconds: metricsAnomalyDispatchDedupeWindowSeconds
    });
  }

  function buildPolicyConfigResponsePayload({
    whitelistCommands = policyEngine.whitelistCommands(),
    enforceHighRiskReason = policyEngine.enforceHighRiskReason()
  } = {}) {
    return {
      policy_path: policyPath,
      policy_config_signing_required: policyConfigSigningSecret !== '',
      whitelist_commands: whitelistCommands,
      enforce_high_risk_reason: enforceHighRiskReason,
      security_alert_webhook_min_severity: securityAlertWebhookMinSeverity,
      security_alert_webhook_code_allowlist: securityAlertWebhookCodeAllowlist,
      security_alert_webhook_routes: securityAlertWebhookRoutes,
      security_alert_escalation_enabled: securityAlertEscalationEnabled,
      security_alert_escalation_interval_seconds: securityAlertEscalationIntervalSeconds,
      security_alert_escalation_ack_deadline_seconds: securityAlertEscalationAckDeadlineSeconds,
      security_alert_escalation_min_severity: securityAlertEscalationMinSeverity,
      security_alert_escalation_code_allowlist: securityAlertEscalationCodeAllowlist,
      security_alert_escalation_actor: securityAlertEscalationActor,
      security_alert_escalation_note: securityAlertEscalationNote
    };
  }

  function persistPolicyConfig({
    whitelistCommands = policyEngine.whitelistCommands(),
    enforceHighRiskReason = policyEngine.enforceHighRiskReason()
  } = {}) {
    writePersistedPolicyConfig(policyPath, {
      whitelist_commands: whitelistCommands,
      enforce_high_risk_reason: enforceHighRiskReason,
      security_alert_webhook_min_severity: securityAlertWebhookMinSeverity,
      security_alert_webhook_code_allowlist: securityAlertWebhookCodeAllowlist,
      security_alert_webhook_routes: securityAlertWebhookRoutes,
      security_alert_escalation_enabled: securityAlertEscalationEnabled,
      security_alert_escalation_interval_seconds: securityAlertEscalationIntervalSeconds,
      security_alert_escalation_ack_deadline_seconds: securityAlertEscalationAckDeadlineSeconds,
      security_alert_escalation_min_severity: securityAlertEscalationMinSeverity,
      security_alert_escalation_code_allowlist: securityAlertEscalationCodeAllowlist,
      security_alert_escalation_actor: securityAlertEscalationActor,
      security_alert_escalation_note: securityAlertEscalationNote
    });
  }

  function applyConsolePolicyConfigUpdate(body, remoteIp = '') {
    const hasWhitelistCommands = Object.prototype.hasOwnProperty.call(body, 'whitelist_commands');
    const hasEnforceFlag = Object.prototype.hasOwnProperty.call(body, 'enforce_high_risk_reason');
    if (!hasWhitelistCommands && !hasEnforceFlag) {
      const error = new Error('missing policy update fields');
      error.status = 400;
      throw error;
    }

    let updatedWhitelist = policyEngine.whitelistCommands();
    if (hasWhitelistCommands) {
      if (!Array.isArray(body.whitelist_commands)) {
        const error = new Error('invalid whitelist_commands');
        error.status = 400;
        throw error;
      }
      updatedWhitelist = policyEngine.setWhitelistCommands(body.whitelist_commands);
    }

    let updatedEnforceHighRiskReason = policyEngine.enforceHighRiskReason();
    if (hasEnforceFlag) {
      if (typeof body.enforce_high_risk_reason !== 'boolean') {
        const error = new Error('invalid enforce_high_risk_reason');
        error.status = 400;
        throw error;
      }
      updatedEnforceHighRiskReason = policyEngine.setEnforceHighRiskReason(body.enforce_high_risk_reason);
    }

    persistPolicyConfig({
      whitelistCommands: updatedWhitelist,
      enforceHighRiskReason: updatedEnforceHighRiskReason
    });

    appendPolicyAudit('policy.config.updated', {
      whitelist_commands: updatedWhitelist,
      enforce_high_risk_reason: updatedEnforceHighRiskReason,
      security_alert_webhook_min_severity: securityAlertWebhookMinSeverity,
      security_alert_webhook_code_allowlist: securityAlertWebhookCodeAllowlist,
      security_alert_webhook_routes: securityAlertWebhookRoutes,
      security_alert_escalation_enabled: securityAlertEscalationEnabled,
      security_alert_escalation_interval_seconds: securityAlertEscalationIntervalSeconds,
      security_alert_escalation_ack_deadline_seconds: securityAlertEscalationAckDeadlineSeconds,
      security_alert_escalation_min_severity: securityAlertEscalationMinSeverity,
      security_alert_escalation_code_allowlist: securityAlertEscalationCodeAllowlist,
      security_alert_escalation_actor: securityAlertEscalationActor,
      security_alert_escalation_note: securityAlertEscalationNote
    }, {
      remote_ip: remoteIp,
      authenticated: true,
      source: 'console'
    });

    return buildPolicyConfigResponsePayload({
      whitelistCommands: updatedWhitelist,
      enforceHighRiskReason: updatedEnforceHighRiskReason
    });
  }

  function verifyPolicyConfigSignature({ headers = {}, rawBody = '' }) {
    if (!policyConfigSigningSecret) {
      return { ok: true, authenticated: false };
    }

    const version = headers['x-nomad-policy-signature-version'];
    const timestampRaw = headers['x-nomad-policy-timestamp'];
    const nonceRaw = headers['x-nomad-policy-nonce'];
    const signature = headers['x-nomad-policy-signature'];

    if (version !== 'v1') {
      return { ok: false, status: 401, error: 'invalid policy signature version' };
    }

    const timestamp = Number.parseInt(String(timestampRaw || ''), 10);
    if (!Number.isFinite(timestamp)) {
      return { ok: false, status: 401, error: 'invalid policy signature timestamp' };
    }

    const nonce = typeof nonceRaw === 'string' ? nonceRaw.trim() : '';
    if (!nonce) {
      return { ok: false, status: 401, error: 'missing policy signature nonce' };
    }

    const nowSec = Math.floor(Date.now() / 1000);
    if (Math.abs(nowSec - timestamp) > policyConfigReplayWindowSeconds) {
      return { ok: false, status: 401, error: 'policy signature timestamp outside replay window' };
    }

    for (const [cachedNonce, expiresAt] of policyConfigNonceCache.entries()) {
      if (expiresAt < nowSec) {
        policyConfigNonceCache.delete(cachedNonce);
      }
    }

    const existingNonceExpiry = policyConfigNonceCache.get(nonce);
    if (typeof existingNonceExpiry === 'number' && existingNonceExpiry >= nowSec) {
      return { ok: false, status: 409, error: 'replayed policy signature nonce' };
    }

    const expectedSignature = createHmac('sha256', policyConfigSigningSecret)
      .update(`${timestamp}.${nonce}.${rawBody}`)
      .digest('hex');
    if (!timingSafeHexEqual(signature, expectedSignature)) {
      return { ok: false, status: 401, error: 'invalid policy signature' };
    }

    policyConfigNonceCache.set(nonce, nowSec + policyConfigReplayWindowSeconds);
    return {
      ok: true,
      authenticated: true,
      timestamp,
      nonce
    };
  }

  function serveConsoleAsset(res, fileName, contentType) {
    const normalizedName = typeof fileName === 'string' ? fileName : '';
    if (!/^[a-zA-Z0-9._-]+$/.test(normalizedName)) {
      sendJson(res, 404, { ok: false, error: 'not found' });
      return;
    }
    const assetPath = path.join(consoleDir, normalizedName);
    if (!assetPath.startsWith(`${consoleDir}${path.sep}`)) {
      sendJson(res, 404, { ok: false, error: 'not found' });
      return;
    }
    try {
      const body = fs.readFileSync(assetPath, 'utf8');
      sendText(res, 200, contentType, body);
    } catch {
      sendJson(res, 404, { ok: false, error: 'not found' });
    }
  }

  refreshSecurityAlertEscalationScheduler();
  refreshMetricsAnomalyDispatchScheduler();

  const server = http.createServer(async (req, res) => {
   try {
    const method = req.method || 'GET';
    const url = new URL(req.url || '/', `http://${host}:${port}`);

    if (method === 'GET' && (url.pathname === '/console' || url.pathname === '/console/')) {
      serveConsoleAsset(res, 'index.html', 'text/html; charset=utf-8');
      return;
    }

    if (method === 'GET' && url.pathname === '/console/app.js') {
      serveConsoleAsset(res, 'app.js', 'application/javascript; charset=utf-8');
      return;
    }

    if (method === 'GET' && url.pathname === '/console/styles.css') {
      serveConsoleAsset(res, 'styles.css', 'text/css; charset=utf-8');
      return;
    }

    if (method === 'POST' && url.pathname === '/console/api/policy/config') {
      const remoteIp = req.socket?.remoteAddress || '';
      if (!isLoopbackAddress(remoteIp)) {
        sendJson(res, 403, {
          ok: false,
          error: 'console policy API only accepts loopback clients'
        });
        return;
      }
      try {
        const body = await readJsonBody(req);
        const payload = applyConsolePolicyConfigUpdate(body, remoteIp);
        sendJson(res, 200, {
          ok: true,
          ...payload
        });
      } catch (error) {
        const status = Number.isFinite(error?.status) ? error.status : 400;
        appendPolicyAudit('policy.config.rejected', {
          error: error.message
        }, {
          status,
          remote_ip: remoteIp,
          authenticated: true,
          source: 'console'
        });
        sendJson(res, status, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'GET' && url.pathname === '/health') {
      sendJson(res, 200, {
        ok: true,
        service: 'nomad-bridge',
        role: 'host-helper',
        bridge_version: bridgeVersion,
        server_boot_id: serverBootID,
        capabilities: hostCapabilities,
        managed_runtime_default: process.env.BRIDGE_ENABLE_MANAGED_RUNTIME === '1'
      });
      return;
    }

    if (await hostSurfaceApi.handle(req, res, url)) {
      return;
    }

    if (method === 'POST' && url.pathname === '/v1/hooks/events') {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      try {
        const body = serverVerifiedAgentHookBody(await readJsonBody(req));
        const event = normalizeAgentHookEvent(body, body.agent);
        if (rejectHookApprovalDecision(event, res)) {
          return;
        }
        appendAndDispatch(event);
        sendJson(res, 200, {
          ok: true,
          event_id: event.id,
          session_id: event.session_id,
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    const approvalRelayExpirationMatch = url.pathname.match(
      /^\/v1\/approvals\/([^/]+)\/expire$/
    );
    if (method === 'POST' && approvalRelayExpirationMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const requestEventID = safeDecodeURIComponent(approvalRelayExpirationMatch[1]);
      const sessionID = requestEventID ? approvalSessionByEventID.get(requestEventID) : '';
      const requestEvent = sessionID
        ? findSessionEventById(dataDir, sessionID, requestEventID)
        : null;
      if (!requestEvent || !isBridgeRelayPermissionRequest(requestEvent)) {
        sendJson(res, 404, { ok: false, error: 'approval relay not found' });
        return;
      }
      approvalRelayActiveUntilByEventID.set(requestEventID, 0);
      settleApprovalDecisionWaiters(requestEventID, null);
      sendJson(res, 200, { ok: true, expired: true, request_event_id: requestEventID });
      return;
    }

    const approvalDecisionPollMatch = url.pathname.match(
      /^\/v1\/approvals\/([^/]+)\/decision$/
    );
    if (method === 'GET' && approvalDecisionPollMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const requestEventID = safeDecodeURIComponent(approvalDecisionPollMatch[1]);
      if (!requestEventID) {
        sendJson(res, 400, { ok: false, error: 'invalid approval event id' });
        return;
      }
      const approvalSessionID = approvalSessionByEventID.get(requestEventID);
      const requestEvent = approvalSessionID
        ? findSessionEventById(dataDir, approvalSessionID, requestEventID)
        : null;
      const hasCachedDecision = approvalDecisionByRequestEventID.has(requestEventID);
      if (!requestEvent && !hasCachedDecision) {
        sendJson(res, 404, { ok: false, error: 'approval request not found' });
        return;
      }
      if (requestEvent && !hasCachedDecision
        && !renewApprovalRelayLease(requestEventID, requestEvent)) {
        sendJson(res, 410, { ok: false, error: 'approval relay expired' });
        return;
      }
      const requestedWaitSeconds = Number(url.searchParams.get('wait') ?? '25');
      const waitSeconds = Number.isFinite(requestedWaitSeconds)
        ? Math.max(0, Math.min(25, requestedWaitSeconds))
        : 25;
      const pollAbortController = new AbortController();
      let pollFinished = false;
      let pollDisconnected = false;
      const disconnectPoll = () => {
        if (pollFinished) {
          return;
        }
        pollDisconnected = true;
        approvalRelayActiveUntilByEventID.set(requestEventID, 0);
        pollAbortController.abort();
      };
      req.once('aborted', disconnectPoll);
      res.once('close', disconnectPoll);
      if (req.aborted || res.destroyed) {
        disconnectPoll();
      }
      const decision = await waitForApprovalDecision(
        requestEventID,
        Math.floor(waitSeconds * 1000),
        { signal: pollAbortController.signal }
      );
      pollFinished = true;
      req.off('aborted', disconnectPoll);
      res.off('close', disconnectPoll);
      if (pollDisconnected) {
        return;
      }
      if (!decision) {
        res.writeHead(204);
        res.end();
        return;
      }
      sendJson(res, 200, decision);
      return;
    }

    const sessionMultiplexerMatch = url.pathname.match(
      /^\/v1\/sessions\/([^/]+)\/multiplexers$/
    );
    if (method === 'GET' && sessionMultiplexerMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = safeDecodeURIComponent(sessionMultiplexerMatch[1]);
      if (!sessionId) {
        sendJson(res, 400, { ok: false, error: 'invalid session id' });
        return;
      }
      const cached = loadStoredHostSession(sessionId);
      if (!cached) {
        sendJson(res, 404, { ok: false, error: 'session not found' });
        return;
      }
      if (!multiplexerCapabilities.includes('multiplexer.list')
        || typeof multiplexerDiscovery.list !== 'function') {
        sendJson(res, 403, { ok: false, error: 'multiplexer capability is not available' });
        return;
      }
      try {
        const metadata = cached.metadata;
        const discovered = await multiplexerDiscovery.list({ sessionId, metadata });
        const targets = Array.isArray(discovered)
          ? discovered.map((target) => ({ ...target, confidence: 'observed' }))
          : [];
        sendJson(res, 200, {
          ok: true,
          session_id: sessionId,
          capabilities: multiplexerCapabilities,
          targets
        });
      } catch (error) {
        sendJson(res, 503, { ok: false, error: error.message });
      }
      return;
    }

    const sessionFileContentMatch = url.pathname.match(
      /^\/v1\/sessions\/([^/]+)\/files\/content$/
    );
    if (method === 'GET' && sessionFileContentMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = safeDecodeURIComponent(sessionFileContentMatch[1]);
      if (!sessionId) {
        sendJson(res, 400, { ok: false, error: 'invalid session id' });
        return;
      }
      try {
        const metadata = storedHostSessionMetadata(sessionId);
        if (!Array.isArray(metadata.capabilities)
          || !metadata.capabilities.includes('repository.read')) {
          sendJson(res, 403, { ok: false, error: 'repository read capability is not available' });
          return;
        }
        if (!boundedRepositoryReader.selfCheck(metadata.cwd)) {
          sendJson(res, 409, { ok: false, error: 'session workspace is unavailable' });
          return;
        }
        const result = boundedRepositoryReader.read({
          workspace: metadata.cwd,
          relativePath: url.searchParams.get('path')
        });
        sendJson(res, 200, { ok: true, session_id: sessionId, ...result });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    const sessionFilesMatch = url.pathname.match(/^\/v1\/sessions\/([^/]+)\/files$/);
    if (method === 'GET' && sessionFilesMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = safeDecodeURIComponent(sessionFilesMatch[1]);
      if (!sessionId) {
        sendJson(res, 400, { ok: false, error: 'invalid session id' });
        return;
      }
      try {
        const metadata = storedHostSessionMetadata(sessionId);
        if (!Array.isArray(metadata.capabilities)
          || !metadata.capabilities.includes('repository.read')) {
          sendJson(res, 403, { ok: false, error: 'repository read capability is not available' });
          return;
        }
        if (!boundedRepositoryReader.selfCheck(metadata.cwd)) {
          sendJson(res, 409, { ok: false, error: 'session workspace is unavailable' });
          return;
        }
        const result = boundedRepositoryReader.list({
          workspace: metadata.cwd,
          relativePath: url.searchParams.get('path') || ''
        });
        sendJson(res, 200, { ok: true, session_id: sessionId, ...result });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    const sessionDiffMatch = url.pathname.match(/^\/v1\/sessions\/([^/]+)\/diff$/);
    if (method === 'GET' && sessionDiffMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(sessionDiffMatch[1]);
      try {
        const metadata = storedHostSessionMetadata(sessionId);
        if (!Array.isArray(metadata.capabilities) || !metadata.capabilities.includes('diff.read')) {
          sendJson(res, 403, { ok: false, error: 'diff capability is not available' });
          return;
        }
        if (typeof metadata.cwd !== 'string' || metadata.cwd.trim() === '') {
          sendJson(res, 409, { ok: false, error: 'session workspace is unavailable' });
          return;
        }
        const result = boundedDiffReader.read({
          cwd: metadata.cwd,
          paths: url.searchParams.getAll('path'),
          maxBytes: 512 * 1024,
          maxFiles: 100
        });
        sendJson(res, 200, {
          ok: true,
          session_id: sessionId,
          ...result
        });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    const sessionPreviewMatch = url.pathname.match(/^\/v1\/sessions\/([^/]+)\/preview$/);
    if (method === 'GET' && sessionPreviewMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(sessionPreviewMatch[1]);
      const metadata = storedHostSessionMetadata(sessionId);
      const preview = metadata.preview;
      if (!Array.isArray(metadata.capabilities) || !metadata.capabilities.includes('preview.read')) {
        sendJson(res, 403, { ok: false, error: 'preview capability is not available' });
        return;
      }
      if (!preview || preview.host !== configuredAdvertisedAddress.toLowerCase()) {
        sendJson(res, 403, { ok: false, error: 'preview host is not allowlisted' });
        return;
      }
      const previewURL = new URL(`${preview.scheme}://${preview.host}:${preview.port}`);
      previewURL.pathname = preview.path;
      sendJson(res, 200, {
        ok: true,
        session_id: sessionId,
        preview: {
          ...preview,
          url: previewURL.toString()
        }
      });
      return;
    }

    const sessionUploadMatch = url.pathname.match(
      /^\/v1\/sessions\/([^/]+)\/(images|attachments)$/
    );
    if (method === 'POST' && sessionUploadMatch) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(sessionUploadMatch[1]);
      const uploadCollection = sessionUploadMatch[2];
      try {
        const metadata = storedHostSessionMetadata(sessionId);
        if (!Array.isArray(metadata.capabilities) || !metadata.capabilities.includes('file.upload')) {
          sendJson(res, 403, { ok: false, error: 'attachment upload capability is not available' });
          return;
        }
        if (typeof metadata.cwd !== 'string' || metadata.cwd.trim() === '') {
          sendJson(res, 409, { ok: false, error: 'session workspace is unavailable' });
          return;
        }
        const body = await readJsonBody(req, { maxBytes: 14 * 1024 * 1024 });
        if (uploadCollection === 'images'
          && (typeof body.mime_type !== 'string' || !body.mime_type.startsWith('image/'))) {
          throw new Error('image endpoint accepts image types only');
        }
        const upload = sessionUploadStore.save({
          workspace: metadata.cwd,
          name: body.name,
          mimeType: body.mime_type,
          dataBase64: body.data_base64
        });
        sendJson(res, 201, {
          ok: true,
          session_id: sessionId,
          upload: {
            relative_path: upload.relative_path,
            mime_type: upload.mime_type,
            size_bytes: upload.size_bytes
          }
        });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    if (url.pathname === '/v1/notification-rules' && (method === 'GET' || method === 'PUT')) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      try {
        if (method === 'PUT') {
          const body = await readJsonBody(req);
          notificationRoutingStore.replace(body.rules);
        }
        sendJson(res, 200, { ok: true, rules: notificationRoutingStore.list() });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    if (url.pathname === '/v1/notification-destination'
      && (method === 'GET' || method === 'PUT')) {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      try {
        if (method === 'PUT') {
          const body = await readJsonBody(req);
          notificationDestinationStore.set(body.webhook_url);
          notificationWebhookURL = notificationDestinationStore.get();
        }
        const configured = typeof notificationWebhookURL === 'string'
          && notificationWebhookURL.trim() !== '';
        sendJson(res, 200, {
          ok: true,
          configured,
          origin: configured ? new URL(notificationWebhookURL).origin : null
        });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/v1/metrics/events') {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      try {
        const body = await readJsonBody(req, { maxBytes: 256 * 1024 });
        const events = Array.isArray(body.events) ? body.events : [body];
        if (events.length === 0 || events.length > 100) {
          throw new Error('events must contain from 1 through 100 product metric events');
        }
        let accepted = 0;
        let duplicates = 0;
        for (const event of events) {
          const result = productMetricStore.append(event);
          accepted += result.accepted ? 1 : 0;
          duplicates += result.duplicate ? 1 : 0;
        }
        sendJson(res, 202, { ok: true, accepted, duplicates });
      } catch (error) {
        sendJson(res, 400, { ok: false, error: error.message });
      }
      return;
    }

    if (method === 'GET' && url.pathname === '/v1/metrics/product') {
      if (!hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const requestedWindow = parsePositiveInt(url.searchParams.get('window_seconds'), 2_592_000);
      const windowSeconds = Math.min(requestedWindow, 31_536_000);
      sendJson(res, 200, {
        ok: true,
        metrics: productMetricStore.summary({ windowSeconds })
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/agents/hooks') {
      sendJson(res, 200, {
        ok: true,
        agents: getSupportedHookAgents()
      });
      return;
    }

    const hookInstallPlanMatch = url.pathname.match(/^\/agents\/hooks\/([^/]+)\/install-plan$/);
    if (method === 'GET' && hookInstallPlanMatch) {
      const agentId = decodeURIComponent(hookInstallPlanMatch[1]);
      const bridgeURL = normalizeOptionalString(url.searchParams.get('bridge_url'), runtimeBaseUrl);
      const projectID = normalizeOptionalString(url.searchParams.get('project_id'), 'default');
      try {
        sendJson(res, 200, {
          ok: true,
          plan: buildHookInstallPlan(agentId, { bridgeURL, projectID })
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    const hostSessionMetadataMatch = url.pathname.match(/^\/agents\/sessions\/([^/]+)\/metadata$/);
    if (method === 'GET' && hostSessionMetadataMatch) {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      const sessionId = safeDecodeURIComponent(hostSessionMetadataMatch[1]);
      if (sessionId === null) {
        sendJson(res, 400, { ok: false, error: 'invalid session id encoding' });
        return;
      }
      const metadata = verifyHostSessionMetadata(storedHostSessionMetadata(sessionId));
      sendJson(res, 200, {
        ok: true,
        session_id: sessionId,
        metadata,
        session: buildHostSessionSnapshot(sessionId, metadata)
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/sessions/summary') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const summary = buildSessionsSummary(dataDir, { windowSeconds });
      sendJson(res, 200, {
        ok: true,
        summary
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const kpi = buildKpiSummary(dataDir, { windowSeconds });
      sendJson(res, 200, {
        ok: true,
        kpi
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/beta-gates') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const crashFreeSessionRate = parseUnitIntervalInput(url.searchParams.get('crash_free_session_rate'));
      const gates = buildKpiBetaGates(dataDir, {
        windowSeconds,
        crashFreeSessionRate,
        thresholds: {
          min_connection_success_rate: parseUnitIntervalInput(url.searchParams.get('min_connection_success_rate')),
          min_approval_decision_rate: parseUnitIntervalInput(url.searchParams.get('min_approval_decision_rate')),
          max_approval_average_latency_ms: parsePositiveIntInput(url.searchParams.get('max_approval_average_latency_ms')),
          max_approval_p95_latency_ms: parsePositiveIntInput(url.searchParams.get('max_approval_p95_latency_ms')),
          min_task_completion_rate: parseUnitIntervalInput(url.searchParams.get('min_task_completion_rate')),
          max_cursor_conflicts_unresolved: parseNonNegativeIntInput(url.searchParams.get('max_cursor_conflicts_unresolved')),
          max_unresolved_high_risk_security_alerts: parseNonNegativeIntInput(url.searchParams.get('max_unresolved_high_risk_security_alerts')),
          min_crash_free_session_rate: parseUnitIntervalInput(url.searchParams.get('min_crash_free_session_rate'))
        }
      });
      sendJson(res, 200, {
        ok: true,
        gates
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/anomalies/config') {
      sendJson(res, 200, {
        ok: true,
        ...buildMetricsAnomalyDispatchConfigPayload()
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/anomalies/dispatch/summary') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const summary = buildKpiAnomalyDispatchSummary(dataDir, { windowSeconds });
      sendJson(res, 200, {
        ok: true,
        summary
      });
      return;
    }

    if (method === 'POST' && url.pathname === '/metrics/kpi/anomalies/config') {
      try {
        const body = await readJsonBody(req);
        const hasEnabled = Object.prototype.hasOwnProperty.call(body, 'enabled');
        const hasIntervalSeconds = Object.prototype.hasOwnProperty.call(body, 'interval_seconds');
        const hasWindowSeconds = Object.prototype.hasOwnProperty.call(body, 'window_seconds');
        const hasBaselineWindowSeconds = Object.prototype.hasOwnProperty.call(body, 'baseline_window_seconds');
        const hasMinSeverity = Object.prototype.hasOwnProperty.call(body, 'min_severity');
        const hasCodeAllowlist = Object.prototype.hasOwnProperty.call(body, 'code_allowlist');
        const hasDedupeWindowSeconds = Object.prototype.hasOwnProperty.call(body, 'dedupe_window_seconds');
        const hasPersist = Object.prototype.hasOwnProperty.call(body, 'persist');

        if (!hasEnabled
          && !hasIntervalSeconds
          && !hasWindowSeconds
          && !hasBaselineWindowSeconds
          && !hasMinSeverity
          && !hasCodeAllowlist
          && !hasDedupeWindowSeconds
          && !hasPersist) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing metrics anomaly config fields'
          });
          return;
        }

        if (hasEnabled && typeof body.enabled !== 'boolean') {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid enabled'
          });
          return;
        }

        const updatedEnabled = hasEnabled
          ? body.enabled
          : metricsAnomalyDispatchEnabled;

        let updatedIntervalSeconds = metricsAnomalyDispatchIntervalSeconds;
        if (hasIntervalSeconds) {
          const parsed = parseNonNegativeIntInput(body.interval_seconds);
          if (parsed === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid interval_seconds'
            });
            return;
          }
          updatedIntervalSeconds = parsed;
        }

        let updatedWindowSeconds = metricsAnomalyDispatchWindowSeconds;
        if (hasWindowSeconds) {
          const parsed = parsePositiveIntInput(body.window_seconds);
          if (parsed === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid window_seconds'
            });
            return;
          }
          updatedWindowSeconds = parsed;
        }

        let updatedBaselineWindowSeconds = metricsAnomalyDispatchBaselineWindowSeconds;
        if (hasBaselineWindowSeconds) {
          const parsed = parsePositiveIntInput(body.baseline_window_seconds);
          if (parsed === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid baseline_window_seconds'
            });
            return;
          }
          updatedBaselineWindowSeconds = parsed;
        }

        let updatedMinSeverity = metricsAnomalyDispatchMinSeverity;
        if (hasMinSeverity) {
          const parsed = parseSecurityAlertSeverityInput(body.min_severity);
          if (!parsed) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid min_severity'
            });
            return;
          }
          updatedMinSeverity = parsed;
        }

        let updatedCodeAllowlist = metricsAnomalyDispatchCodeAllowlist;
        if (hasCodeAllowlist) {
          const parsed = parseSecurityAlertCodeAllowlistInput(body.code_allowlist);
          if (!parsed) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid code_allowlist'
            });
            return;
          }
          updatedCodeAllowlist = parsed;
        }

        let updatedDedupeWindowSeconds = metricsAnomalyDispatchDedupeWindowSeconds;
        if (hasDedupeWindowSeconds) {
          const parsed = parseNonNegativeIntInput(body.dedupe_window_seconds);
          if (parsed === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid dedupe_window_seconds'
            });
            return;
          }
          updatedDedupeWindowSeconds = parsed;
        }

        metricsAnomalyDispatchEnabled = updatedEnabled;
        metricsAnomalyDispatchIntervalSeconds = updatedIntervalSeconds;
        metricsAnomalyDispatchWindowSeconds = updatedWindowSeconds;
        metricsAnomalyDispatchBaselineWindowSeconds = updatedBaselineWindowSeconds;
        metricsAnomalyDispatchMinSeverity = updatedMinSeverity;
        metricsAnomalyDispatchCodeAllowlist = updatedCodeAllowlist;
        metricsAnomalyDispatchDedupeWindowSeconds = updatedDedupeWindowSeconds;
        refreshMetricsAnomalyDispatchScheduler();

        const shouldPersist = parseBooleanInput(body.persist, true);
        if (shouldPersist) {
          persistMetricsAnomalyDispatchConfig();
        }

        sendJson(res, 200, {
          ok: true,
          persisted: shouldPersist,
          ...buildMetricsAnomalyDispatchConfigPayload()
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/anomalies') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const baselineWindowSeconds = parsePositiveInt(
        url.searchParams.get('baseline_window_seconds') || '86400',
        86400
      );
      const summary = buildKpiAnomalySummary(dataDir, {
        windowSeconds,
        baselineWindowSeconds
      });
      sendJson(res, 200, {
        ok: true,
        summary
      });
      return;
    }

    if (method === 'POST' && url.pathname === '/metrics/kpi/anomalies/dispatch') {
      try {
        const body = await readJsonBody(req);
        const windowSeconds = parsePositiveInt(body.window_seconds ?? 3600, 3600);
        const baselineWindowSeconds = parsePositiveInt(
          body.baseline_window_seconds ?? 86400,
          86400
        );
        const minSeverity = Object.prototype.hasOwnProperty.call(body, 'min_severity')
          ? parseSecurityAlertSeverityInput(body.min_severity)
          : 'high';
        if (!minSeverity) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid min_severity'
          });
          return;
        }
        const codeAllowlist = Object.prototype.hasOwnProperty.call(body, 'code_allowlist')
          ? parseSecurityAlertCodeAllowlistInput(body.code_allowlist)
          : [];
        if (codeAllowlist === null) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid code_allowlist'
          });
          return;
        }
        const respectDedupe = parseBooleanInput(body.respect_dedupe, false);
        let dedupeWindowSeconds = metricsAnomalyDispatchDedupeWindowSeconds;
        if (Object.prototype.hasOwnProperty.call(body, 'dedupe_window_seconds')) {
          const parsedDedupeWindowSeconds = parseNonNegativeIntInput(body.dedupe_window_seconds);
          if (parsedDedupeWindowSeconds === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid dedupe_window_seconds'
            });
            return;
          }
          dedupeWindowSeconds = parsedDedupeWindowSeconds;
        }
        const dryRun = parseBooleanInput(body.dry_run, false);
        const summary = buildKpiAnomalySummary(dataDir, {
          windowSeconds,
          baselineWindowSeconds
        });
        const dispatchRecords = dryRun
          ? []
          : await dispatchKpiAnomalyAlerts({
              dataDir,
              summary,
              webhookURL: metricsAnomalyWebhookURL,
              webhookSender: metricsAnomalyWebhookSender,
              minSeverity,
              codeAllowlist,
              dedupeWindowSeconds,
              respectDedupe
            });
        const dispatchedCount = dispatchRecords.filter((item) => item.status === 'dispatched').length;
        sendJson(res, 200, {
          ok: true,
          webhook_url: metricsAnomalyWebhookURL || null,
          dry_run: dryRun,
          min_severity: minSeverity,
          code_allowlist: codeAllowlist,
          respect_dedupe: respectDedupe,
          dedupe_window_seconds: dedupeWindowSeconds,
          dispatched_count: dispatchedCount,
          records: dispatchRecords,
          summary
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/metrics/ui-actions') {
      try {
        const body = await readJsonBody(req);
        const action = normalizeOptionalString(body.action, '');
        if (!action) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing action'
          });
          return;
        }
        const timestamp = Number.isFinite(body.timestamp)
          ? Math.floor(body.timestamp)
          : Math.floor(Date.now() / 1000);
        const record = appendUiActionRecord(dataDir, {
          event_id: randomUUID(),
          action,
          screen: body.screen,
          flow_id: body.flow_id,
          session_id: body.session_id,
          timestamp
        });
        sendJson(res, 200, {
          ok: true,
          event_id: record.event_id
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/ui-actions/summary') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const limit = parsePositiveInt(url.searchParams.get('limit') || '10', 10);
      const summary = buildUiActionSummary(dataDir, { windowSeconds, limit });
      sendJson(res, 200, {
        ok: true,
        summary
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/replay/consistency') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const limit = parsePositiveInt(url.searchParams.get('limit') || '10', 10);
      const summary = buildReplayConsistencySummary(dataDir, { windowSeconds, limit });
      sendJson(res, 200, {
        ok: true,
        summary
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/sessions') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '3600', 3600);
      const limit = parsePositiveInt(url.searchParams.get('limit') || '20', 20);
      const offset = parseNonNegativeInt(url.searchParams.get('offset') || '0', 0);
      const search = normalizeOptionalString(url.searchParams.get('search'), '');
      const preset = resolveKpiSessionPreset(url.searchParams.get('preset'));
      const source = normalizeOptionalString(url.searchParams.get('source'), 'all').toLowerCase();
      const risk = normalizeOptionalString(url.searchParams.get('risk'), 'all').toLowerCase();
      const sortBy = normalizeKpiSessionSortBy(
        url.searchParams.get('sort_by'),
        preset.sort_by
      );
      const sortOrder = normalizeKpiSessionSortOrder(
        url.searchParams.get('sort_order'),
        preset.sort_order
      );
      const breakdown = buildKpiSessionsBreakdown(dataDir, {
        windowSeconds,
        limit,
        offset,
        source,
        risk,
        search,
        sortBy,
        sortOrder,
        presetApplied: preset.preset_applied
      });
      sendJson(res, 200, {
        ok: true,
        ...breakdown
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/sessions/profile') {
      const profile = readPersistedKpiSessionProfile(kpiSessionProfilePath);
      sendJson(res, 200, {
        ok: true,
        profile_path: kpiSessionProfilePath,
        queries: profile.queries,
        updated_at: profile.updated_at
      });
      return;
    }

    if (method === 'PUT' && url.pathname === '/metrics/kpi/sessions/profile') {
      try {
        const body = await readJsonBody(req);
        const parsed = parseKpiSessionProfileQueriesInput(body.queries);
        if (!parsed.ok) {
          sendJson(res, 400, {
            ok: false,
            error: parsed.error
          });
          return;
        }
        const persisted = writePersistedKpiSessionProfile(kpiSessionProfilePath, parsed.queries);
        sendJson(res, 200, {
          ok: true,
          profile_path: kpiSessionProfilePath,
          queries: persisted.queries,
          updated_at: persisted.updated_at
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/metrics/kpi/sessions/profile/merge') {
      try {
        const body = await readJsonBody(req);
        const parsed = parseKpiSessionProfileQueriesInput(body.queries);
        if (!parsed.ok) {
          sendJson(res, 400, {
            ok: false,
            error: parsed.error
          });
          return;
        }
        const existing = readPersistedKpiSessionProfile(kpiSessionProfilePath);
        const mergedQueries = mergeKpiSessionProfileQueries(existing.queries, parsed.queries);
        const persisted = writePersistedKpiSessionProfile(kpiSessionProfilePath, mergedQueries);
        sendJson(res, 200, {
          ok: true,
          profile_path: kpiSessionProfilePath,
          queries: persisted.queries,
          updated_at: persisted.updated_at
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'GET' && url.pathname === '/metrics/kpi/timeseries') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '86400', 86400);
      const bucketSeconds = parsePositiveInt(url.searchParams.get('bucket_seconds') || '3600', 3600);
      const timeseries = buildKpiTimeseries(dataDir, { windowSeconds, bucketSeconds });
      sendJson(res, 200, {
        ok: true,
        ...timeseries
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/policy/config') {
      sendJson(res, 200, {
        ok: true,
        policy_path: policyPath,
        policy_config_signing_required: policyConfigSigningSecret !== '',
        policy_config_replay_window_seconds: policyConfigReplayWindowSeconds,
        whitelist_commands: policyEngine.whitelistCommands(),
        enforce_high_risk_reason: policyEngine.enforceHighRiskReason(),
        security_alert_webhook_min_severity: securityAlertWebhookMinSeverity,
        security_alert_webhook_code_allowlist: securityAlertWebhookCodeAllowlist,
        security_alert_webhook_routes: securityAlertWebhookRoutes,
        security_alert_escalation_enabled: securityAlertEscalationEnabled,
        security_alert_escalation_interval_seconds: securityAlertEscalationIntervalSeconds,
        security_alert_escalation_ack_deadline_seconds: securityAlertEscalationAckDeadlineSeconds,
        security_alert_escalation_min_severity: securityAlertEscalationMinSeverity,
        security_alert_escalation_code_allowlist: securityAlertEscalationCodeAllowlist,
        security_alert_escalation_actor: securityAlertEscalationActor,
        security_alert_escalation_note: securityAlertEscalationNote
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/policy/audit') {
      const limit = parsePositiveInt(url.searchParams.get('limit') || '50', 50);
      const events = listPolicyAuditRecords(policyAuditPath, { limit });
      sendJson(res, 200, {
        ok: true,
        audit_path: policyAuditPath,
        events
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/policy/audit/summary') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '86400', 86400);
      const records = listPolicyAuditRecords(policyAuditPath, { limit: Number.MAX_SAFE_INTEGER });
      const summary = buildPolicyAuditSummary(records, { windowSeconds });
      sendJson(res, 200, {
        ok: true,
        audit_path: policyAuditPath,
        summary
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/security/alerts') {
      const limit = parsePositiveInt(url.searchParams.get('limit') || '50', 50);
      const ackStateByAlertId = buildSecurityAlertAckStateMap(
        listPolicyAuditRecords(securityAlertAckPath, { limit: Number.MAX_SAFE_INTEGER })
      );
      const escalationStateByAlertId = buildSecurityAlertEscalationStateMap(
        listPolicyAuditRecords(securityAlertEscalationPath, { limit: Number.MAX_SAFE_INTEGER })
      );
      const alerts = listSecurityAlerts(securityAlertPath, {
        ackStateByAlertId,
        escalationStateByAlertId,
        limit
      });
      sendJson(res, 200, {
        ok: true,
        alert_path: securityAlertPath,
        alerts
      });
      return;
    }

    if (method === 'GET' && url.pathname === '/security/alerts/summary') {
      const windowSeconds = parsePositiveInt(url.searchParams.get('window_seconds') || '86400', 86400);
      const ackStateByAlertId = buildSecurityAlertAckStateMap(
        listPolicyAuditRecords(securityAlertAckPath, { limit: Number.MAX_SAFE_INTEGER })
      );
      const escalationStateByAlertId = buildSecurityAlertEscalationStateMap(
        listPolicyAuditRecords(securityAlertEscalationPath, { limit: Number.MAX_SAFE_INTEGER })
      );
      const alerts = listSecurityAlerts(securityAlertPath, {
        ackStateByAlertId,
        escalationStateByAlertId,
        limit: Number.MAX_SAFE_INTEGER
      });
      const summary = buildSecurityAlertSummary(alerts, { windowSeconds });
      sendJson(res, 200, {
        ok: true,
        alert_path: securityAlertPath,
        summary
      });
      return;
    }

    const securityAlertAckMatch = url.pathname.match(/^\/security\/alerts\/([^/]+)\/ack$/);
    if (method === 'POST' && securityAlertAckMatch) {
      const alertId = decodeURIComponent(securityAlertAckMatch[1]).trim();
      if (!alertId) {
        sendJson(res, 400, {
          ok: false,
          error: 'invalid alert_id'
        });
        return;
      }
      try {
        const body = await readJsonBody(req);
        const actor = typeof body.actor === 'string' ? body.actor.trim() : '';
        if (!actor) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing actor'
          });
          return;
        }
        const note = typeof body.note === 'string' ? body.note.trim() : '';

        const ackRecords = listPolicyAuditRecords(securityAlertAckPath, { limit: Number.MAX_SAFE_INTEGER });
        const ackStateByAlertId = buildSecurityAlertAckStateMap(ackRecords);
        const escalationStateByAlertId = buildSecurityAlertEscalationStateMap(
          listPolicyAuditRecords(securityAlertEscalationPath, { limit: Number.MAX_SAFE_INTEGER })
        );
        const alerts = listSecurityAlerts(securityAlertPath, {
          ackStateByAlertId,
          escalationStateByAlertId,
          limit: Number.MAX_SAFE_INTEGER
        });
        const targetAlert = alerts.find((alert) => alert.id === alertId);
        if (!targetAlert) {
          sendJson(res, 404, {
            ok: false,
            error: 'alert not found',
            alert_id: alertId
          });
          return;
        }

        const existingAck = ackStateByAlertId.get(alertId);
        if (existingAck) {
          sendJson(res, 200, {
            ok: true,
            duplicate: true,
            alert_id: alertId,
            ack: existingAck,
            alert: targetAlert
          });
          return;
        }

        const ackRecord = {
          id: randomUUID(),
          action: 'ack',
          alert_id: alertId,
          actor,
          note,
          timestamp: Math.floor(Date.now() / 1000)
        };
        appendSecurityAlertAckRecord(securityAlertAckPath, ackRecord);
        sendJson(res, 200, {
          ok: true,
          duplicate: false,
          alert_id: alertId,
          ack: ackRecord,
          alert: {
            ...targetAlert,
            acknowledged: true,
            acknowledged_at: ackRecord.timestamp,
            acknowledged_by: ackRecord.actor,
            ack_note: ackRecord.note || null,
            ack_event_id: ackRecord.id
          }
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/security/alerts/escalate') {
      try {
        const body = await readJsonBody(req);
        const ackDeadlineSeconds = Object.prototype.hasOwnProperty.call(body, 'ack_deadline_seconds')
          ? parsePositiveInt(body.ack_deadline_seconds, 0)
          : 900;
        const minSeverity = Object.prototype.hasOwnProperty.call(body, 'min_severity')
          ? parseSecurityAlertSeverityInput(body.min_severity)
          : 'high';
        if (!minSeverity) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid min_severity'
          });
          return;
        }
        let codeAllowlist = [];
        if (Object.prototype.hasOwnProperty.call(body, 'code_allowlist')) {
          if (!Array.isArray(body.code_allowlist)) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid code_allowlist'
            });
            return;
          }
          codeAllowlist = normalizeSecurityAlertCodeAllowlist(body.code_allowlist);
        }
        const result = executeSecurityAlertEscalation({
          ackDeadlineSeconds,
          minSeverity,
          codeAllowlist,
          actor: body.actor,
          note: body.note
        });
        sendJson(res, 200, {
          ok: true,
          ...result
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/policy/config') {
      const remoteIp = req.socket?.remoteAddress || '';
      try {
        const { body, raw } = await readJsonBody(req, { includeRaw: true });
        const signatureResult = verifyPolicyConfigSignature({
          headers: req.headers || {},
          rawBody: raw
        });
        if (!signatureResult.ok) {
          appendPolicyAudit('policy.config.rejected', {
            error: signatureResult.error
          }, {
            status: signatureResult.status || 401,
            remote_ip: remoteIp
          });
          sendJson(res, signatureResult.status || 401, {
            ok: false,
            error: signatureResult.error
          });
          return;
        }

        const hasWhitelistCommands = Object.prototype.hasOwnProperty.call(body, 'whitelist_commands');
        const hasEnforceFlag = Object.prototype.hasOwnProperty.call(body, 'enforce_high_risk_reason');
        const hasSecurityAlertMinSeverity = Object.prototype.hasOwnProperty.call(body, 'security_alert_webhook_min_severity');
        const hasSecurityAlertCodeAllowlist = Object.prototype.hasOwnProperty.call(body, 'security_alert_webhook_code_allowlist');
        const hasSecurityAlertRoutes = Object.prototype.hasOwnProperty.call(body, 'security_alert_webhook_routes');
        const hasSecurityAlertEscalationEnabled = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_enabled');
        const hasSecurityAlertEscalationIntervalSeconds = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_interval_seconds');
        const hasSecurityAlertEscalationAckDeadlineSeconds = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_ack_deadline_seconds');
        const hasSecurityAlertEscalationMinSeverity = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_min_severity');
        const hasSecurityAlertEscalationCodeAllowlist = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_code_allowlist');
        const hasSecurityAlertEscalationActor = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_actor');
        const hasSecurityAlertEscalationNote = Object.prototype.hasOwnProperty.call(body, 'security_alert_escalation_note');
        if (!hasWhitelistCommands
          && !hasEnforceFlag
          && !hasSecurityAlertMinSeverity
          && !hasSecurityAlertCodeAllowlist
          && !hasSecurityAlertRoutes
          && !hasSecurityAlertEscalationEnabled
          && !hasSecurityAlertEscalationIntervalSeconds
          && !hasSecurityAlertEscalationAckDeadlineSeconds
          && !hasSecurityAlertEscalationMinSeverity
          && !hasSecurityAlertEscalationCodeAllowlist
          && !hasSecurityAlertEscalationActor
          && !hasSecurityAlertEscalationNote) {
          appendPolicyAudit('policy.config.rejected', {
            error: 'missing policy update fields'
          }, {
            status: 400,
            remote_ip: remoteIp,
            authenticated: signatureResult.authenticated === true
          });
          sendJson(res, 400, {
            ok: false,
            error: 'missing policy update fields'
          });
          return;
        }
        let updatedWhitelist = policyEngine.whitelistCommands();
        if (hasWhitelistCommands) {
          if (!Array.isArray(body.whitelist_commands)) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid whitelist_commands'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid whitelist_commands'
            });
            return;
          }
          updatedWhitelist = policyEngine.setWhitelistCommands(body.whitelist_commands);
        }
        let updatedEnforceHighRiskReason = policyEngine.enforceHighRiskReason();
        if (hasEnforceFlag) {
          if (typeof body.enforce_high_risk_reason !== 'boolean') {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid enforce_high_risk_reason'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid enforce_high_risk_reason'
            });
            return;
          }
          updatedEnforceHighRiskReason = policyEngine.setEnforceHighRiskReason(body.enforce_high_risk_reason);
        }
        let updatedSecurityAlertWebhookMinSeverity = securityAlertWebhookMinSeverity;
        if (hasSecurityAlertMinSeverity) {
          const parsedSecurityAlertMinSeverity = parseSecurityAlertSeverityInput(body.security_alert_webhook_min_severity);
          if (!parsedSecurityAlertMinSeverity) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_webhook_min_severity'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_webhook_min_severity'
            });
            return;
          }
          updatedSecurityAlertWebhookMinSeverity = parsedSecurityAlertMinSeverity;
        }
        let updatedSecurityAlertWebhookCodeAllowlist = securityAlertWebhookCodeAllowlist;
        if (hasSecurityAlertCodeAllowlist) {
          const parsedSecurityAlertCodeAllowlist = parseSecurityAlertCodeAllowlistInput(body.security_alert_webhook_code_allowlist);
          if (!parsedSecurityAlertCodeAllowlist) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_webhook_code_allowlist'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_webhook_code_allowlist'
            });
            return;
          }
          updatedSecurityAlertWebhookCodeAllowlist = parsedSecurityAlertCodeAllowlist;
        }
        let updatedSecurityAlertWebhookRoutes = securityAlertWebhookRoutes;
        if (hasSecurityAlertRoutes) {
          const parsedSecurityAlertRoutes = parseSecurityAlertWebhookRoutesInput(body.security_alert_webhook_routes);
          if (!parsedSecurityAlertRoutes || parsedSecurityAlertRoutes.ok !== true) {
            appendPolicyAudit('policy.config.rejected', {
              error: parsedSecurityAlertRoutes?.error || 'invalid security_alert_webhook_routes'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: parsedSecurityAlertRoutes?.error || 'invalid security_alert_webhook_routes'
            });
            return;
          }
          updatedSecurityAlertWebhookRoutes = parsedSecurityAlertRoutes.routes;
        }
        let updatedSecurityAlertEscalationEnabled = securityAlertEscalationEnabled;
        if (hasSecurityAlertEscalationEnabled) {
          if (typeof body.security_alert_escalation_enabled !== 'boolean') {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_enabled'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_enabled'
            });
            return;
          }
          updatedSecurityAlertEscalationEnabled = body.security_alert_escalation_enabled;
        }
        let updatedSecurityAlertEscalationIntervalSeconds = securityAlertEscalationIntervalSeconds;
        if (hasSecurityAlertEscalationIntervalSeconds) {
          const parsedInterval = parseNonNegativeIntInput(body.security_alert_escalation_interval_seconds);
          if (parsedInterval === null) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_interval_seconds'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_interval_seconds'
            });
            return;
          }
          updatedSecurityAlertEscalationIntervalSeconds = parsedInterval;
        }
        let updatedSecurityAlertEscalationAckDeadlineSeconds = securityAlertEscalationAckDeadlineSeconds;
        if (hasSecurityAlertEscalationAckDeadlineSeconds) {
          const parsedAckDeadline = parseNonNegativeIntInput(body.security_alert_escalation_ack_deadline_seconds);
          if (parsedAckDeadline === null) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_ack_deadline_seconds'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_ack_deadline_seconds'
            });
            return;
          }
          updatedSecurityAlertEscalationAckDeadlineSeconds = parsedAckDeadline;
        }
        let updatedSecurityAlertEscalationMinSeverity = securityAlertEscalationMinSeverity;
        if (hasSecurityAlertEscalationMinSeverity) {
          const parsedEscalationMinSeverity = parseSecurityAlertSeverityInput(body.security_alert_escalation_min_severity);
          if (!parsedEscalationMinSeverity) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_min_severity'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_min_severity'
            });
            return;
          }
          updatedSecurityAlertEscalationMinSeverity = parsedEscalationMinSeverity;
        }
        let updatedSecurityAlertEscalationCodeAllowlist = securityAlertEscalationCodeAllowlist;
        if (hasSecurityAlertEscalationCodeAllowlist) {
          const parsedEscalationCodeAllowlist = parseSecurityAlertCodeAllowlistInput(body.security_alert_escalation_code_allowlist);
          if (!parsedEscalationCodeAllowlist) {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_code_allowlist'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_code_allowlist'
            });
            return;
          }
          updatedSecurityAlertEscalationCodeAllowlist = parsedEscalationCodeAllowlist;
        }
        let updatedSecurityAlertEscalationActor = securityAlertEscalationActor;
        if (hasSecurityAlertEscalationActor) {
          if (typeof body.security_alert_escalation_actor !== 'string'
            || body.security_alert_escalation_actor.trim() === '') {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_actor'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_actor'
            });
            return;
          }
          updatedSecurityAlertEscalationActor = body.security_alert_escalation_actor.trim();
        }
        let updatedSecurityAlertEscalationNote = securityAlertEscalationNote;
        if (hasSecurityAlertEscalationNote) {
          if (typeof body.security_alert_escalation_note !== 'string') {
            appendPolicyAudit('policy.config.rejected', {
              error: 'invalid security_alert_escalation_note'
            }, {
              status: 400,
              remote_ip: remoteIp,
              authenticated: signatureResult.authenticated === true
            });
            sendJson(res, 400, {
              ok: false,
              error: 'invalid security_alert_escalation_note'
            });
            return;
          }
          updatedSecurityAlertEscalationNote = body.security_alert_escalation_note.trim();
        }
        securityAlertWebhookMinSeverity = updatedSecurityAlertWebhookMinSeverity;
        securityAlertWebhookCodeAllowlist = updatedSecurityAlertWebhookCodeAllowlist;
        securityAlertWebhookRoutes = updatedSecurityAlertWebhookRoutes;
        securityAlertEscalationEnabled = updatedSecurityAlertEscalationEnabled;
        securityAlertEscalationIntervalSeconds = updatedSecurityAlertEscalationIntervalSeconds;
        securityAlertEscalationAckDeadlineSeconds = updatedSecurityAlertEscalationAckDeadlineSeconds;
        securityAlertEscalationMinSeverity = updatedSecurityAlertEscalationMinSeverity;
        securityAlertEscalationCodeAllowlist = updatedSecurityAlertEscalationCodeAllowlist;
        securityAlertEscalationActor = updatedSecurityAlertEscalationActor;
        securityAlertEscalationNote = updatedSecurityAlertEscalationNote;
        refreshSecurityAlertEscalationScheduler();
        writePersistedPolicyConfig(policyPath, {
          whitelist_commands: updatedWhitelist,
          enforce_high_risk_reason: updatedEnforceHighRiskReason,
          security_alert_webhook_min_severity: updatedSecurityAlertWebhookMinSeverity,
          security_alert_webhook_code_allowlist: updatedSecurityAlertWebhookCodeAllowlist,
          security_alert_webhook_routes: updatedSecurityAlertWebhookRoutes,
          security_alert_escalation_enabled: updatedSecurityAlertEscalationEnabled,
          security_alert_escalation_interval_seconds: updatedSecurityAlertEscalationIntervalSeconds,
          security_alert_escalation_ack_deadline_seconds: updatedSecurityAlertEscalationAckDeadlineSeconds,
          security_alert_escalation_min_severity: updatedSecurityAlertEscalationMinSeverity,
          security_alert_escalation_code_allowlist: updatedSecurityAlertEscalationCodeAllowlist,
          security_alert_escalation_actor: updatedSecurityAlertEscalationActor,
          security_alert_escalation_note: updatedSecurityAlertEscalationNote
        });
        appendPolicyAudit('policy.config.updated', {
          whitelist_commands: updatedWhitelist,
          enforce_high_risk_reason: updatedEnforceHighRiskReason,
          security_alert_webhook_min_severity: updatedSecurityAlertWebhookMinSeverity,
          security_alert_webhook_code_allowlist: updatedSecurityAlertWebhookCodeAllowlist,
          security_alert_webhook_routes: updatedSecurityAlertWebhookRoutes,
          security_alert_escalation_enabled: updatedSecurityAlertEscalationEnabled,
          security_alert_escalation_interval_seconds: updatedSecurityAlertEscalationIntervalSeconds,
          security_alert_escalation_ack_deadline_seconds: updatedSecurityAlertEscalationAckDeadlineSeconds,
          security_alert_escalation_min_severity: updatedSecurityAlertEscalationMinSeverity,
          security_alert_escalation_code_allowlist: updatedSecurityAlertEscalationCodeAllowlist,
          security_alert_escalation_actor: updatedSecurityAlertEscalationActor,
          security_alert_escalation_note: updatedSecurityAlertEscalationNote
        }, {
          remote_ip: remoteIp,
          authenticated: signatureResult.authenticated === true
        });
        sendJson(res, 200, {
          ok: true,
          policy_path: policyPath,
          policy_config_signing_required: policyConfigSigningSecret !== '',
          whitelist_commands: updatedWhitelist,
          enforce_high_risk_reason: updatedEnforceHighRiskReason,
          security_alert_webhook_min_severity: updatedSecurityAlertWebhookMinSeverity,
          security_alert_webhook_code_allowlist: updatedSecurityAlertWebhookCodeAllowlist,
          security_alert_webhook_routes: updatedSecurityAlertWebhookRoutes,
          security_alert_escalation_enabled: updatedSecurityAlertEscalationEnabled,
          security_alert_escalation_interval_seconds: updatedSecurityAlertEscalationIntervalSeconds,
          security_alert_escalation_ack_deadline_seconds: updatedSecurityAlertEscalationAckDeadlineSeconds,
          security_alert_escalation_min_severity: updatedSecurityAlertEscalationMinSeverity,
          security_alert_escalation_code_allowlist: updatedSecurityAlertEscalationCodeAllowlist,
          security_alert_escalation_actor: updatedSecurityAlertEscalationActor,
          security_alert_escalation_note: updatedSecurityAlertEscalationNote
        });
      } catch (error) {
        appendPolicyAudit('policy.config.rejected', {
          error: error.message
        }, {
          status: 400,
          remote_ip: remoteIp
        });
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/policy/evaluate') {
      try {
        const body = await readJsonBody(req);
        const command = typeof body.command === 'string' ? body.command.trim() : '';
        if (!command) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing command'
          });
          return;
        }
        const evaluation = policyEngine.evaluateCommand(command);
        if (!evaluation) {
          sendJson(res, 400, {
            ok: false,
            error: 'command cannot be evaluated'
          });
          return;
        }
        sendJson(res, 200, {
          ok: true,
          command: evaluation.command,
          risk_level: evaluation.risk_level,
          policy: {
            requires_confirmation: evaluation.requires_confirmation,
            decision: evaluation.decision,
            matched_rule: evaluation.matched_rule,
            rationale: evaluation.rationale
          }
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/hooks/claude') {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      try {
        const body = await readJsonBody(req);
        const event = normalizeClaudeHookEvent(body);
        if (rejectHookApprovalDecision(event, res)) {
          return;
        }
        appendAndDispatch(event);
        sendJson(res, 200, {
          ok: true,
          event_id: event.id,
          session_id: event.session_id,
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/hooks/claude/session-start') {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      try {
        const body = await readJsonBody(req);
        const sessionId = extractSessionIdFromHookPayload(body);
        const event = normalizeClaudeHookEvent({
          session_id: sessionId,
          event_type: 'session_start',
          payload: body
        });
        appendAndDispatch(event);
        sendJson(res, 200, {
          ok: true,
          event_id: event.id,
          session_id: event.session_id,
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/claude/hooks/settings') {
      try {
        const body = await readJsonBody(req);
        const fallbackBaseUrl = `http://${req.headers.host || `${host}:${port}`}`;
        const template = buildClaudeSessionStartHookSettings(body.base_url || fallbackBaseUrl);
        sendJson(res, 200, {
          ok: true,
          ...template
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/claude/hooks/install') {
      try {
        const body = await readJsonBody(req);
        const fallbackBaseUrl = `http://${req.headers.host || `${host}:${port}`}`;
        const result = installClaudeSessionStartHook({
          baseUrl: body.base_url || fallbackBaseUrl,
          settingsPath: body.settings_path
        });
        sendJson(res, 200, {
          ok: true,
          ...result
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/hooks/codex') {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      try {
        const body = await readJsonBody(req);
        const event = normalizeCodexMcpEvent(body);
        if (rejectHookApprovalDecision(event, res)) {
          return;
        }
        appendAndDispatch(event);
        sendJson(res, 200, {
          ok: true,
          event_id: event.id,
          session_id: event.session_id,
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST'
      && (url.pathname === '/codex/sessions/start' || url.pathname === '/agents/sessions/start')) {
      try {
        const body = await readJsonBody(req);
        const sessionId = normalizeRuntimeSessionId(body.session_id);
        const runtime = normalizeAgentRuntime(body.runtime, agentRuntime);
        const requestedCommand = typeof body.command === 'string' && body.command.trim() !== ''
          ? body.command
          : (runtime === AGENT_RUNTIME_PI_RPC ? 'pi' : 'codex');
        const requestedArgs = Array.isArray(body.args) ? body.args.map(String) : [];
        const requestedMode = body.mode === 'mcp' ? 'mcp' : 'cli';
        const launch = runtime === AGENT_RUNTIME_PI_RPC
          ? piLaunchResolver({
            command: requestedCommand,
            args: requestedArgs,
            mode: 'rpc'
          })
          : codexLaunchResolver({
            command: requestedCommand,
            args: requestedArgs,
            mode: requestedMode
          });
        const command = launch.command;
        const args = launch.args;
        const cwd = typeof body.cwd === 'string' && body.cwd.trim() !== '' ? body.cwd : process.cwd();

        if (codexSessions.has(sessionId) || codexSessionAliasToBridgeSessionId.has(sessionId)) {
          sendJson(res, 409, {
            ok: false,
            error: 'session already running',
            session_id: sessionId
          });
          return;
        }

        const traceId = body.trace_id;
        appendCodexLifecycleEvent(sessionId, 'session_start', {
          runtime,
          command,
          args,
          cwd,
          mode: launch.mode,
          mcp_subcommand: launch.mcp_subcommand || null
        }, traceId);

        let ended = false;
        let startupSettled = false;
        let startupErrorMessage = '';
        let startupResolve = null;
        const startupPromise = new Promise((resolve) => {
          startupResolve = resolve;
        });
        let startupTimer = null;
        const startupGraceMs = runtime === AGENT_RUNTIME_PI_RPC ? 500 : 250;

        function settleStartup(result) {
          if (startupSettled) {
            return;
          }
          startupSettled = true;
          if (startupTimer) {
            clearTimeout(startupTimer);
            startupTimer = null;
          }
          startupResolve(result);
        }

        function formatStartupExitMessage(code, signal, fallback) {
          if (fallback) {
            return fallback;
          }
          const normalizedCode = code == null ? 'null' : String(code);
          const normalizedSignal = signal == null ? 'null' : String(signal);
          return `runtime exited during startup (code=${normalizedCode}, signal=${normalizedSignal})`;
        }

        const runtimeGeneration = randomUUID();
        const runnerFactory = runtime === AGENT_RUNTIME_PI_RPC ? piRunnerFactory : codexRunnerFactory;
        const runner = runnerFactory({
          sessionId,
          command,
          args,
          cwd,
          env: process.env,
          onEvent: (event) => {
            ingestCodexRunnerEvent(sessionId, runtimeGeneration, event);
            if (!startupSettled && runner.isRunning()) {
              settleStartup({ ok: true });
            }
          },
          onError: (error) => {
            const entry = codexSessions.get(sessionId);
            if (!entry || entry.runtime_generation !== runtimeGeneration) {
              return;
            }
            appendCodexLifecycleEvent(sessionId, 'error', {
              runtime,
              message: error.message
            }, traceId);
            startupErrorMessage = error.message;
            if (!startupSettled) {
              settleStartup({
                ok: false,
                error: formatStartupExitMessage(null, 'spawn_error', startupErrorMessage)
              });
            }
          },
          onSessionMeta: (metadata) => {
            const entry = codexSessions.get(sessionId);
            if (!entry
              || entry.runtime_generation !== runtimeGeneration
              || !metadata
              || typeof metadata !== 'object'
              || Array.isArray(metadata)) {
              return;
            }
            const piSessionId = normalizeOptionalString(metadata.pi_session_id, '');
            const sessionFile = normalizeOptionalString(metadata.session_file, '');
            if (!piSessionId && !sessionFile) {
              return;
            }
            entry.pi_session_id = piSessionId || null;
            entry.session_file = sessionFile || null;
            appendCodexLifecycleEvent(sessionId, 'session_update', {
              runtime,
              pi_session_id: entry.pi_session_id,
              session_file: entry.session_file
            }, traceId);
            if (!startupSettled && runner.isRunning()) {
              settleStartup({ ok: true });
            }
          },
          onExit: (code, signal) => {
            if (ended) {
              return;
            }
            ended = true;
            const entry = codexSessions.get(sessionId);
            if (!entry || entry.runtime_generation !== runtimeGeneration) {
              return;
            }
            if (!startupSettled) {
              settleStartup({
                ok: false,
                error: formatStartupExitMessage(code, signal, startupErrorMessage)
              });
            }
            appendCodexLifecycleEvent(sessionId, 'session_end', {
              runtime,
              code,
              signal
            }, traceId);
            clearCodexSessionAliases(sessionId);
            codexSessions.delete(sessionId);
          }
        });
        codexSessions.set(sessionId, {
          runner,
          runtime_generation: runtimeGeneration,
          outstandingElicitationByRequestId: new Map(),
          respondedDecisionByRequestId: new Map(),
          command,
          args,
          cwd,
          runtime,
          mode: launch.mode,
          mcp_subcommand: launch.mcp_subcommand || null,
          started_at: Math.floor(Date.now() / 1000),
          codex_session_id: null,
          pi_session_id: null,
          session_file: null
        });
        runner.start();
        startupTimer = setTimeout(() => {
          if (runner.isRunning()) {
            settleStartup({ ok: true });
            return;
          }
          settleStartup({
            ok: false,
            error: formatStartupExitMessage(null, null, startupErrorMessage)
          });
        }, startupGraceMs);
        const startupResult = await startupPromise;
        if (!startupResult.ok) {
          clearCodexSessionAliases(sessionId);
          codexSessions.delete(sessionId);
          sendJson(res, 502, {
            ok: false,
            error: startupResult.error,
            session_id: sessionId,
            bridge_session_id: sessionId,
            runtime
          });
          return;
        }
        const runtimeSession = codexSessions.get(sessionId);

        sendJson(res, 200, {
          ok: true,
          session_id: sessionId,
          bridge_session_id: sessionId,
          codex_session_id: normalizeOptionalString(runtimeSession?.codex_session_id, '') || null,
          pi_session_id: normalizeOptionalString(runtimeSession?.pi_session_id, '') || null,
          session_file: normalizeOptionalString(runtimeSession?.session_file, '') || null,
          provider: runtime,
          runtime,
          pid: runner.pid(),
          running: runner.isRunning(),
          mode: launch.mode,
          command,
          args,
          cwd,
          mcp_subcommand: launch.mcp_subcommand || null
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'GET'
      && (url.pathname === '/codex/runtime' || url.pathname === '/agents/runtime')) {
      const runtimeQuery = url.searchParams.get('runtime');
      const commandQuery = url.searchParams.get('command');
      const selectedRuntime = runtimeQuery
        ? normalizeAgentRuntime(runtimeQuery, agentRuntime)
        : (typeof commandQuery === 'string' && commandQuery.trim().toLowerCase() === 'pi'
            ? AGENT_RUNTIME_PI_RPC
            : (typeof commandQuery === 'string' && commandQuery.trim().toLowerCase() === 'codex'
                ? AGENT_RUNTIME_CODEX_CLI
                : agentRuntime));
      const command = typeof commandQuery === 'string' && commandQuery.trim() !== ''
        ? commandQuery
        : (selectedRuntime === AGENT_RUNTIME_PI_RPC ? 'pi' : 'codex');
      const runtime = selectedRuntime === AGENT_RUNTIME_PI_RPC
        ? piRuntimeInspector({ command })
        : codexRuntimeInspector({ command });
      const runtimeMode = normalizeOptionalString(
        runtime.mode,
        selectedRuntime === AGENT_RUNTIME_PI_RPC
          ? 'rpc'
          : (runtime.mcp_subcommand ? 'mcp' : 'cli')
      );
      const errorCode = normalizeOptionalString(runtime.error_code, null);
      const commandStatus = runtime.available === true
        ? 'available'
        : (errorCode === 'ENOENT' ? 'missing' : 'unavailable');
      sendJson(res, 200, {
        ok: true,
        provider: selectedRuntime,
        runtime: selectedRuntime,
        mode: runtimeMode,
        endpoint: url.pathname,
        bridge_version: bridgeVersion,
        command_status: commandStatus,
        ...runtime
      });
      return;
    }

    if (method === 'GET'
      && (url.pathname === '/codex/sessions'
        || url.pathname === '/agents/sessions'
        || url.pathname === '/v1/sessions')) {
      const versionedMobileRoute = url.pathname === '/v1/sessions';
      if (!(versionedMobileRoute
        ? hostSurfaceApi.authenticate(req, res)
        : requireLocalOrAuthenticated(req, res))) {
        return;
      }
      const sessions = Array.from(codexSessions.entries()).map(([sessionId, entry]) => (
        buildCodexSessionRuntimePayload(sessionId, entry)
      ));
      const responseSessions = (url.pathname === '/agents/sessions'
        || url.pathname === '/v1/sessions')
        ? sessions.concat(buildHostSessionSnapshots())
        : sessions;
      sendJson(res, 200, {
        ok: true,
        sessions: responseSessions
      });
      return;
    }

    const sessionDeleteMatch = url.pathname.match(/^\/(?:agents|v1)\/sessions\/([^/]+)$/);
    if (method === 'DELETE' && sessionDeleteMatch) {
      const versionedMobileRoute = url.pathname.startsWith('/v1/');
      if (!(versionedMobileRoute
        ? hostSurfaceApi.authenticate(req, res)
        : requireLocalOrAuthenticated(req, res))) {
        return;
      }
      const sessionId = safeDecodeURIComponent(sessionDeleteMatch[1]);
      if (!sessionId) {
        sendJson(res, 400, { ok: false, error: 'invalid session id' });
        return;
      }
      const cached = loadStoredHostSession(sessionId);
      if (!cached) {
        sendJson(res, 404, {
          ok: false,
          error: 'session not found',
          session_id: sessionId
        });
        return;
      }
      const metadata = cached.metadata;
      if (metadata.state !== 'completed') {
        sendJson(res, 409, {
          ok: false,
          error: 'only completed sessions can be deleted',
          session_id: sessionId,
          state: metadata.state
        });
        return;
      }
      const deletion = deleteSession(dataDir, sessionId);
      storedHostSessionCache.delete(sessionId);
      sendJson(res, 200, { ok: true, ...deletion });
      return;
    }

    const codexStopMatch = url.pathname.match(/^\/(?:codex|agents)\/sessions\/([^/]+)\/stop$/);
    if (method === 'POST' && codexStopMatch) {
      const sessionId = decodeURIComponent(codexStopMatch[1]);
      const lookup = resolveCodexSessionLookup(sessionId);
      if (!lookup) {
        sendJson(res, 404, {
          ok: false,
          error: 'session not running',
          session_id: sessionId
        });
        return;
      }
      const { bridge_session_id: bridgeSessionId, entry } = lookup;

      entry.runner.stop();
      sendJson(res, 200, {
        ok: true,
        session_id: bridgeSessionId,
        bridge_session_id: bridgeSessionId,
        codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
        pi_session_id: normalizeOptionalString(entry.pi_session_id, '') || null,
        session_file: normalizeOptionalString(entry.session_file, '') || null,
        provider: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
        runtime: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI)
      });
      return;
    }

    const codexCommandMatch = url.pathname.match(
      /^\/(?:codex|agents|v1)\/sessions\/([^/]+)\/command$/
    );
    if (method === 'POST' && codexCommandMatch) {
      if (url.pathname.startsWith('/v1/') && !hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(codexCommandMatch[1]);
      const lookup = resolveCodexSessionLookup(sessionId);
      if (!lookup) {
        sendJson(res, 404, {
          ok: false,
          error: 'session not running',
          session_id: sessionId
        });
        return;
      }
      const { bridge_session_id: bridgeSessionId, entry } = lookup;
      if (typeof entry.runner.sendCommand !== 'function') {
        sendJson(res, 409, {
          ok: false,
          error: 'runner does not support command dispatch',
          session_id: bridgeSessionId,
          bridge_session_id: bridgeSessionId,
          codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
          pi_session_id: normalizeOptionalString(entry.pi_session_id, '') || null
        });
        return;
      }

      try {
        const body = await readJsonBody(req);
        const commandType = typeof body.type === 'string' ? body.type.trim() : '';
        if (!allowedRuntimeCommandTypeSet.has(commandType)) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid command type'
          });
          return;
        }

        const message = typeof body.message === 'string' ? body.message.trim() : '';
        if (messageRequiredRuntimeCommandTypeSet.has(commandType) && !message) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing message'
          });
          return;
        }

        const commandPayload = { type: commandType };
        if (message) {
          commandPayload.message = message;
        }
        if (Array.isArray(body.images)) {
          commandPayload.images = body.images;
        }
        if (typeof body.id === 'string' && body.id.trim() !== '') {
          commandPayload.id = body.id.trim();
        }
        if (typeof body.streaming_behavior === 'string' && body.streaming_behavior.trim() !== '') {
          commandPayload.streamingBehavior = body.streaming_behavior.trim();
        }

        const commandResult = await Promise.resolve(entry.runner.sendCommand(commandPayload));
        const commandId = normalizeOptionalString(commandResult && commandResult.id, '') || null;
        const commandError = normalizeOptionalString(commandResult && commandResult.error, '');
        if (commandResult && commandResult.success === false) {
          sendJson(res, 502, {
            ok: false,
            error: commandError || 'rpc command rejected',
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
            pi_session_id: normalizeOptionalString(entry.pi_session_id, '') || null,
            command_id: commandId
          });
          return;
        }

        sendJson(res, 200, {
          ok: true,
          accepted: true,
          session_id: bridgeSessionId,
          bridge_session_id: bridgeSessionId,
          codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
          pi_session_id: normalizeOptionalString(entry.pi_session_id, '') || null,
          provider: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
          runtime: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
          command_type: commandType,
          command_id: commandId
        });
      } catch (error) {
        sendJson(res, 502, {
          ok: false,
          error: error.message,
          session_id: bridgeSessionId,
          bridge_session_id: bridgeSessionId,
          codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
          pi_session_id: normalizeOptionalString(entry.pi_session_id, '') || null
        });
      }
      return;
    }

    const agentApprovalRespondMatch = url.pathname.match(
      /^\/(?:agents|v1)\/sessions\/([^/]+)\/approval\/respond$/
    );
    if (method === 'POST' && agentApprovalRespondMatch) {
      const authorized = url.pathname.startsWith('/v1/')
        ? hostSurfaceApi.authenticate(req, res)
        : requireLocalOrAuthenticated(req, res);
      if (!authorized) {
        return;
      }
      const sessionId = decodeURIComponent(agentApprovalRespondMatch[1]);
      try {
        const body = await readJsonBody(req);
        const requestId = typeof body.request_id === 'string' ? body.request_id.trim() : '';
        if (!requestId) {
          const bindingError = permissionAgentRunBindingError(sessionId, body);
          if (bindingError) {
            sendJson(res, 409, {
              ok: false,
              error: bindingError,
              session_id: sessionId,
              request_event_id: body.request_event_id || null
            });
            return;
          }
          const requestEventID = normalizeOptionalString(body.request_event_id, '');
          const existingDecision = findPermissionDecisionEvent(dataDir, sessionId, requestEventID);
          if (existingDecision) {
            if (isConflictingPermissionDecision(existingDecision, body.decision)) {
              recordIdempotencyViolation(body.request_event_id);
              sendJson(res, 409, {
                ok: false,
                error: 'conflicting decision for an already-decided request',
                session_id: sessionId,
                request_event_id: body.request_event_id || null
              });
              return;
            }
            sendJson(res, 200, {
              ok: true,
              duplicate: true,
              event_id: existingDecision.id,
              session_id: existingDecision.session_id,
              provider: 'generic',
              type: existingDecision.type
            });
            return;
          }
          const mappedSessionID = approvalSessionByEventID.get(requestEventID);
          if (mappedSessionID && mappedSessionID !== sessionId) {
            sendJson(res, 409, {
              ok: false,
              error: 'approval request belongs to another session',
              session_id: sessionId,
              request_event_id: requestEventID || null
            });
            return;
          }
          const requestEvent = findSessionEventById(dataDir, sessionId, requestEventID);
          if (isBridgeRelayPermissionRequest(requestEvent)
            && !isApprovalRelayActive(requestEventID, requestEvent)) {
            sendJson(res, 409, {
              ok: false,
              error: 'approval relay expired; confirm on the host',
              session_id: sessionId,
              request_event_id: requestEventID || null
            });
            return;
          }
          const reason = normalizeReason(body.reason);
          if (requiresApprovalReason({
            sessionId,
            decision: body.decision,
            requestEventId: body.request_event_id
          }) && reason === '') {
            appendPolicyGateRejectionEvent(sessionId, {
              request_event_id: typeof body.request_event_id === 'string' ? body.request_event_id : null,
              endpoint: '/agents/sessions/:session_id/approval/respond',
              decision: body.decision
            });
            sendJson(res, 400, {
              ok: false,
              error: 'approval reason required for high-risk request'
            });
            return;
          }

          const event = buildPermissionDecisionEvent(sessionId, {
            ...body,
            reason
          });
          appendAndDispatch(event, { settleApprovalRelay: true });
          sendJson(res, 200, {
            ok: true,
            duplicate: false,
            event_id: event.id,
            session_id: event.session_id,
            provider: 'generic',
            type: event.type
          });
          return;
        }

        const lookup = resolveCodexSessionLookup(sessionId);
        if (!lookup) {
          sendJson(res, 404, {
            ok: false,
            error: 'session not running',
            session_id: sessionId
          });
          return;
        }
        const { bridge_session_id: bridgeSessionId, entry } = lookup;
        const decision = typeof body.decision === 'string' ? body.decision.trim() : '';
        if (!allowedDecisionSet.has(decision)) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid decision'
          });
          return;
        }
        const requestEventId = typeof body.request_event_id === 'string' ? body.request_event_id.trim() : '';
        const bindingError = permissionAgentRunBindingError(bridgeSessionId, body);
        const elicitationBindingError = bindingError || managedElicitationBindingError({
          entry,
          sessionId: bridgeSessionId,
          requestId,
          requestEventId
        });
        if (elicitationBindingError) {
          sendJson(res, 409, {
            ok: false,
            error: elicitationBindingError,
            session_id: bridgeSessionId,
            request_event_id: requestEventId || null
          });
          return;
        }
        if (entry.respondedDecisionByRequestId.has(requestId)) {
          const existingEventID = entry.respondedDecisionByRequestId.get(requestId);
          const existingEvent = findSessionEventById(dataDir, bridgeSessionId, existingEventID);
          if (isConflictingPermissionDecision(existingEvent, decision)) {
            recordIdempotencyViolation(requestEventId);
            sendJson(res, 409, {
              ok: false,
              error: 'conflicting decision for an already-decided request',
              session_id: bridgeSessionId,
              request_event_id: requestEventId || null
            });
            return;
          }
          sendJson(res, 200, {
            ok: true,
            duplicate: true,
            event_id: existingEventID,
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
            provider: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
            type: 'permission.decided'
          });
          return;
        }
        const reason = normalizeReason(body.reason);
        if (requiresApprovalReason({ sessionId: bridgeSessionId, decision, requestEventId }) && reason === '') {
          appendPolicyGateRejectionEvent(bridgeSessionId, {
            request_id: requestId,
            request_event_id: requestEventId || null,
            endpoint: '/agents/sessions/:session_id/approval/respond',
            decision
          });
          sendJson(res, 400, {
            ok: false,
            error: 'approval reason required for high-risk request'
          });
          return;
        }
        if (typeof entry.runner.respondElicitation !== 'function') {
          sendJson(res, 409, {
            ok: false,
            error: 'runner does not support elicitation response',
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null
          });
          return;
        }
        const accepted = entry.runner.respondElicitation(requestId, decision, reason);
        if (!accepted) {
          sendJson(res, 500, {
            ok: false,
            error: 'failed to send elicitation response',
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null
          });
          return;
        }

        const actor = typeof body.actor === 'string' && body.actor.trim() !== ''
          ? body.actor
          : 'ios';
        const event = normalizeCodexMcpEvent({
          session_id: bridgeSessionId,
          event_type: 'permission_decision',
          payload: {
            request_id: requestId,
            request_event_id: requestEventId,
            decision,
            actor,
            reason
          }
        });
        appendStoredSessionEvent(event);
        entry.outstandingElicitationByRequestId.delete(requestId);
        entry.respondedDecisionByRequestId.set(requestId, event.id);

        sendJson(res, 200, {
          ok: true,
          duplicate: false,
          event_id: event.id,
          session_id: bridgeSessionId,
          bridge_session_id: bridgeSessionId,
          codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
          provider: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    const codexElicitationRespondMatch = url.pathname.match(/^\/codex\/sessions\/([^/]+)\/elicitation\/respond$/);
    if (method === 'POST' && codexElicitationRespondMatch) {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(codexElicitationRespondMatch[1]);
      const lookup = resolveCodexSessionLookup(sessionId);
      if (!lookup) {
        sendJson(res, 404, {
          ok: false,
          error: 'session not running',
          session_id: sessionId
        });
        return;
      }
      const { bridge_session_id: bridgeSessionId, entry } = lookup;

      try {
        const body = await readJsonBody(req);
        const requestId = typeof body.request_id === 'string' ? body.request_id.trim() : '';
        if (!requestId) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing request_id'
          });
          return;
        }
        const decision = typeof body.decision === 'string' ? body.decision.trim() : '';
        if (!allowedDecisionSet.has(decision)) {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid decision'
          });
          return;
        }
        const requestEventId = typeof body.request_event_id === 'string' ? body.request_event_id.trim() : '';
        const bindingError = permissionAgentRunBindingError(bridgeSessionId, body);
        const elicitationBindingError = bindingError || managedElicitationBindingError({
          entry,
          sessionId: bridgeSessionId,
          requestId,
          requestEventId
        });
        if (elicitationBindingError) {
          sendJson(res, 409, {
            ok: false,
            error: elicitationBindingError,
            session_id: bridgeSessionId,
            request_event_id: requestEventId || null
          });
          return;
        }
        if (entry.respondedDecisionByRequestId.has(requestId)) {
          const existingEventID = entry.respondedDecisionByRequestId.get(requestId);
          const existingEvent = findSessionEventById(dataDir, bridgeSessionId, existingEventID);
          if (isConflictingPermissionDecision(existingEvent, decision)) {
            recordIdempotencyViolation(requestEventId);
            sendJson(res, 409, {
              ok: false,
              error: 'conflicting decision for an already-decided request',
              session_id: bridgeSessionId,
              request_event_id: requestEventId || null
            });
            return;
          }
          sendJson(res, 200, {
            ok: true,
            duplicate: true,
            event_id: existingEventID,
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
            type: 'permission.decided'
          });
          return;
        }
        const reason = normalizeReason(body.reason);
        if (requiresApprovalReason({ sessionId: bridgeSessionId, decision, requestEventId }) && reason === '') {
          appendPolicyGateRejectionEvent(bridgeSessionId, {
            request_id: requestId,
            request_event_id: requestEventId || null,
            endpoint: '/codex/sessions/:session_id/elicitation/respond',
            decision
          });
          sendJson(res, 400, {
            ok: false,
            error: 'approval reason required for high-risk request'
          });
          return;
        }
        if (typeof entry.runner.respondElicitation !== 'function') {
          sendJson(res, 409, {
            ok: false,
            error: 'runner does not support elicitation response',
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null
          });
          return;
        }
        const accepted = entry.runner.respondElicitation(requestId, decision, reason);
        if (!accepted) {
          sendJson(res, 500, {
            ok: false,
            error: 'failed to send elicitation response',
            session_id: bridgeSessionId,
            bridge_session_id: bridgeSessionId,
            codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null
          });
          return;
        }

        const actor = typeof body.actor === 'string' && body.actor.trim() !== ''
          ? body.actor
          : 'ios';
        const event = normalizeCodexMcpEvent({
          session_id: bridgeSessionId,
          event_type: 'permission_decision',
          payload: {
            request_id: requestId,
            request_event_id: requestEventId,
            decision,
            actor,
            reason
          }
        });
        appendStoredSessionEvent(event);
        entry.outstandingElicitationByRequestId.delete(requestId);
        entry.respondedDecisionByRequestId.set(requestId, event.id);

        sendJson(res, 200, {
          ok: true,
          duplicate: false,
          event_id: event.id,
          session_id: bridgeSessionId,
          bridge_session_id: bridgeSessionId,
          codex_session_id: normalizeOptionalString(entry.codex_session_id, '') || null,
          provider: normalizeAgentRuntime(entry.runtime, AGENT_RUNTIME_CODEX_CLI),
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    const permissionDecisionMatch = url.pathname.match(/^\/sessions\/([^/]+)\/permissions\/decide$/);
    if (method === 'POST' && permissionDecisionMatch) {
      if (!requireLocalOrAuthenticated(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(permissionDecisionMatch[1]);
      try {
        const body = await readJsonBody(req);
        const bindingError = permissionAgentRunBindingError(sessionId, body);
        if (bindingError) {
          sendJson(res, 409, {
            ok: false,
            error: bindingError,
            session_id: sessionId,
            request_event_id: body.request_event_id || null
          });
          return;
        }
        const existingDecision = findPermissionDecisionEvent(dataDir, sessionId, body.request_event_id);
        if (existingDecision) {
          if (isConflictingPermissionDecision(existingDecision, body.decision)) {
            recordIdempotencyViolation(body.request_event_id);
            sendJson(res, 409, {
              ok: false,
              error: 'conflicting decision for an already-decided request',
              session_id: sessionId,
              request_event_id: body.request_event_id || null
            });
            return;
          }
          sendJson(res, 200, {
            ok: true,
            duplicate: true,
            event_id: existingDecision.id,
            session_id: existingDecision.session_id,
            type: existingDecision.type
          });
          return;
        }
        const requestEventID = normalizeOptionalString(body.request_event_id, '');
        const requestEvent = findSessionEventById(dataDir, sessionId, requestEventID);
        if (isBridgeRelayPermissionRequest(requestEvent)
          && !isApprovalRelayActive(requestEventID, requestEvent)) {
          sendJson(res, 409, {
            ok: false,
            error: 'approval relay expired; confirm on the host',
            session_id: sessionId,
            request_event_id: requestEventID || null
          });
          return;
        }
        const reason = normalizeReason(body.reason);
        if (requiresApprovalReason({
          sessionId,
          decision: body.decision,
          requestEventId: body.request_event_id
        }) && reason === '') {
          appendPolicyGateRejectionEvent(sessionId, {
            request_event_id: typeof body.request_event_id === 'string' ? body.request_event_id : null,
            endpoint: '/sessions/:session_id/permissions/decide',
            decision: body.decision
          });
          sendJson(res, 400, {
            ok: false,
            error: 'approval reason required for high-risk request'
          });
          return;
        }

        const event = buildPermissionDecisionEvent(sessionId, {
          ...body,
          reason
        });
        appendAndDispatch(event, { settleApprovalRelay: true });
        sendJson(res, 200, {
          ok: true,
          duplicate: false,
          event_id: event.id,
          session_id: event.session_id,
          type: event.type
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    if (method === 'POST' && url.pathname === '/sessions/cursors/prune') {
      try {
        const body = await readJsonBody(req);
        let maxAgeSeconds = cursorMaxAgeSeconds;
        if (Object.prototype.hasOwnProperty.call(body, 'max_age_seconds')) {
          const parsedMaxAge = parseNonNegativeIntInput(body.max_age_seconds);
          if (parsedMaxAge === null) {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid max_age_seconds'
            });
            return;
          }
          maxAgeSeconds = parsedMaxAge;
        }
        const result = purgeExpiredSessionCursors(dataDir, {
          maxAgeSeconds,
          nowTimestampMs: Date.now()
        });
        sendJson(res, 200, {
          ok: true,
          max_age_seconds: maxAgeSeconds,
          removed_count: result.removed_count,
          removed_sessions: result.removed_sessions
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    const sessionMatch = url.pathname.match(/^\/sessions\/([^/]+)\/events$/)
      || url.pathname.match(/^\/agents\/sessions\/([^/]+)\/events$/)
      || url.pathname.match(/^\/v1\/sessions\/([^/]+)\/events$/);
    if (method === 'GET' && sessionMatch) {
      if (url.pathname.startsWith('/v1/') && !hostSurfaceApi.authenticate(req, res)) {
        return;
      }
      const sessionId = decodeURIComponent(sessionMatch[1]);
      const rawLimit = Number.parseInt(url.searchParams.get('limit') || '200', 10);
      const limit = Number.isFinite(rawLimit) ? rawLimit : 200;
      const cursor = url.searchParams.get('cursor') || undefined;
      const cachedEvents = loadStoredHostSession(sessionId)?.events;
      const replay = listSessionEventsWithCursor(dataDir, sessionId, {
        limit,
        cursor,
        events: cachedEvents
      });
      sendJson(res, 200, {
        ok: true,
        session_id: sessionId,
        events: replay.events,
        next_cursor: replay.next_cursor,
        has_more: replay.has_more,
        pending_count: replay.pending_count,
        reset_required: replay.reset_required
      });
      return;
    }

    const sessionArtifactsMatch = url.pathname.match(/^\/sessions\/([^/]+)\/artifacts$/)
      || url.pathname.match(/^\/agents\/sessions\/([^/]+)\/artifacts$/);
    if (method === 'GET' && sessionArtifactsMatch) {
      const sessionId = decodeURIComponent(sessionArtifactsMatch[1]);
      const artifacts = listSessionArtifacts(dataDir, sessionId);
      sendJson(res, 200, {
        ok: true,
        session_id: sessionId,
        artifacts
      });
      return;
    }

    const sessionCursorMatch = url.pathname.match(/^\/sessions\/([^/]+)\/cursor$/)
      || url.pathname.match(/^\/agents\/sessions\/([^/]+)\/cursor$/);
    if (method === 'GET' && sessionCursorMatch) {
      const sessionId = decodeURIComponent(sessionCursorMatch[1]);
      const cursorState = loadSessionCursor(dataDir, sessionId, {
        maxAgeSeconds: cursorMaxAgeSeconds
      });
      sendJson(res, 200, {
        ok: true,
        ...cursorState
      });
      return;
    }

    if (method === 'POST' && sessionCursorMatch) {
      const sessionId = decodeURIComponent(sessionCursorMatch[1]);
      try {
        const body = await readJsonBody(req);
        if (!Object.prototype.hasOwnProperty.call(body, 'cursor')) {
          sendJson(res, 400, {
            ok: false,
            error: 'missing cursor'
          });
          return;
        }
        if (body.cursor !== null && typeof body.cursor !== 'string') {
          sendJson(res, 400, {
            ok: false,
            error: 'invalid cursor'
          });
          return;
        }
        let ifMatchUpdatedTimestamp = null;
        if (Object.prototype.hasOwnProperty.call(body, 'if_match_updated_timestamp')) {
          if (body.if_match_updated_timestamp === null || body.if_match_updated_timestamp === '') {
            ifMatchUpdatedTimestamp = null;
          } else if (Number.isFinite(body.if_match_updated_timestamp)) {
            ifMatchUpdatedTimestamp = Math.trunc(body.if_match_updated_timestamp);
          } else {
            sendJson(res, 400, {
              ok: false,
              error: 'invalid if_match_updated_timestamp'
            });
            return;
          }
        }
        const currentState = loadSessionCursor(dataDir, sessionId, {
          maxAgeSeconds: cursorMaxAgeSeconds
        });
        if (ifMatchUpdatedTimestamp !== null) {
          const currentVersion = Number.isFinite(currentState.updated_timestamp)
            ? Math.trunc(currentState.updated_timestamp)
            : null;
          if (currentVersion !== ifMatchUpdatedTimestamp) {
            try {
              appendCursorOperationRecord(dataDir, {
                session_id: sessionId,
                outcome: 'conflict',
                if_match_provided: true
              });
            } catch {
              // best-effort metrics instrumentation
            }
            sendJson(res, 409, {
              ok: false,
              error: 'cursor version conflict',
              session_id: currentState.session_id,
              expected_updated_timestamp: ifMatchUpdatedTimestamp,
              current: currentState
            });
            return;
          }
        }
        const cursorState = saveSessionCursor(dataDir, sessionId, body.cursor);
        try {
          appendCursorOperationRecord(dataDir, {
            session_id: sessionId,
            outcome: 'success',
            if_match_provided: ifMatchUpdatedTimestamp !== null
          });
        } catch {
          // best-effort metrics instrumentation
        }
        sendJson(res, 200, {
          ok: true,
          ...cursorState
        });
      } catch (error) {
        sendJson(res, 400, {
          ok: false,
          error: error.message
        });
      }
      return;
    }

    sendJson(res, 404, { ok: false, error: 'not found' });
   } catch (error) {
      // Backstop: never let a thrown route handler (e.g. a URIError from a
      // malformed path, or any unexpected failure) reject the async server
      // callback into an unhandled rejection that hangs the socket or takes
      // down the daemon.
      if (!res.headersSent) {
        sendJson(res, 500, { ok: false, error: 'internal error' });
      } else {
        try { res.end(); } catch { /* already closed */ }
      }
    }
  });

  function start() {
    return new Promise((resolve, reject) => {
      server.listen(port, host, async () => {
        const address = server.address();
        const resolvedPort = typeof address === 'object' && address ? address.port : port;
        runtimeBaseUrl = `http://${host}:${resolvedPort}`;
        try {
          await hostControlSocket?.start();
          resolve({
            server,
            host,
            port: resolvedPort,
            baseUrl: `http://${host}:${resolvedPort}`,
            serverBootID,
            controlSocketPath: hostControlSocket?.socketPath || null,
            close: async () => {
              stopSecurityAlertEscalationScheduler();
              stopMetricsAnomalyDispatchScheduler();
              releaseApprovalDecisionWaiters();
              await hostControlSocket?.close();
              attachTicketStore?.clear?.();
              if (ownsSurfaceRegistry) {
                surfaceRegistry.dispose();
              }
              await new Promise((done, fail) => {
                server.close((err) => (err ? fail(err) : done()));
              });
            }
          });
        } catch (error) {
          server.close();
          reject(error);
        }
      });
    });
  }

  return { start, server };
}

async function startBridge(options = {}) {
  const bridge = createBridgeServer(options);
  return bridge.start();
}

if (require.main === module) {
  const host = process.env.BRIDGE_HOST || '127.0.0.1';
  const port = Number.parseInt(process.env.BRIDGE_PORT || '24000', 10);
  const dataDir = process.env.BRIDGE_DATA_DIR || path.join(process.cwd(), 'data');

  startBridge({ host, port, dataDir }).then((bridge) => {
    // eslint-disable-next-line no-console
    console.log(`[nomad-bridge] listening on ${bridge.baseUrl} dataDir=${dataDir}`);
  });
}

module.exports = {
  createBridgeServer,
  startBridge
};
