#!/usr/bin/env node

const http = require('node:http');
const https = require('node:https');

const baseUrlArg = process.argv[2];

if (!baseUrlArg) {
  process.exit(1);
}

let endpoint;
try {
  const normalized = new URL(baseUrlArg);
  normalized.pathname = '/hooks/claude/session-start';
  normalized.search = '';
  endpoint = normalized;
} catch {
  process.exit(1);
}

const chunks = [];
process.stdin.on('data', (chunk) => {
  chunks.push(chunk);
});

process.stdin.on('end', () => {
  const body = Buffer.concat(chunks);
  const transport = endpoint.protocol === 'https:' ? https : http;
  const req = transport.request({
    protocol: endpoint.protocol,
    hostname: endpoint.hostname,
    port: endpoint.port || undefined,
    method: 'POST',
    path: endpoint.pathname,
    headers: {
      'content-type': 'application/json',
      'content-length': body.length
    }
  }, (res) => {
    res.resume();
  });

  req.on('error', () => {
    // hook must be best-effort; never block claude execution
  });
  req.end(body);
});

process.stdin.resume();
