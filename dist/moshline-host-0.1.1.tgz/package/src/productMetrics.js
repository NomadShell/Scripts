'use strict';

const fs = require('node:fs');
const path = require('node:path');

const EVENT_TYPES = new Set([
  'setup.started',
  'setup.completed',
  'notification.received',
  'notification.decision',
  'approval.round_trip.succeeded',
  'approval.round_trip.failed',
  'approval.idempotency_violation',
  'route.attach.attempted',
  'route.attach.succeeded',
  'route.attach.mismatch',
  'route.fallback',
  'reconnect.attempted',
  'reconnect.succeeded',
  'app.active',
  'conversion.eligible',
  'conversion.pro'
]);

const ALLOWED_FIELDS = new Set([
  'event_id',
  'type',
  'timestamp',
  'installation_id',
  'host_id',
  'agent_run_id',
  'flow_id',
  'network_handoff',
  'host_count',
  'provider_count'
]);

function normalizedString(value, field, { required = false, maxLength = 128 } = {}) {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if (required && normalized === '') {
    throw new Error(`${field} is required`);
  }
  if (normalized.length > maxLength) {
    throw new Error(`${field} is too long`);
  }
  return normalized || null;
}

function normalizeTimestamp(value) {
  let milliseconds = null;
  if (typeof value === 'number' && Number.isFinite(value)) {
    milliseconds = Math.abs(value) >= 100_000_000_000 ? value : value * 1000;
  } else if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Date.parse(value);
    milliseconds = Number.isFinite(parsed) ? parsed : null;
  }
  if (milliseconds === null || !Number.isFinite(milliseconds)) {
    throw new Error('timestamp must be an epoch number or ISO date');
  }
  const timestamp = Math.floor(milliseconds / 1000);
  if (!Number.isSafeInteger(timestamp) || timestamp <= 0) {
    throw new Error('timestamp is outside the supported range');
  }
  return timestamp;
}

function normalizeCount(value, field) {
  if (value === undefined || value === null) {
    return null;
  }
  if (!Number.isInteger(value) || value < 0 || value > 10_000) {
    throw new Error(`${field} must be an integer from 0 through 10000`);
  }
  return value;
}

function normalizeEvent(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('product metric event must be an object');
  }
  for (const field of Object.keys(input)) {
    if (!ALLOWED_FIELDS.has(field)) {
      throw new Error(`unsupported product metric field: ${field}`);
    }
  }
  const type = normalizedString(input.type, 'type', { required: true, maxLength: 64 });
  if (!EVENT_TYPES.has(type)) {
    throw new Error(`unsupported product metric type: ${type}`);
  }
  if (input.network_handoff !== undefined && typeof input.network_handoff !== 'boolean') {
    throw new Error('network_handoff must be a boolean');
  }
  return {
    event_id: normalizedString(input.event_id, 'event_id', { required: true }),
    type,
    timestamp: normalizeTimestamp(input.timestamp),
    installation_id: normalizedString(input.installation_id, 'installation_id', { required: true }),
    host_id: normalizedString(input.host_id, 'host_id'),
    agent_run_id: normalizedString(input.agent_run_id, 'agent_run_id'),
    flow_id: normalizedString(input.flow_id, 'flow_id'),
    network_handoff: input.network_handoff === true,
    host_count: normalizeCount(input.host_count, 'host_count'),
    provider_count: normalizeCount(input.provider_count, 'provider_count')
  };
}

function readRecords(filePath) {
  if (!fs.existsSync(filePath)) {
    return [];
  }
  return fs.readFileSync(filePath, 'utf8')
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      try {
        return normalizeEvent(JSON.parse(line));
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .sort((left, right) => left.timestamp - right.timestamp);
}

function ratio(numerator, denominator) {
  if (denominator <= 0) {
    return null;
  }
  return Math.round((numerator / denominator) * 10_000) / 10_000;
}

function median(values) {
  if (values.length === 0) {
    return null;
  }
  const sorted = [...values].sort((left, right) => left - right);
  const midpoint = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) {
    return sorted[midpoint];
  }
  return Math.round((sorted[midpoint - 1] + sorted[midpoint]) / 2);
}

function pairKey(event) {
  return `${event.installation_id}|${event.host_id || 'unknown-host'}`;
}

function buildSummary(records, { windowSeconds, nowTimestamp }) {
  const endTimestamp = nowTimestamp;
  const startTimestamp = endTimestamp - windowSeconds;
  const windowRecords = records.filter((event) => (
    event.timestamp >= startTimestamp && event.timestamp <= endTimestamp
  ));
  const count = (type) => windowRecords.filter((event) => event.type === type).length;

  const setupStarted = new Set();
  const setupCompleted = new Map();
  const firstNotification = new Map();
  const notificationByFlow = new Map();
  const notificationReceivedKeys = new Set();
  const notificationDecisionKeys = new Set();
  const decisionLatencies = [];
  for (const event of windowRecords) {
    const key = pairKey(event);
    if (event.type === 'setup.started') {
      setupStarted.add(key);
    } else if (event.type === 'setup.completed') {
      const existing = setupCompleted.get(key);
      setupCompleted.set(key, existing === undefined ? event.timestamp : Math.min(existing, event.timestamp));
    } else if (event.type === 'notification.received') {
      const existing = firstNotification.get(key);
      firstNotification.set(key, existing === undefined ? event.timestamp : Math.min(existing, event.timestamp));
      const flowKey = event.flow_id ? `${key}|${event.flow_id}` : event.event_id;
      notificationReceivedKeys.add(flowKey);
      if (event.flow_id && !notificationByFlow.has(flowKey)) {
        notificationByFlow.set(flowKey, event.timestamp);
      }
    } else if (event.type === 'notification.decision' && event.flow_id) {
      const flowKey = `${key}|${event.flow_id}`;
      const notificationTimestamp = notificationByFlow.get(flowKey);
      if (!notificationDecisionKeys.has(flowKey)
          && notificationTimestamp !== undefined
          && event.timestamp >= notificationTimestamp) {
        notificationDecisionKeys.add(flowKey);
        decisionLatencies.push((event.timestamp - notificationTimestamp) * 1000);
      }
    } else if (event.type === 'notification.decision') {
      notificationDecisionKeys.add(event.event_id);
    }
  }
  const pairingLatencies = [];
  for (const [key, pairedAt] of setupCompleted.entries()) {
    const notifiedAt = firstNotification.get(key);
    if (notifiedAt !== undefined && notifiedAt >= pairedAt) {
      pairingLatencies.push((notifiedAt - pairedAt) * 1000);
    }
  }
  const setupCompletedAfterStart = [...setupStarted]
    .filter((key) => setupCompleted.has(key)).length;

  const approvalSucceeded = count('approval.round_trip.succeeded');
  const approvalFailed = count('approval.round_trip.failed');
  const approvalAttempted = approvalSucceeded + approvalFailed;
  const attachAttempted = count('route.attach.attempted');
  const attachSucceeded = count('route.attach.succeeded');
  const routeMismatches = count('route.attach.mismatch');
  const fallbackCount = count('route.fallback');
  const reconnectAttempted = count('reconnect.attempted');
  const reconnectSucceeded = count('reconnect.succeeded');
  const handoffAttempted = windowRecords.filter((event) => (
    event.type === 'reconnect.attempted' && event.network_handoff
  )).length;
  const handoffSucceeded = windowRecords.filter((event) => (
    event.type === 'reconnect.succeeded' && event.network_handoff
  )).length;

  const firstEventByInstallation = new Map();
  const activeByInstallation = new Map();
  for (const event of records.filter((candidate) => candidate.timestamp <= endTimestamp)) {
    const first = firstEventByInstallation.get(event.installation_id);
    if (first === undefined || event.timestamp < first) {
      firstEventByInstallation.set(event.installation_id, event.timestamp);
    }
    if (event.type === 'app.active') {
      if (!activeByInstallation.has(event.installation_id)) {
        activeByInstallation.set(event.installation_id, []);
      }
      activeByInstallation.get(event.installation_id).push(event.timestamp);
    }
  }
  let retentionEligible = 0;
  let retentionW4 = 0;
  for (const [installationID, firstAt] of firstEventByInstallation.entries()) {
    if (firstAt > endTimestamp - (28 * 86_400)) {
      continue;
    }
    retentionEligible += 1;
    const active = activeByInstallation.get(installationID) || [];
    if (active.some((timestamp) => (
      timestamp >= firstAt + (21 * 86_400) && timestamp <= firstAt + (35 * 86_400)
    ))) {
      retentionW4 += 1;
    }
  }

  const conversionEligible = new Set(windowRecords
    .filter((event) => event.type === 'conversion.eligible')
    .map((event) => event.installation_id));
  const converted = new Set(windowRecords
    .filter((event) => event.type === 'conversion.pro' && conversionEligible.has(event.installation_id))
    .map((event) => event.installation_id));

  return {
    window_seconds: windowSeconds,
    start_timestamp: startTimestamp,
    end_timestamp: endTimestamp,
    activation: {
      setup_started: setupStarted.size,
      setup_completed: setupCompletedAfterStart,
      setup_completion_rate: ratio(setupCompletedAfterStart, setupStarted.size),
      pairing_to_first_notification_median_ms: median(pairingLatencies)
    },
    loop: {
      notifications_received: notificationReceivedKeys.size,
      notification_decisions: notificationDecisionKeys.size,
      notification_to_decision_median_ms: median(decisionLatencies),
      approval_round_trip_attempted: approvalAttempted,
      approval_round_trip_succeeded: approvalSucceeded,
      approval_round_trip_success_rate: ratio(approvalSucceeded, approvalAttempted),
      idempotency_violations: count('approval.idempotency_violation')
    },
    truth: {
      attach_attempted: attachAttempted,
      attach_succeeded: attachSucceeded,
      route_mismatches: routeMismatches,
      route_mismatch_rate: ratio(routeMismatches, attachAttempted),
      fallback_count: fallbackCount,
      fallback_rate: ratio(fallbackCount, fallbackCount + attachSucceeded),
      reconnect_attempted: reconnectAttempted,
      reconnect_succeeded: reconnectSucceeded,
      reconnect_success_rate: ratio(reconnectSucceeded, reconnectAttempted),
      handoff_reconnect_success_rate: ratio(handoffSucceeded, handoffAttempted)
    },
    retention: {
      w4_eligible_installations: retentionEligible,
      w4_retained_installations: retentionW4,
      w4_rate: ratio(retentionW4, retentionEligible)
    },
    conversion: {
      eligible_installations: conversionEligible.size,
      pro_installations: converted.size,
      free_to_pro_rate: ratio(converted.size, conversionEligible.size)
    }
  };
}

function createProductMetricStore({ filePath }) {
  const eventIDs = new Set(readRecords(filePath).map((event) => event.event_id));

  function append(input) {
    const event = normalizeEvent(input);
    if (eventIDs.has(event.event_id)) {
      return { accepted: false, duplicate: true, event };
    }
    fs.mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
    fs.appendFileSync(filePath, `${JSON.stringify(event)}\n`, { mode: 0o600 });
    fs.chmodSync(filePath, 0o600);
    eventIDs.add(event.event_id);
    return { accepted: true, duplicate: false, event };
  }

  function summary({
    windowSeconds = 2_592_000,
    nowTimestamp = Math.floor(Date.now() / 1000)
  } = {}) {
    return buildSummary(readRecords(filePath), { windowSeconds, nowTimestamp });
  }

  return { append, summary };
}

module.exports = {
  EVENT_TYPES,
  createProductMetricStore,
  normalizeEvent
};
