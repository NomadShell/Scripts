'use strict';

const fs = require('node:fs');
const path = require('node:path');

function normalizeRule(rule) {
  const project = typeof rule?.project === 'string' ? rule.project.trim() : '';
  const eventType = typeof rule?.event_type === 'string' ? rule.event_type.trim() : '';
  if (!project || !eventType || typeof rule.push !== 'boolean') {
    throw new Error('invalid notification rule');
  }
  return { project, event_type: eventType, push: rule.push };
}

function createNotificationRoutingStore({ filePath }) {
  let rules = [];
  try {
    rules = JSON.parse(fs.readFileSync(filePath, 'utf8')).rules.map(normalizeRule);
  } catch {
    rules = [];
  }
  return {
    list: () => rules.map((rule) => ({ ...rule })),
    replace(nextRules) {
      if (!Array.isArray(nextRules) || nextRules.length > 100) {
        throw new Error('notification rules must be an array of at most 100 items');
      }
      rules = nextRules.map(normalizeRule);
      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      const temporaryPath = `${filePath}.tmp-${process.pid}`;
      fs.writeFileSync(temporaryPath, `${JSON.stringify({ rules }, null, 2)}\n`, { mode: 0o600 });
      fs.renameSync(temporaryPath, filePath);
      return this.list();
    },
    shouldPush(event) {
      const project = typeof event?.payload?.project_name === 'string'
        ? event.payload.project_name.trim()
        : '';
      const exact = rules.find((rule) => rule.event_type === event?.type && rule.project === project);
      const wildcard = rules.find((rule) => rule.event_type === event?.type && rule.project === '*');
      return (exact || wildcard)?.push ?? true;
    }
  };
}

module.exports = { createNotificationRoutingStore };
