'use strict';

const fs = require('node:fs');
const path = require('node:path');

const MAX_TRANSCRIPT_TAIL_BYTES = 2 * 1024 * 1024;

function isObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function finiteNonNegative(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
    ? value
    : null;
}

function allowedTranscriptPath(filePath, { home, codexHome } = {}) {
  if (typeof filePath !== 'string' || filePath.trim() === '') {
    return null;
  }
  const resolvedHome = typeof home === 'string' && home.trim() !== ''
    ? path.resolve(home)
    : null;
  const resolvedCodexHome = path.resolve(
    typeof codexHome === 'string' && codexHome.trim() !== ''
      ? codexHome
      : path.join(resolvedHome || '', '.codex')
  );
  const candidate = path.resolve(filePath);
  const roots = [
    path.join(resolvedCodexHome, 'sessions'),
    path.join(resolvedCodexHome, 'archived_sessions')
  ];
  return roots.some((root) => candidate === root || candidate.startsWith(`${root}${path.sep}`))
    ? candidate
    : null;
}

function readTail(filePath, maxBytes = MAX_TRANSCRIPT_TAIL_BYTES) {
  const stat = fs.statSync(filePath);
  const bytes = Math.min(stat.size, maxBytes);
  const start = stat.size - bytes;
  const descriptor = fs.openSync(filePath, 'r');
  try {
    const buffer = Buffer.alloc(bytes);
    fs.readSync(descriptor, buffer, 0, bytes, start);
    let text = buffer.toString('utf8');
    if (start > 0) {
      const newline = text.indexOf('\n');
      text = newline >= 0 ? text.slice(newline + 1) : '';
    }
    return text;
  } finally {
    fs.closeSync(descriptor);
  }
}

function windowLabel(minutes) {
  if (!Number.isFinite(minutes) || minutes <= 0) {
    return 'Rate limit';
  }
  if (minutes % 10_080 === 0) {
    const days = (minutes / 1_440);
    return `${days} day`;
  }
  if (minutes % 1_440 === 0) {
    return `${minutes / 1_440} day`;
  }
  if (minutes % 60 === 0) {
    return `${minutes / 60} hour`;
  }
  return `${minutes} minute`;
}

function isoTimestamp(value) {
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? new Date(parsed).toISOString() : null;
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    const milliseconds = Math.abs(value) >= 100_000_000_000 ? value : value * 1000;
    return new Date(milliseconds).toISOString();
  }
  return null;
}

function normalizeRateLimitWindow(kind, value, capturedAt) {
  if (!isObject(value)) {
    return null;
  }
  const usedPercent = finiteNonNegative(value.used_percent);
  if (usedPercent === null || usedPercent > 100) {
    return null;
  }
  const minutes = finiteNonNegative(value.window_minutes);
  return {
    id: `codex-${kind}-${minutes ?? 'unknown'}m`,
    label: windowLabel(minutes),
    ...(minutes !== null ? { duration_seconds: minutes * 60 } : {}),
    used_fraction: usedPercent / 100,
    remaining_fraction: 1 - (usedPercent / 100),
    ...(isoTimestamp(value.resets_at) ? { resets_at: isoTimestamp(value.resets_at) } : {}),
    captured_at: capturedAt
  };
}

function usageFromTokenCount(record) {
  if (!isObject(record) || record.type !== 'event_msg'
      || record.payload?.type !== 'token_count') {
    return null;
  }
  const capturedAt = isoTimestamp(record.timestamp) || new Date().toISOString();
  const info = isObject(record.payload.info) ? record.payload.info : {};
  const tokenUsage = isObject(info.last_token_usage)
    ? info.last_token_usage
    : (isObject(info.total_token_usage) ? info.total_token_usage : {});
  const contextUsed = finiteNonNegative(tokenUsage.total_tokens);
  const contextLimit = finiteNonNegative(info.model_context_window);
  const rateLimits = isObject(record.payload.rate_limits) ? record.payload.rate_limits : {};
  const windows = ['primary', 'secondary']
    .map((kind) => normalizeRateLimitWindow(kind, rateLimits[kind], capturedAt))
    .filter(Boolean);
  if (contextUsed === null && contextLimit === null && windows.length === 0) {
    return null;
  }
  const planType = typeof rateLimits.plan_type === 'string'
    ? rateLimits.plan_type.trim()
    : '';
  return {
    capturedAt,
    usage: {
      schema_version: windows.length > 0 ? 2 : 1,
      provider: 'codex',
      ...(planType ? { account_label: planType } : {}),
      captured_at: capturedAt,
      ...(contextUsed !== null ? { context_used_tokens: contextUsed } : {}),
      ...(contextLimit !== null ? { context_limit_tokens: contextLimit } : {}),
      ...(windows.length > 0 ? { windows } : {})
    },
    tokenUsage: {
      input_tokens: finiteNonNegative(tokenUsage.input_tokens),
      cached_input_tokens: finiteNonNegative(tokenUsage.cached_input_tokens),
      output_tokens: finiteNonNegative(tokenUsage.output_tokens),
      reasoning_output_tokens: finiteNonNegative(tokenUsage.reasoning_output_tokens),
      total_tokens: contextUsed
    }
  };
}

function readCodexTranscriptUsage(filePath, options = {}) {
  const allowed = allowedTranscriptPath(filePath, options);
  if (!allowed) {
    return null;
  }
  let lines;
  try {
    lines = readTail(allowed).split('\n').filter(Boolean);
  } catch {
    return null;
  }
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try {
      const usage = usageFromTokenCount(JSON.parse(lines[index]));
      if (usage) {
        return usage;
      }
    } catch {
      // Ignore truncated or provider-specific records and continue backwards.
    }
  }
  return null;
}

module.exports = {
  allowedTranscriptPath,
  readCodexTranscriptUsage,
  usageFromTokenCount
};
