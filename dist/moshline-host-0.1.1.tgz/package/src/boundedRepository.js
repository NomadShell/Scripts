'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const LANGUAGE_BY_EXTENSION = Object.freeze({
  '.c': 'c',
  '.cc': 'cpp',
  '.cpp': 'cpp',
  '.css': 'css',
  '.go': 'go',
  '.h': 'c',
  '.hpp': 'cpp',
  '.html': 'html',
  '.java': 'java',
  '.js': 'javascript',
  '.json': 'json',
  '.jsx': 'javascript',
  '.kt': 'kotlin',
  '.log': 'log',
  '.md': 'markdown',
  '.m': 'objective-c',
  '.mm': 'objective-cpp',
  '.php': 'php',
  '.py': 'python',
  '.rb': 'ruby',
  '.rs': 'rust',
  '.sh': 'shell',
  '.sql': 'sql',
  '.swift': 'swift',
  '.ts': 'typescript',
  '.tsx': 'typescript',
  '.xml': 'xml',
  '.yaml': 'yaml',
  '.yml': 'yaml'
});

function normalizeRelativePath(value) {
  if (value === undefined || value === null || value === '') {
    return '';
  }
  if (typeof value !== 'string'
    || value.includes('\0')
    || value.includes('\\')
    || path.posix.isAbsolute(value)) {
    throw new Error('file path must be a safe relative path');
  }
  const normalized = path.posix.normalize(value);
  if (normalized === '..' || normalized.startsWith('../') || normalized === '.') {
    if (normalized === '.') {
      return '';
    }
    throw new Error('file path must be a safe relative path');
  }
  return normalized;
}

function workspaceRoot(workspace) {
  if (typeof workspace !== 'string' || !path.isAbsolute(workspace)) {
    throw new Error('session workspace is invalid');
  }
  const root = fs.realpathSync(workspace);
  if (!fs.statSync(root).isDirectory()) {
    throw new Error('session workspace is invalid');
  }
  return root;
}

function resolveContained(root, relativePath) {
  const unresolved = path.resolve(root, relativePath);
  const resolved = fs.realpathSync(unresolved);
  if (resolved !== root && !resolved.startsWith(`${root}${path.sep}`)) {
    throw new Error('file path escapes the session workspace');
  }
  return resolved;
}

function languageFor(relativePath) {
  return LANGUAGE_BY_EXTENSION[path.extname(relativePath).toLowerCase()] || 'plain-text';
}

function createBoundedRepositoryReader({
  maxEntries = 500,
  maxReadBytes = 512 * 1024
} = {}) {
  function selfCheck(workspace) {
    try {
      workspaceRoot(workspace);
      return true;
    } catch {
      return false;
    }
  }

  function list({ workspace, relativePath = '' }) {
    const root = workspaceRoot(workspace);
    const normalizedPath = normalizeRelativePath(relativePath);
    const absolutePath = resolveContained(root, normalizedPath);
    const directoryStat = fs.lstatSync(absolutePath);
    if (!directoryStat.isDirectory() || directoryStat.isSymbolicLink()) {
      throw new Error('file path is not a directory');
    }
    const allEntries = fs.readdirSync(absolutePath, { withFileTypes: true })
      .map((entry) => {
        const entryPath = path.join(absolutePath, entry.name);
        const stat = fs.lstatSync(entryPath);
        const kind = stat.isDirectory()
          ? 'directory'
          : stat.isFile()
            ? 'file'
            : stat.isSymbolicLink()
              ? 'symlink'
              : 'special';
        return {
          name: entry.name,
          path: normalizedPath ? path.posix.join(normalizedPath, entry.name) : entry.name,
          kind,
          size_bytes: stat.isFile() ? stat.size : null,
          modified_at: stat.mtime.toISOString()
        };
      })
      .sort((left, right) => {
        if (left.kind === 'directory' && right.kind !== 'directory') return -1;
        if (right.kind === 'directory' && left.kind !== 'directory') return 1;
        return left.name.localeCompare(right.name);
      });
    return {
      path: normalizedPath,
      entries: allEntries.slice(0, maxEntries),
      truncated: allEntries.length > maxEntries,
      entry_limit: maxEntries
    };
  }

  function read({ workspace, relativePath }) {
    const root = workspaceRoot(workspace);
    const normalizedPath = normalizeRelativePath(relativePath);
    if (normalizedPath === '') {
      throw new Error('file path must name a file');
    }
    const unresolved = path.resolve(root, normalizedPath);
    const linkStat = fs.lstatSync(unresolved);
    if (linkStat.isSymbolicLink()) {
      const resolved = fs.realpathSync(unresolved);
      if (resolved !== root && !resolved.startsWith(`${root}${path.sep}`)) {
        throw new Error('file path escapes the session workspace');
      }
      throw new Error('symbolic links cannot be read');
    }
    const absolutePath = resolveContained(root, normalizedPath);
    const stat = fs.statSync(absolutePath);
    if (!stat.isFile()) {
      throw new Error('file path is not a regular file');
    }
    if (stat.size > maxReadBytes) {
      throw new Error('file exceeds the read size limit');
    }
    const data = fs.readFileSync(absolutePath);
    let content;
    try {
      content = new TextDecoder('utf-8', { fatal: true }).decode(data);
    } catch {
      throw new Error('binary files cannot be rendered');
    }
    if (content.includes('\0')) {
      throw new Error('binary files cannot be rendered');
    }
    return {
      path: normalizedPath,
      content,
      encoding: 'utf-8',
      language: languageFor(normalizedPath),
      size_bytes: data.length,
      modified_at: stat.mtime.toISOString(),
      revision: crypto.createHash('sha256').update(data).digest('hex'),
      truncated: false,
      byte_limit: maxReadBytes
    };
  }

  return { list, read, selfCheck };
}

module.exports = {
  createBoundedRepositoryReader,
  normalizeRelativePath
};
