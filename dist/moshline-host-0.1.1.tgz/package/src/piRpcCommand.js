const { spawnSync } = require('node:child_process');

function resolvePiRpcLaunch(options = {}) {
  const command = typeof options.command === 'string' && options.command.trim() !== ''
    ? options.command.trim()
    : 'pi';
  const args = Array.isArray(options.args) && options.args.length > 0
    ? options.args.map(String)
    : ['--mode', 'rpc'];

  return {
    command,
    args,
    mode: 'rpc',
    mcp_subcommand: null
  };
}

function runPiVersionCommand(command) {
  const result = spawnSync(command, ['--version'], {
    encoding: 'utf8'
  });
  if (result.error) {
    return {
      ok: false,
      error: result.error.message,
      error_code: result.error.code || null
    };
  }
  if (result.status !== 0) {
    const message = (result.stderr || result.stdout || `command exited ${result.status}`).trim();
    return {
      ok: false,
      error: message || `command exited ${result.status}`,
      error_code: `EXIT_${result.status}`
    };
  }
  const output = (result.stdout || result.stderr || '').trim();
  if (!output) {
    return {
      ok: false,
      error: 'empty version output',
      error_code: 'EMPTY_OUTPUT'
    };
  }
  return {
    ok: true,
    output
  };
}

function inspectPiRuntime(options = {}) {
  const command = typeof options.command === 'string' && options.command.trim() !== ''
    ? options.command.trim()
    : 'pi';
  const runVersionCommand = typeof options.runVersionCommand === 'function'
    ? options.runVersionCommand
    : runPiVersionCommand;
  const probe = runVersionCommand(command);
  if (!probe || probe.ok !== true || typeof probe.output !== 'string') {
    return {
      available: false,
      command,
      version: null,
      mcp_subcommand: null,
      mode: 'rpc',
      error: probe && typeof probe.error === 'string' ? probe.error : 'failed to run version command',
      error_code: probe && probe.error_code ? String(probe.error_code) : null
    };
  }
  return {
    available: true,
    command,
    version: probe.output,
    mcp_subcommand: null,
    mode: 'rpc',
    error: null,
    error_code: null
  };
}

module.exports = {
  resolvePiRpcLaunch,
  inspectPiRuntime
};
