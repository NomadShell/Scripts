const fs = require('node:fs');
const net = require('node:net');
const path = require('node:path');

function removeSocketFile(socketPath) {
  if (!fs.existsSync(socketPath)) {
    return;
  }
  const stat = fs.lstatSync(socketPath);
  if (!stat.isSocket()) {
    throw new Error(`refusing to replace non-socket control path: ${socketPath}`);
  }
  fs.unlinkSync(socketPath);
}

function createHostControlSocket({
  socketPath,
  serverBootID,
  surfaceRegistry,
  attachTicketStore,
  maxFrameBytes = 256 * 1024
}) {
  const clients = new Set();

  const server = net.createServer((socket) => {
    clients.add(socket);
    let buffer = '';
    let attachment = null;
    let attached = false;
    const pendingOutput = [];

    function send(frame) {
      if (!socket.destroyed) {
        socket.write(`${JSON.stringify(frame)}\n`);
      }
    }

    function fail(code, message) {
      send({ type: 'error', code, message });
    }

    function handleAttach(frame) {
      if (typeof frame.ticket !== 'string' || frame.ticket === '') {
        fail('invalid_attach_ticket', 'attach ticket is missing');
        return;
      }
      const binding = attachTicketStore.consume(frame.ticket, serverBootID);
      if (!binding) {
        fail('invalid_attach_ticket', 'attach ticket is invalid or expired');
        return;
      }
      attachment = surfaceRegistry.attach(binding.surface_id, {
        onData(data) {
          const output = { type: 'output', data: Buffer.from(data).toString('base64') };
          if (attached) {
            send(output);
          } else {
            pendingOutput.push(output);
          }
        },
        onExit(event) {
          send({ type: 'exit', ...event });
        }
      });
      if (!attachment) {
        fail('surface_unavailable', 'surface is no longer running');
        return;
      }
      attached = true;
      send({ type: 'attached', surface: attachment.surface });
      for (const output of pendingOutput) {
        send(output);
      }
      pendingOutput.length = 0;
    }

    function handleFrame(frame) {
      if (!attached) {
        if (frame.type !== 'attach') {
          fail('attach_required', 'first frame must attach with a ticket');
          return;
        }
        handleAttach(frame);
        return;
      }
      if (frame.type === 'input') {
        if (typeof frame.data !== 'string') {
          fail('invalid_input', 'input data must be base64 text');
          return;
        }
        const data = Buffer.from(frame.data, 'base64').toString('utf8');
        if (!surfaceRegistry.write(attachment.surface.surface_id, data)) {
          fail('surface_unavailable', 'surface is no longer running');
        }
        return;
      }
      if (frame.type === 'resize') {
        const { columns, rows } = frame;
        if (!Number.isInteger(columns) || columns <= 0
          || !Number.isInteger(rows) || rows <= 0) {
          fail('invalid_resize', 'resize dimensions must be positive integers');
          return;
        }
        if (!surfaceRegistry.resize(attachment.surface.surface_id, columns, rows)) {
          fail('surface_unavailable', 'surface is no longer running');
        }
        return;
      }
      if (frame.type === 'detach') {
        socket.end();
        return;
      }
      fail('unknown_frame', 'unsupported control frame');
    }

    socket.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      if (Buffer.byteLength(buffer) > maxFrameBytes && !buffer.includes('\n')) {
        fail('frame_too_large', 'control frame exceeds size limit');
        socket.destroy();
        return;
      }
      let newline = buffer.indexOf('\n');
      while (newline >= 0) {
        const line = buffer.slice(0, newline);
        buffer = buffer.slice(newline + 1);
        if (line !== '') {
          try {
            handleFrame(JSON.parse(line));
          } catch {
            fail('invalid_json', 'control frame is not valid JSON');
          }
        }
        newline = buffer.indexOf('\n');
      }
    });
    socket.on('close', () => {
      attachment?.detach();
      clients.delete(socket);
    });
  });

  function start() {
    fs.mkdirSync(path.dirname(socketPath), { recursive: true });
    removeSocketFile(socketPath);
    return new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(socketPath, () => {
        server.removeListener('error', reject);
        fs.chmodSync(socketPath, 0o600);
        resolve();
      });
    });
  }

  function close() {
    for (const client of clients) {
      client.destroy();
    }
    return new Promise((resolve, reject) => {
      if (!server.listening) {
        resolve();
        return;
      }
      server.close((error) => {
        if (error) {
          reject(error);
          return;
        }
        try {
          removeSocketFile(socketPath);
          resolve();
        } catch (unlinkError) {
          reject(unlinkError);
        }
      });
    });
  }

  return { start, close, socketPath };
}

module.exports = { createHostControlSocket };
