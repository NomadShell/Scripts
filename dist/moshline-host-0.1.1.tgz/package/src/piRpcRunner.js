const { spawn } = require('node:child_process');

const { normalizeCodexMcpEvent } = require('./normalize');

const SUPPORTED_COMMAND_TYPES = new Set(['prompt', 'steer', 'follow_up', 'abort', 'get_state']);
const MESSAGE_REQUIRED_COMMAND_TYPES = new Set(['prompt', 'steer', 'follow_up']);

function createLinePump(onLine) {
  let buffer = '';

  function drain(flushTail = false) {
    while (true) {
      const lineEnd = buffer.indexOf('\n');
      if (lineEnd < 0) {
        if (flushTail) {
          const tail = buffer.trim();
          buffer = '';
          if (tail) {
            onLine(tail);
          }
        }
        break;
      }
      const line = buffer.slice(0, lineEnd).trim();
      buffer = buffer.slice(lineEnd + 1);
      if (line) {
        onLine(line);
      }
    }
  }

  return {
    push(chunk) {
      buffer += chunk.toString('utf8');
      drain(false);
    },
    flush() {
      drain(true);
    }
  };
}

function normalizeMetadataValue(value) {
  if (typeof value !== 'string') {
    return null;
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function normalizeCommandType(value) {
  if (typeof value !== 'string') {
    return '';
  }
  return value.trim();
}

function normalizeCommandId(value) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return String(Math.trunc(value));
  }
  if (typeof value !== 'string') {
    return '';
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : '';
}

function firstNonEmptyString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim() !== '') {
      return value.trim();
    }
  }
  return '';
}

function extractTextFromContent(content) {
  if (typeof content === 'string') {
    return content.trim();
  }
  if (Array.isArray(content)) {
    for (const item of content) {
      if (typeof item === 'string' && item.trim() !== '') {
        return item.trim();
      }
      if (item && typeof item === 'object' && !Array.isArray(item)) {
        const text = firstNonEmptyString(item.text, item.value, item.content, item.message);
        if (text) {
          return text;
        }
      }
    }
  }
  if (content && typeof content === 'object' && !Array.isArray(content)) {
    const text = firstNonEmptyString(content.text, content.value, content.content, content.message);
    if (text) {
      return text;
    }
  }
  return '';
}

function extractTextFromPiEvent(event) {
  if (!event || typeof event !== 'object' || Array.isArray(event)) {
    return '';
  }
  const assistantMessageEvent = event.assistantMessageEvent;
  const message = event.message;
  const partialResult = event.partialResult;
  const result = event.result;
  return firstNonEmptyString(
    event.text,
    event.message,
    assistantMessageEvent && assistantMessageEvent.text,
    assistantMessageEvent && assistantMessageEvent.delta,
    message && message.text,
    message && message.content && extractTextFromContent(message.content),
    partialResult && partialResult.text,
    partialResult && partialResult.content && extractTextFromContent(partialResult.content),
    result && result.text,
    result && result.content && extractTextFromContent(result.content)
  );
}

function createPiRpcSessionRunner(options) {
  const {
    sessionId,
    command,
    args,
    cwd,
    env,
    onEvent,
    onError,
    onExit,
    onSessionMeta,
    spawnImpl
  } = options;

  const doSpawn = typeof spawnImpl === 'function' ? spawnImpl : spawn;
  let child = null;
  let running = false;
  let rpcStateRequestId = 1;
  let rpcCommandRequestId = 1;
  const pendingCommands = new Map();

  function emitEvent(event) {
    if (event) {
      onEvent(event);
    }
  }

  function emitTaskStep(text, stream = 'stdout') {
    if (typeof text !== 'string' || text.trim() === '') {
      return;
    }
    emitEvent(normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: 'task_step',
      payload: {
        stream,
        text: text.trim()
      }
    }));
  }

  function emitError(message, traceId = undefined) {
    emitEvent(normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: 'error',
      payload: { message },
      trace_id: traceId
    }));
  }

  function createEvent(eventType, payload = {}, riskLevel = undefined) {
    return normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: eventType,
      payload,
      risk_level: riskLevel
    });
  }

  function emitCommandAcceptedEvent(commandType, commandId) {
    if (commandType === 'prompt' || commandType === 'steer' || commandType === 'follow_up') {
      emitEvent(createEvent('task_start', {
        command: commandType,
        command_id: commandId
      }));
      return;
    }
    if (commandType === 'abort') {
      emitEvent(createEvent('task_abort', {
        command: commandType,
        command_id: commandId
      }));
    }
  }

  function emitMappedPiEvent(parsed) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return false;
    }
    const eventType = normalizeCommandType(parsed.type);
    if (!eventType || eventType === 'response') {
      return false;
    }

    if (eventType === 'agent_start') {
      emitEvent(createEvent('task_start', {
        runtime: 'pi_rpc',
        event_type: eventType
      }));
      return true;
    }
    if (eventType === 'agent_end') {
      const errorMessage = firstNonEmptyString(
        parsed.error && (parsed.error.message || parsed.error),
        parsed.reason
      );
      if (errorMessage) {
        emitEvent(createEvent('task_failed', {
          error: errorMessage,
          event_type: eventType,
          raw: parsed
        }, 'high'));
      } else {
        emitEvent(createEvent('task_complete', {
          event_type: eventType,
          message_count: Array.isArray(parsed.messages) ? parsed.messages.length : undefined
        }));
      }
      return true;
    }
    if (eventType === 'tool_execution_start') {
      emitEvent(createEvent('tool_use', {
        tool: firstNonEmptyString(parsed.toolName, parsed.tool),
        tool_call_id: firstNonEmptyString(parsed.toolCallId, parsed.tool_call_id),
        args: parsed.args
      }));
      return true;
    }
    if (eventType === 'tool_execution_end') {
      emitEvent(createEvent('tool_result', {
        tool: firstNonEmptyString(parsed.toolName, parsed.tool),
        tool_call_id: firstNonEmptyString(parsed.toolCallId, parsed.tool_call_id),
        result: parsed.result,
        is_error: parsed.isError === true
      }));
      return true;
    }
    if (eventType === 'extension_ui_request') {
      emitEvent(createEvent('permission_request', {
        request_id: firstNonEmptyString(parsed.id, parsed.request_id),
        message: firstNonEmptyString(parsed.message, parsed.title, parsed.method),
        method: parsed.method || null,
        raw: parsed
      }, 'high'));
      return true;
    }

    const text = extractTextFromPiEvent(parsed);
    emitEvent(createEvent('task_step', {
      text: text || `[pi_rpc] ${eventType}`,
      event_type: eventType,
      raw: parsed
    }));
    return true;
  }

  function resolvePendingCommand(response) {
    const commandId = normalizeCommandId(response && response.id);
    if (!commandId) {
      return;
    }
    const pending = pendingCommands.get(commandId);
    if (!pending) {
      return;
    }
    pendingCommands.delete(commandId);
    if (pending.timer) {
      clearTimeout(pending.timer);
    }
    if (response && response.success === true) {
      emitCommandAcceptedEvent(pending.commandType, commandId);
      pending.resolve(response);
      return;
    }
    const errorMessage = firstNonEmptyString(response && response.error, 'rpc command failed');
    pending.reject(new Error(errorMessage));
  }

  function rejectAllPendingCommands(reason) {
    const entries = Array.from(pendingCommands.values());
    pendingCommands.clear();
    for (const entry of entries) {
      if (entry.timer) {
        clearTimeout(entry.timer);
      }
      entry.reject(reason);
    }
  }

  function emitSessionMetaUpdate(metadata) {
    if (!metadata || (metadata.pi_session_id == null && metadata.session_file == null)) {
      return;
    }
    emitEvent(normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: 'session_update',
      payload: {
        runtime: 'pi_rpc',
        pi_session_id: metadata.pi_session_id || null,
        session_file: metadata.session_file || null
      }
    }));
  }

  function handleRpcResponse(parsed) {
    if (!parsed || parsed.type !== 'response') {
      return;
    }
    if (parsed.command === 'get_state'
      && parsed.success === true
      && parsed.data
      && typeof parsed.data === 'object'
      && !Array.isArray(parsed.data)) {
      const metadata = {
        pi_session_id: normalizeMetadataValue(parsed.data.sessionId),
        session_file: normalizeMetadataValue(parsed.data.sessionFile)
      };
      if (typeof onSessionMeta === 'function') {
        onSessionMeta(metadata);
      }
      emitSessionMetaUpdate(metadata);
    }
    resolvePendingCommand(parsed);
  }

  function sendRpcCommand(commandBody) {
    if (!running || !child || !child.stdin) {
      return false;
    }
    const line = JSON.stringify(commandBody);
    child.stdin.write(`${line}\n`);
    return true;
  }

  function sendCommand(commandPayload, options = {}) {
    if (!running || !child || !child.stdin) {
      return Promise.reject(new Error('runner not running'));
    }
    if (!commandPayload || typeof commandPayload !== 'object' || Array.isArray(commandPayload)) {
      return Promise.reject(new Error('invalid command payload'));
    }

    const type = normalizeCommandType(commandPayload.type);
    if (!SUPPORTED_COMMAND_TYPES.has(type)) {
      return Promise.reject(new Error('invalid command type'));
    }

    const normalizedPayload = { ...commandPayload, type };
    if (MESSAGE_REQUIRED_COMMAND_TYPES.has(type)) {
      const message = firstNonEmptyString(commandPayload.message);
      if (!message) {
        return Promise.reject(new Error('missing message'));
      }
      normalizedPayload.message = message;
    }

    const timeoutMs = Number.isFinite(options.timeoutMs)
      ? Math.max(100, Math.trunc(options.timeoutMs))
      : 30000;
    const commandId = normalizeCommandId(commandPayload.id) || `bridge-cmd-${rpcCommandRequestId++}`;
    normalizedPayload.id = commandId;

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pendingCommands.delete(commandId);
        reject(new Error(`rpc command timeout: ${type}`));
      }, timeoutMs);

      pendingCommands.set(commandId, {
        resolve,
        reject,
        timer,
        commandType: type
      });

      const sent = sendRpcCommand(normalizedPayload);
      if (!sent) {
        pendingCommands.delete(commandId);
        clearTimeout(timer);
        reject(new Error('failed to send rpc command'));
      }
    });
  }

  function start() {
    if (running) {
      return;
    }

    child = doSpawn(command, Array.isArray(args) ? args : [], {
      cwd,
      env,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    running = true;

    const stdoutPump = createLinePump((line) => {
      try {
        const parsed = JSON.parse(line);
        handleRpcResponse(parsed);
        if (parsed && parsed.type !== 'response') {
          const handled = emitMappedPiEvent(parsed);
          if (!handled) {
            emitTaskStep(line, 'stdout');
          }
        }
      } catch {
        emitTaskStep(line, 'stdout');
      }
    });
    const stderrPump = createLinePump((line) => {
      emitTaskStep(line, 'stderr');
    });
    let exited = false;
    let flushed = false;

    function flushBuffersOnce() {
      if (flushed) {
        return;
      }
      flushed = true;
      stdoutPump.flush();
      stderrPump.flush();
    }

    function finalizeExit(code, signal) {
      if (exited) {
        return;
      }
      exited = true;
      running = false;
      rejectAllPendingCommands(new Error('pi rpc session ended'));
      flushBuffersOnce();
      onExit(code, signal);
    }

    if (child.stdout) {
      child.stdout.on('data', (chunk) => stdoutPump.push(chunk));
    }
    if (child.stderr) {
      child.stderr.on('data', (chunk) => stderrPump.push(chunk));
    }

    child.on('error', (error) => {
      onError(error);
      emitError(error.message);
      finalizeExit(null, 'spawn_error');
    });

    child.on('exit', (code, signal) => {
      finalizeExit(code, signal);
    });

    child.on('close', (code, signal) => {
      finalizeExit(code, signal);
    });

    setImmediate(() => {
      sendRpcCommand({
        id: `bridge-bootstrap-${rpcStateRequestId++}`,
        type: 'get_state'
      });
    });
  }

  function stop() {
    if (!running || !child) {
      return;
    }
    child.kill('SIGTERM');
  }

  return {
    start,
    stop,
    sendCommand,
    isRunning: () => running,
    pid: () => (child ? child.pid : null)
  };
}

module.exports = {
  createPiRpcSessionRunner
};
