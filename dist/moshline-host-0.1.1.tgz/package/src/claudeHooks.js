const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');

function normalizeBaseUrl(baseUrl) {
  if (typeof baseUrl !== 'string' || baseUrl.trim() === '') {
    throw new Error('invalid base_url');
  }
  const parsed = new URL(baseUrl.trim());
  return parsed.toString().replace(/\/$/, '');
}

function resolveForwarderScriptPath() {
  return path.resolve(__dirname, '..', 'scripts', 'claude_session_hook_forwarder.cjs');
}

function buildClaudeSessionStartHookSettings(baseUrlInput) {
  const baseUrl = normalizeBaseUrl(baseUrlInput);
  const endpoint = `${baseUrl}/hooks/claude/session-start`;
  const scriptPath = resolveForwarderScriptPath();
  const command = `node "${scriptPath}" "${baseUrl}"`;

  return {
    endpoint,
    script_path: scriptPath,
    command,
    settings: {
      hooks: {
        SessionStart: [
          {
            matcher: '*',
            hooks: [
              {
                type: 'command',
                command
              }
            ]
          }
        ]
      }
    }
  };
}

function defaultClaudeSettingsPath() {
  return path.join(os.homedir(), '.claude', 'settings.json');
}

function resolveSettingsPath(inputPath) {
  if (typeof inputPath !== 'string' || inputPath.trim() === '') {
    return defaultClaudeSettingsPath();
  }
  return path.resolve(inputPath.trim());
}

function loadSettingsObject(settingsPath) {
  if (!fs.existsSync(settingsPath)) {
    return {};
  }
  const raw = fs.readFileSync(settingsPath, 'utf8');
  if (raw.trim() === '') {
    return {};
  }
  const parsed = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('invalid claude settings file');
  }
  return parsed;
}

function hasHookCommand(settings, command) {
  const list = settings?.hooks?.SessionStart;
  if (!Array.isArray(list)) {
    return false;
  }
  for (const item of list) {
    const hooks = item?.hooks;
    if (!Array.isArray(hooks)) {
      continue;
    }
    for (const hook of hooks) {
      if (hook?.type === 'command' && hook?.command === command) {
        return true;
      }
    }
  }
  return false;
}

function installClaudeSessionStartHook(options = {}) {
  const template = buildClaudeSessionStartHookSettings(options.baseUrl);
  const settingsPath = resolveSettingsPath(options.settingsPath);

  const settings = loadSettingsObject(settingsPath);
  if (!settings.hooks || typeof settings.hooks !== 'object' || Array.isArray(settings.hooks)) {
    settings.hooks = {};
  }
  if (!Array.isArray(settings.hooks.SessionStart)) {
    settings.hooks.SessionStart = [];
  }

  if (hasHookCommand(settings, template.command)) {
    return {
      settings_path: settingsPath,
      changed: false,
      command: template.command,
      endpoint: template.endpoint
    };
  }

  const entry = {
    matcher: '*',
    hooks: [
      {
        type: 'command',
        command: template.command
      }
    ]
  };
  settings.hooks.SessionStart.push(entry);

  fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
  if (fs.existsSync(settingsPath)) {
    fs.copyFileSync(settingsPath, `${settingsPath}.bak`);
  }
  fs.writeFileSync(settingsPath, `${JSON.stringify(settings, null, 2)}\n`, 'utf8');

  return {
    settings_path: settingsPath,
    changed: true,
    command: template.command,
    endpoint: template.endpoint
  };
}

function extractSessionIdFromHookPayload(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return 'unknown-session';
  }
  if (typeof payload.session_id === 'string' && payload.session_id.trim() !== '') {
    return payload.session_id;
  }
  if (typeof payload.sessionId === 'string' && payload.sessionId.trim() !== '') {
    return payload.sessionId;
  }
  return 'unknown-session';
}

module.exports = {
  buildClaudeSessionStartHookSettings,
  extractSessionIdFromHookPayload,
  installClaudeSessionStartHook
};
