'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const GATES = [
  { id: 'M2-01', milestone: 'm2', row: 'Multiplexer session/window picker (“Jump to…”)' },
  { id: 'M2-02', milestone: 'm2', row: 'Zellij detection/navigation' },
  { id: 'M3-01', milestone: 'm3', row: 'Provider windows (Claude 5h/7d, Codex variable) + pace' },
  { id: 'M3-02', milestone: 'm3', row: 'Dedicated Usages tab' },
  { id: 'M3-03', milestone: 'm3', row: 'Fleet/home usage rings across agents/accounts' },
  { id: 'M3-04', milestone: 'm3', row: 'Per-session context “stamina ring”' },
  { id: 'M3-05', milestone: 'm3', row: 'Watch usage screen and complication' },
  { id: 'M4-01', milestone: 'm4', row: 'OSC 52 remote → iOS clipboard' },
  { id: 'M4-02', milestone: 'm4', row: 'CJK / IME input' },
  { id: 'M4-03', milestone: 'm4', row: 'Hardware keyboard on iPad' },
  { id: 'M4-04', milestone: 'm4', row: 'Nerd Font glyph coverage' },
  { id: 'M4-05', milestone: 'm4', row: 'Repository file browser + syntax highlighting' },
  { id: 'M4-06', milestone: 'm4', row: 'Image crop / annotation' },
  { id: 'M4-07', milestone: 'm4', row: 'PDF / log attachment' },
  { id: 'M5-01', milestone: 'm5', row: 'Agent hook: Cursor' },
  { id: 'M5-02', milestone: 'm5', row: 'Agent hook: Kimi' },
  { id: 'M5-03', milestone: 'm5', row: 'Agent hook: Qwen Code' }
];

const PROVIDER_COMMANDS = {
  claude: 'claude',
  codex: 'codex',
  cursor: 'cursor-agent',
  kimi: 'kimi',
  qwen: 'qwen',
  tmux: 'tmux',
  zellij: 'zellij'
};

function normalizeMilestones(value = 'all') {
  const requested = String(value).split(',')
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
  if (requested.length === 0 || requested.includes('all')) {
    return ['m2', 'm3', 'm4', 'm5'];
  }
  const invalid = requested.filter((item) => !['m2', 'm3', 'm4', 'm5'].includes(item));
  if (invalid.length > 0) {
    throw new Error(`unsupported milestone: ${invalid.join(', ')}`);
  }
  return [...new Set(requested)];
}

function boundedString(value, limit = 256) {
  return typeof value === 'string' && value.trim() !== ''
    ? value.trim().slice(0, limit)
    : null;
}

function sanitizeUsage(usage) {
  if (!usage || typeof usage !== 'object') {
    return null;
  }
  const windows = Array.isArray(usage.windows) ? usage.windows.map((window) => ({
    id: boundedString(window.id),
    label: boundedString(window.label),
    duration_seconds: Number.isFinite(window.duration_seconds) ? window.duration_seconds : null,
    used_fraction: Number.isFinite(window.used_fraction) ? window.used_fraction : null,
    remaining_fraction: Number.isFinite(window.remaining_fraction) ? window.remaining_fraction : null,
    resets_at: boundedString(window.resets_at),
    pace: boundedString(window.pace)
  })) : [];
  return {
    schema_version: Number.isFinite(usage.schema_version) ? usage.schema_version : null,
    provider: boundedString(usage.provider),
    captured_at: boundedString(usage.captured_at),
    windows
  };
}

function sanitizeSession(session) {
  const route = session?.terminal_route;
  return {
    session_id: boundedString(session?.session_id),
    agent_run_id: boundedString(session?.agent_run_id),
    provider: boundedString(session?.provider),
    state: boundedString(session?.state),
    running: session?.running === true,
    last_event_at: boundedString(session?.last_event_at),
    capabilities: Array.isArray(session?.capabilities)
      ? session.capabilities.filter((item) => typeof item === 'string').slice(0, 64)
      : [],
    terminal_route: route && typeof route === 'object' ? {
      kind: boundedString(route.kind),
      confidence: boundedString(route.confidence),
      observed_at: boundedString(route.observed_at),
      server_boot_id: boundedString(route.server_boot_id),
      surface_id: boundedString(route.surface_id)
    } : null,
    usage: sanitizeUsage(session?.usage)
  };
}

function sanitizeEvent(event) {
  const payload = event?.payload && typeof event.payload === 'object' ? event.payload : {};
  return {
    id: boundedString(event?.id),
    session_id: boundedString(event?.session_id),
    source: boundedString(event?.source),
    type: boundedString(event?.type),
    timestamp: event?.timestamp ?? null,
    provider: boundedString(payload.provider || event?.provider),
    hook_event_name: boundedString(payload.hook_event_name || payload.event_name),
    tool_name: boundedString(payload.tool_name || payload.tool),
    request_id: boundedString(payload.request_id)
  };
}

async function fetchJson(fetchImpl, baseURL, pathname, token) {
  try {
    const response = await fetchImpl(new URL(pathname, baseURL), {
      headers: { authorization: `Bearer ${token}` }
    });
    const text = await response.text();
    let body = {};
    try {
      body = text ? JSON.parse(text) : {};
    } catch {
      body = {};
    }
    return {
      ok: response.ok,
      status: response.status,
      body: response.ok ? body : null,
      error: response.ok ? null : boundedString(body.error || text || `HTTP ${response.status}`)
    };
  } catch (error) {
    return { ok: false, status: null, body: null, error: boundedString(error.message) };
  }
}

function defaultVersionProbe(command) {
  const result = spawnSync(command, ['--version'], {
    encoding: 'utf8',
    timeout: 5000,
    maxBuffer: 64 * 1024,
    shell: false
  });
  if (result.error) {
    return { available: false, version: null, error: boundedString(result.error.message) };
  }
  const output = boundedString(`${result.stdout || ''}\n${result.stderr || ''}`.trim(), 512);
  return {
    available: result.status === 0,
    version: output,
    error: result.status === 0 ? null : `exit ${result.status}`
  };
}

function renderMarkdown(snapshot) {
  const lines = [
    '# Moshi Parity Physical Acceptance Capture',
    '',
    `Captured at: ${snapshot.captured_at}`,
    '',
    `Milestones: ${snapshot.milestones.join(', ').toUpperCase()}`,
    '',
    `Host: ${snapshot.host.platform} ${snapshot.host.release} (${snapshot.host.arch})`,
    '',
    `Bridge preflight: ${snapshot.bridge.host.ok ? 'PASS' : `FAIL (${snapshot.bridge.host.error || snapshot.bridge.host.status})`}`,
    '',
    'This capture is evidence scaffolding, not an automatic pass. Fill the manual result and artifact links after running the physical-device steps in the acceptance runbook.',
    '',
    '## Gate checklist',
    '',
    '| ID | Matrix row | Result | Device/host evidence | Artifact links |',
    '| --- | --- | --- | --- | --- |'
  ];
  for (const gate of snapshot.gates) {
    lines.push(`| ${gate.id} | ${gate.row} | ⏳ |  |  |`);
  }
  lines.push('', '## Tool versions', '');
  for (const [name, result] of Object.entries(snapshot.tool_versions)) {
    lines.push(`- ${name}: ${result.available ? result.version || 'available' : `unavailable (${result.error || 'not found'})`}`);
  }
  lines.push('', '## Captured sessions', '');
  if (snapshot.sessions.length === 0) {
    lines.push('- None captured. Re-run with one or more `--session <id>` arguments after starting real provider sessions.');
  } else {
    for (const session of snapshot.sessions) {
      lines.push(`- ${session.session_id}: provider=${session.provider || 'unknown'}, state=${session.state || 'unknown'}, events=${session.events.length}, multiplexer_targets=${session.multiplexer?.targets?.length || 0}`);
    }
  }
  lines.push('', '## Manual notes', '', '- ', '');
  return `${lines.join('\n')}\n`;
}

async function captureMoshiParityAcceptance({
  baseURL = 'http://127.0.0.1:24000',
  token,
  milestones = 'all',
  sessionIDs = [],
  outputDir,
  now = new Date(),
  fetchImpl = fetch,
  versionProbe = defaultVersionProbe,
  host = { platform: os.platform(), release: os.release(), arch: os.arch() }
}) {
  if (typeof token !== 'string' || token.trim() === '') {
    throw new Error('host bearer token is required');
  }
  if (typeof outputDir !== 'string' || outputDir.trim() === '') {
    throw new Error('outputDir is required');
  }
  const selectedMilestones = normalizeMilestones(milestones);
  const capturedAt = now.toISOString();
  const suffix = capturedAt.replace(/[:.]/g, '-');
  const bridgeHost = await fetchJson(fetchImpl, baseURL, '/v1/host', token);
  const bridgeSessions = await fetchJson(fetchImpl, baseURL, '/v1/sessions', token);
  const listedSessions = bridgeSessions.ok && Array.isArray(bridgeSessions.body?.sessions)
    ? bridgeSessions.body.sessions.map(sanitizeSession)
    : [];
  const selectedSessionIDs = [...new Set(sessionIDs.map((item) => String(item).trim()).filter(Boolean))];
  const sessions = [];
  for (const sessionID of selectedSessionIDs) {
    const encoded = encodeURIComponent(sessionID);
    const eventsResult = await fetchJson(
      fetchImpl,
      baseURL,
      `/v1/sessions/${encoded}/events?limit=1000`,
      token
    );
    const multiplexerResult = selectedMilestones.includes('m2')
      ? await fetchJson(fetchImpl, baseURL, `/v1/sessions/${encoded}/multiplexers`, token)
      : null;
    const listed = listedSessions.find((item) => item.session_id === sessionID) || { session_id: sessionID };
    sessions.push({
      ...listed,
      events_capture: {
        ok: eventsResult.ok,
        status: eventsResult.status,
        error: eventsResult.error
      },
      events: eventsResult.ok && Array.isArray(eventsResult.body?.events)
        ? eventsResult.body.events.map(sanitizeEvent)
        : [],
      multiplexer: multiplexerResult ? {
        ok: multiplexerResult.ok,
        status: multiplexerResult.status,
        error: multiplexerResult.error,
        capabilities: Array.isArray(multiplexerResult.body?.capabilities)
          ? multiplexerResult.body.capabilities
          : [],
        targets: Array.isArray(multiplexerResult.body?.targets)
          ? multiplexerResult.body.targets.map((target) => ({
            kind: boundedString(target.kind),
            session: boundedString(target.session),
            window: boundedString(target.window),
            pane: boundedString(target.pane),
            title: boundedString(target.title),
            confidence: boundedString(target.confidence)
          }))
          : []
      } : null
    });
  }

  const toolNames = new Set();
  if (selectedMilestones.includes('m2')) {
    toolNames.add('tmux');
    toolNames.add('zellij');
  }
  if (selectedMilestones.includes('m3')) {
    toolNames.add('claude');
    toolNames.add('codex');
  }
  if (selectedMilestones.includes('m5')) {
    toolNames.add('cursor');
    toolNames.add('kimi');
    toolNames.add('qwen');
  }
  const toolVersions = Object.fromEntries([...toolNames].map((name) => [
    name,
    versionProbe(PROVIDER_COMMANDS[name])
  ]));
  const snapshot = {
    schema_version: 1,
    captured_at: capturedAt,
    milestones: selectedMilestones,
    host,
    gates: GATES.filter((gate) => selectedMilestones.includes(gate.milestone)),
    bridge: {
      host: { ok: bridgeHost.ok, status: bridgeHost.status, error: bridgeHost.error },
      sessions: { ok: bridgeSessions.ok, status: bridgeSessions.status, error: bridgeSessions.error },
      capabilities: Array.isArray(bridgeHost.body?.host?.capabilities)
        ? bridgeHost.body.host.capabilities
        : []
    },
    tool_versions: toolVersions,
    listed_sessions: listedSessions,
    sessions
  };
  fs.mkdirSync(outputDir, { recursive: true });
  const jsonPath = path.join(outputDir, `capture-${suffix}.json`);
  const markdownPath = path.join(outputDir, `capture-${suffix}.md`);
  fs.writeFileSync(jsonPath, `${JSON.stringify(snapshot, null, 2)}\n`);
  fs.writeFileSync(markdownPath, renderMarkdown(snapshot));
  fs.copyFileSync(jsonPath, path.join(outputDir, 'latest.json'));
  fs.copyFileSync(markdownPath, path.join(outputDir, 'latest.md'));
  return {
    ...snapshot,
    paths: { json: jsonPath, markdown: markdownPath }
  };
}

module.exports = {
  GATES,
  captureMoshiParityAcceptance,
  defaultVersionProbe,
  normalizeMilestones,
  renderMarkdown,
  sanitizeEvent,
  sanitizeSession,
  sanitizeUsage
};
