const fs = require('node:fs');
const path = require('node:path');

function safeStamp(nowDate) {
  return nowDate.toISOString().replace(/[:]/g, '-').replace(/\.\d{3}Z$/, 'Z');
}

function readJsonIfExists(filePath) {
  if (!fs.existsSync(filePath)) {
    return null;
  }
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    if (!raw.trim()) {
      return null;
    }
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function createIncidentMarkdown({
  nowDate,
  gateResult,
  windowSamples,
  expectedSamples,
  overallStatus,
  endpointFailCount,
  cursorConflictsUnresolved,
  snapshotGeneratedAt
}) {
  const lines = [];
  lines.push('# Incident Report');
  lines.push('');
  lines.push(`- created_at: ${nowDate.toISOString()}`);
  lines.push(`- gate_result: ${gateResult}`);
  lines.push(`- samples: ${windowSamples}/${expectedSamples}`);
  lines.push(`- overall_status: ${overallStatus}`);
  lines.push(`- endpoint_fail_count: ${endpointFailCount}`);
  lines.push(`- cursor_conflicts_unresolved: ${cursorConflictsUnresolved}`);
  lines.push(`- source_snapshot_generated_at: ${snapshotGeneratedAt}`);
  lines.push('');
  lines.push('## Impact');
  lines.push('- 用户影响范围：');
  lines.push('- 持续时长：');
  lines.push('- 严重级别（P1/P2/P3）：');
  lines.push('');
  lines.push('## Timeline');
  lines.push('- T0 发现：');
  lines.push('- T1 处置：');
  lines.push('- T2 恢复：');
  lines.push('');
  lines.push('## Actions');
  lines.push('- [ ] ACK/Escalate 已执行');
  lines.push('- [ ] 策略配置已复核');
  lines.push('- [ ] 回放一致性已复核');
  lines.push('- [ ] KPI 异常已复核');
  lines.push('');
  lines.push('## Root Cause');
  lines.push('- 触发条件：');
  lines.push('- 根因：');
  lines.push('- 证据（API 快照/日志）：');
  lines.push('');
  lines.push('## Follow-ups');
  lines.push('- [ ] 修复项：');
  lines.push('- [ ] 验证项：');
  lines.push('- [ ] 责任人：');
  lines.push('- [ ] 截止时间：');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function createIncidentTemplateFromReports(options = {}) {
  const reportDir = typeof options.reportDir === 'string' && options.reportDir.trim() !== ''
    ? path.resolve(options.reportDir)
    : path.resolve(process.cwd(), 'reports', 'beta-acceptance');
  const nowDate = options.now instanceof Date ? options.now : new Date();
  const snapshot = readJsonIfExists(path.join(reportDir, 'latest.json'));
  const summary = readJsonIfExists(path.join(reportDir, 'summary-latest.json'));

  const gateResult = summary && summary.summary && typeof summary.summary.gate_result === 'string'
    ? summary.summary.gate_result
    : 'n/a';
  const windowSamples = summary && summary.summary && Number.isFinite(summary.summary.samples_in_window)
    ? summary.summary.samples_in_window
    : 'n/a';
  const expectedSamples = summary && summary.summary && Number.isFinite(summary.summary.expected_samples)
    ? summary.summary.expected_samples
    : 'n/a';
  const overallStatus = snapshot && snapshot.summary && typeof snapshot.summary.overall_status === 'string'
    ? snapshot.summary.overall_status
    : 'n/a';
  const endpointFailCount = snapshot && snapshot.summary && Number.isFinite(snapshot.summary.endpoint_fail_count)
    ? snapshot.summary.endpoint_fail_count
    : 'n/a';
  const cursorConflictsUnresolved = snapshot
    && snapshot.summary
    && Number.isFinite(snapshot.summary.cursor_conflicts_unresolved)
    ? snapshot.summary.cursor_conflicts_unresolved
    : 'n/a';
  const snapshotGeneratedAt = snapshot && typeof snapshot.generated_at === 'string'
    ? snapshot.generated_at
    : 'n/a';

  const markdown = createIncidentMarkdown({
    nowDate,
    gateResult,
    windowSamples,
    expectedSamples,
    overallStatus,
    endpointFailCount,
    cursorConflictsUnresolved,
    snapshotGeneratedAt
  });

  const incidentsDir = path.join(reportDir, 'incidents');
  fs.mkdirSync(incidentsDir, { recursive: true });
  const incidentPath = path.join(incidentsDir, `incident-${safeStamp(nowDate)}.md`);
  const latestPath = path.join(incidentsDir, 'incident-latest.md');
  fs.writeFileSync(incidentPath, markdown, 'utf8');
  fs.writeFileSync(latestPath, markdown, 'utf8');

  return {
    path: incidentPath,
    latest_path: latestPath
  };
}

module.exports = {
  createIncidentTemplateFromReports
};
