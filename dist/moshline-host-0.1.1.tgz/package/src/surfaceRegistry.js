const { randomUUID } = require('node:crypto');

function cloneSurface(surface) {
  return {
    surface_id: surface.surface_id,
    server_boot_id: surface.server_boot_id,
    pid: surface.pid,
    argv: [...surface.argv],
    cwd: surface.cwd,
    columns: surface.columns,
    rows: surface.rows,
    state: surface.state,
    created_at: surface.created_at,
    updated_at: surface.updated_at,
    exit_code: surface.exit_code,
    claimed_session_id: surface.claimed_session_id || null
  };
}

function createSurfaceRegistry({
  serverBootID,
  ptyFactory,
  surfaceIDFactory = randomUUID,
  now = () => new Date()
}) {
  if (!ptyFactory || typeof ptyFactory.spawn !== 'function') {
    throw new Error('PTY factory is required');
  }
  const surfaces = new Map();

  function getRecord(surfaceId) {
    return surfaces.get(surfaceId) || null;
  }

  function create({ argv, cwd, columns = 80, rows = 24 }) {
    const surfaceId = surfaceIDFactory();
    const timestamp = now().toISOString();
    const resolvedCwd = cwd || process.cwd();
    const pty = ptyFactory.spawn(argv[0], argv.slice(1), {
      name: 'xterm-256color',
      cols: columns,
      rows,
      cwd: resolvedCwd,
      env: {
        ...process.env,
        MOSHLINE_SURFACE_ID: surfaceId,
        MOSHLINE_SERVER_BOOT_ID: serverBootID
      }
    });
    const record = {
      surface_id: surfaceId,
      server_boot_id: serverBootID,
      pid: pty.pid,
      argv: [...argv],
      cwd: resolvedCwd,
      columns,
      rows,
      state: 'running',
      created_at: timestamp,
      updated_at: timestamp,
      exit_code: null,
      claimed_session_id: null,
      pty,
      dataListeners: new Set(),
      exitListeners: new Set(),
      buffer: ''
    };
    surfaces.set(surfaceId, record);

    record.dataSubscription = pty.onData((data) => {
      record.buffer = `${record.buffer}${data}`.slice(-256 * 1024);
      record.updated_at = now().toISOString();
      for (const listener of record.dataListeners) {
        listener(data);
      }
    });
    record.exitSubscription = pty.onExit((event = {}) => {
      record.state = 'exited';
      record.exit_code = Number.isInteger(event.exitCode) ? event.exitCode : null;
      record.updated_at = now().toISOString();
      for (const listener of record.exitListeners) {
        listener({
          exit_code: record.exit_code,
          signal: Number.isInteger(event.signal) ? event.signal : null
        });
      }
    });
    return cloneSurface(record);
  }

  function list() {
    return [...surfaces.values()].map(cloneSurface);
  }

  function get(surfaceId) {
    const record = getRecord(surfaceId);
    return record ? cloneSurface(record) : null;
  }

  // Bind a surface to the first agent session that claims it. A daemon-owned
  // surface has no session identity at spawn time; the session is only known
  // once its hook reports the injected MOSHLINE_SURFACE_ID. The first non-empty
  // claim wins and is sticky, so a second session that reports another
  // session's surface_id cannot take ownership (and therefore cannot earn a
  // verified route to a PTY it does not own).
  function claimSession(surfaceId, sessionId) {
    const record = getRecord(surfaceId);
    const normalizedSessionId = typeof sessionId === 'string' ? sessionId.trim() : '';
    if (!record || normalizedSessionId === '') {
      return false;
    }
    if (!record.claimed_session_id) {
      record.claimed_session_id = normalizedSessionId;
      return true;
    }
    return record.claimed_session_id === normalizedSessionId;
  }

  function resize(surfaceId, columns, rows) {
    const record = getRecord(surfaceId);
    if (!record || record.state !== 'running') {
      return null;
    }
    record.pty.resize(columns, rows);
    record.columns = columns;
    record.rows = rows;
    record.updated_at = now().toISOString();
    return cloneSurface(record);
  }

  function write(surfaceId, data) {
    const record = getRecord(surfaceId);
    if (!record || record.state !== 'running') {
      return false;
    }
    record.pty.write(data);
    return true;
  }

  function attach(surfaceId, { onData, onExit } = {}) {
    const record = getRecord(surfaceId);
    if (!record || record.state !== 'running') {
      return null;
    }
    if (typeof onData === 'function') {
      record.dataListeners.add(onData);
      if (record.buffer !== '') {
        onData(record.buffer);
      }
    }
    if (typeof onExit === 'function') {
      record.exitListeners.add(onExit);
    }
    return {
      surface: cloneSurface(record),
      detach() {
        record.dataListeners.delete(onData);
        record.exitListeners.delete(onExit);
      }
    };
  }

  function close(surfaceId) {
    const record = getRecord(surfaceId);
    if (!record) {
      return false;
    }
    surfaces.delete(surfaceId);
    record.dataSubscription?.dispose?.();
    record.exitSubscription?.dispose?.();
    if (record.state === 'running') {
      record.pty.kill();
    }
    return true;
  }

  function dispose() {
    for (const surfaceId of [...surfaces.keys()]) {
      close(surfaceId);
    }
  }

  return {
    list,
    get,
    claimSession,
    create,
    resize,
    write,
    attach,
    close,
    dispose
  };
}

module.exports = { createSurfaceRegistry };
