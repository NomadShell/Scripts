const fs = require('node:fs');
const path = require('node:path');

const { collectBetaAcceptanceSnapshot } = require('./betaSnapshot');
const { summarizeBetaAcceptanceWindow } = require('./betaSummary');
const { createIncidentTemplateFromReports } = require('./incidentTemplate');

function parsePositiveInt(value, defaultValue) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return defaultValue;
  }
  return parsed;
}

function parseOptionalPositiveInt(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  const parsed = Number.parseInt(String(value), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return null;
  }
  return parsed;
}

function safeStamp(nowDate) {
  return nowDate.toISOString().replace(/[:]/g, '-').replace(/\.\d{3}Z$/, 'Z');
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function buildSoakMarkdown(result) {
  const lines = [];
  lines.push('# Nomad Beta Soak Run');
  lines.push('');
  lines.push(`- started_at: ${result.started_at}`);
  lines.push(`- ended_at: ${result.ended_at}`);
  lines.push(`- total_iterations: ${result.total_iterations}`);
  lines.push(`- abnormal_iterations: ${result.abnormal_iterations}`);
  lines.push(`- incidents_created: ${result.incidents_created}`);
  lines.push(`- last_overall_status: ${result.last_overall_status}`);
  lines.push(`- last_gate_result: ${result.last_gate_result}`);
  lines.push('');
  lines.push('## Iterations');
  lines.push('');
  lines.push('| # | ts | overall | gate | abnormal | incident |');
  lines.push('| --- | --- | --- | --- | --- | --- |');
  for (const item of result.iterations) {
    lines.push(`| ${item.index} | ${item.generated_at} | ${item.overall_status} | ${item.gate_result} | ${item.abnormal ? 'yes' : 'no'} | ${item.incident_path || ''} |`);
  }
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function persistSoakResult(reportDir, result, endedAtDate) {
  const soakDir = path.join(reportDir, 'soak');
  fs.mkdirSync(soakDir, { recursive: true });
  const stamp = safeStamp(endedAtDate);
  const jsonPath = path.join(soakDir, `run-${stamp}.json`);
  const markdownPath = path.join(soakDir, `run-${stamp}.md`);
  const latestJsonPath = path.join(soakDir, 'run-latest.json');
  const latestMarkdownPath = path.join(soakDir, 'run-latest.md');

  fs.writeFileSync(jsonPath, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  fs.writeFileSync(markdownPath, buildSoakMarkdown(result), 'utf8');
  fs.writeFileSync(latestJsonPath, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  fs.writeFileSync(latestMarkdownPath, buildSoakMarkdown(result), 'utf8');

  return {
    json: jsonPath,
    markdown: markdownPath,
    latest_json: latestJsonPath,
    latest_markdown: latestMarkdownPath
  };
}

async function runBetaSoakMonitor(options = {}) {
  const reportDir = typeof options.reportDir === 'string' && options.reportDir.trim() !== ''
    ? path.resolve(options.reportDir)
    : path.resolve(process.cwd(), 'reports', 'beta-acceptance');
  const intervalSeconds = parsePositiveInt(options.intervalSeconds, 300);
  let maxIterations = parseOptionalPositiveInt(options.maxIterations);
  const durationSeconds = parseOptionalPositiveInt(options.durationSeconds);
  const stopOnFailure = options.stopOnFailure === true;
  const windowDays = parsePositiveInt(options.windowDays, 7);
  const samplesPerDay = parsePositiveInt(options.samplesPerDay, 2);

  if (maxIterations === null && durationSeconds === null) {
    maxIterations = 1;
  }

  const collectImpl = typeof options.collectImpl === 'function'
    ? options.collectImpl
    : collectBetaAcceptanceSnapshot;
  const summarizeImpl = typeof options.summarizeImpl === 'function'
    ? options.summarizeImpl
    : summarizeBetaAcceptanceWindow;
  const incidentImpl = typeof options.incidentImpl === 'function'
    ? options.incidentImpl
    : createIncidentTemplateFromReports;
  const sleepImpl = typeof options.sleepImpl === 'function' ? options.sleepImpl : sleep;
  const nowProvider = typeof options.nowProvider === 'function'
    ? options.nowProvider
    : () => new Date();
  const onIteration = typeof options.onIteration === 'function' ? options.onIteration : null;

  const startedAtDate = nowProvider();
  const startedAtMs = startedAtDate.getTime();
  const iterations = [];
  let totalIterations = 0;
  let abnormalIterations = 0;
  let incidentsCreated = 0;
  let lastOverallStatus = null;
  let lastGateResult = null;

  while (true) {
    const nowDate = nowProvider();
    const snapshot = await collectImpl({
      bridgeBaseUrl: options.bridgeBaseUrl,
      outputDir: reportDir,
      windowSeconds: options.windowSeconds,
      baselineWindowSeconds: options.baselineWindowSeconds,
      consistencyLimit: options.consistencyLimit,
      crashFreeSessionRate: options.crashFreeSessionRate,
      now: nowDate
    });
    const summary = summarizeImpl({
      reportDir,
      windowDays,
      samplesPerDay,
      now: nowDate
    });

    const overallStatus = snapshot && snapshot.summary && typeof snapshot.summary.overall_status === 'string'
      ? snapshot.summary.overall_status
      : 'unknown';
    const gateResult = summary && summary.summary && typeof summary.summary.gate_result === 'string'
      ? summary.summary.gate_result
      : 'Unknown';
    const abnormal = overallStatus !== 'pass' || gateResult === 'Fail';
    let incidentPath = null;
    if (abnormal) {
      const incident = incidentImpl({ reportDir, now: nowDate });
      incidentPath = incident && typeof incident.path === 'string' ? incident.path : null;
      incidentsCreated += 1;
      abnormalIterations += 1;
    }

    totalIterations += 1;
    lastOverallStatus = overallStatus;
    lastGateResult = gateResult;

    const record = {
      index: totalIterations,
      generated_at: nowDate.toISOString(),
      overall_status: overallStatus,
      gate_result: gateResult,
      abnormal,
      incident_path: incidentPath
    };
    iterations.push(record);
    if (onIteration) {
      await onIteration(record);
    }

    const elapsedMs = nowDate.getTime() - startedAtMs;
    const hitMaxIterations = Number.isFinite(maxIterations) && totalIterations >= maxIterations;
    const hitDuration = Number.isFinite(durationSeconds) && elapsedMs >= durationSeconds * 1000;
    if (hitMaxIterations || hitDuration || (stopOnFailure && abnormal)) {
      break;
    }

    await sleepImpl(intervalSeconds * 1000);
  }

  const endedAtDate = nowProvider();
  const result = {
    started_at: startedAtDate.toISOString(),
    ended_at: endedAtDate.toISOString(),
    total_iterations: totalIterations,
    abnormal_iterations: abnormalIterations,
    incidents_created: incidentsCreated,
    last_overall_status: lastOverallStatus,
    last_gate_result: lastGateResult,
    interval_seconds: intervalSeconds,
    max_iterations: maxIterations,
    duration_seconds: durationSeconds,
    stop_on_failure: stopOnFailure,
    iterations
  };
  const paths = persistSoakResult(reportDir, result, endedAtDate);
  return {
    ...result,
    paths
  };
}

module.exports = {
  runBetaSoakMonitor
};
