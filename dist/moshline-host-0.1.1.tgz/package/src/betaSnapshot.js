const fs = require('node:fs');
const path = require('node:path');

function parsePositiveInt(value, defaultValue) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return defaultValue;
  }
  return parsed;
}

function parseOptionalUnitInterval(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  const parsed = Number.parseFloat(String(value).trim());
  if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1) {
    return null;
  }
  return parsed;
}

function normalizeBridgeBaseUrl(bridgeBaseUrl) {
  if (typeof bridgeBaseUrl !== 'string' || bridgeBaseUrl.trim() === '') {
    throw new Error('bridgeBaseUrl is required');
  }
  const normalized = bridgeBaseUrl.trim();
  const parsed = new URL(normalized);
  parsed.pathname = '';
  parsed.search = '';
  parsed.hash = '';
  return parsed.toString().replace(/\/$/, '');
}

function endpointURL(baseUrl, pathname, query = {}) {
  const url = new URL(pathname, `${baseUrl}/`);
  for (const [key, value] of Object.entries(query)) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    url.searchParams.set(key, String(value));
  }
  return url.toString();
}

async function fetchJsonEndpoint(url, fetchImpl) {
  let response;
  try {
    response = await fetchImpl(url);
  } catch (error) {
    return {
      ok: false,
      status: null,
      url,
      error: error instanceof Error ? error.message : String(error),
      data: null
    };
  }

  const status = Number.isFinite(response.status) ? response.status : null;
  let textBody = '';
  try {
    textBody = await response.text();
  } catch (error) {
    return {
      ok: false,
      status,
      url,
      error: error instanceof Error ? error.message : String(error),
      data: null
    };
  }

  let data = null;
  if (textBody.trim() !== '') {
    try {
      data = JSON.parse(textBody);
    } catch (error) {
      return {
        ok: false,
        status,
        url,
        error: 'invalid JSON response',
        data: null
      };
    }
  }

  const httpOk = status !== null ? status >= 200 && status <= 299 : false;
  const payloadOk = !(data && typeof data === 'object' && data.ok === false);
  const ok = httpOk && payloadOk;
  const payloadError = data && typeof data.error === 'string' ? data.error : null;

  return {
    ok,
    status,
    url,
    error: ok ? null : (payloadError || `HTTP ${status}`),
    data
  };
}

function safeSnapshotStamp(nowDate) {
  return nowDate.toISOString().replace(/[:]/g, '-').replace(/\.\d{3}Z$/, 'Z');
}

function ratioToPercent(value) {
  if (!Number.isFinite(value)) {
    return 'n/a';
  }
  return `${(value * 100).toFixed(2)}%`;
}

function gateCheckValue(betaGates, id, field) {
  const checks = Array.isArray(betaGates?.checks) ? betaGates.checks : [];
  const check = checks.find((item) => item && item.id === id);
  if (!check || !Object.prototype.hasOwnProperty.call(check, field)) {
    return null;
  }
  return check[field];
}

function resolveSummary(endpoints) {
  const endpointResults = Object.values(endpoints);
  const endpointOkCount = endpointResults.filter((item) => item.ok).length;
  const endpointFailCount = endpointResults.length - endpointOkCount;

  const healthOk = endpoints.health.ok && endpoints.health.data && endpoints.health.data.ok === true;
  const betaGates = endpoints.kpi_beta_gates.data && endpoints.kpi_beta_gates.data.gates
    ? endpoints.kpi_beta_gates.data.gates
    : null;
  const betaOverall = betaGates && typeof betaGates.overall_status === 'string'
    ? betaGates.overall_status
    : null;
  const cursorUnresolved = endpoints.kpi.data
    && endpoints.kpi.data.kpi
    && endpoints.kpi.data.kpi.reliability
    ? endpoints.kpi.data.kpi.reliability.cursor_conflicts_unresolved
    : null;
  const unresolvedHighRiskSecurityAlerts = betaGates
    && betaGates.external_evidence
    && Number.isFinite(betaGates.external_evidence.unresolved_high_risk_security_alerts)
    ? betaGates.external_evidence.unresolved_high_risk_security_alerts
    : null;
  const approvalDecisionRate = gateCheckValue(betaGates, 'approval.decision_rate', 'current_value');
  const crashFreeSessionRate = gateCheckValue(betaGates, 'app.crash_free_sessions', 'current_value');
  const taskCompletionRate = gateCheckValue(betaGates, 'task.completion_rate', 'current_value');
  const connectionSuccessRate = gateCheckValue(betaGates, 'connection.success_rate', 'current_value');
  const approvalAverageLatencyMs = gateCheckValue(betaGates, 'approval.average_latency_ms', 'current_value');
  const approvalP95LatencyMs = gateCheckValue(betaGates, 'approval.p95_latency_ms', 'current_value');
  const cursorConflictRecoveryRate = endpoints.kpi.data
    && endpoints.kpi.data.kpi
    && endpoints.kpi.data.kpi.reliability
    ? endpoints.kpi.data.kpi.reliability.cursor_conflict_recovery_rate
    : null;

  let overallStatus = 'pass';
  if (!healthOk) {
    overallStatus = 'fail';
  } else if (betaOverall === 'fail') {
    overallStatus = 'fail';
  } else if (endpointFailCount > 0) {
    overallStatus = 'degraded';
  } else if (betaOverall === 'pass_with_unknown') {
    overallStatus = 'pass_with_unknown';
  }

  return {
    overall_status: overallStatus,
    health_ok: Boolean(healthOk),
    endpoint_ok_count: endpointOkCount,
    endpoint_fail_count: endpointFailCount,
    beta_gates_overall_status: betaOverall,
    beta_pass_count: betaGates && Number.isFinite(betaGates.pass_count) ? betaGates.pass_count : null,
    beta_fail_count: betaGates && Number.isFinite(betaGates.fail_count) ? betaGates.fail_count : null,
    beta_unknown_count: betaGates && Number.isFinite(betaGates.unknown_count) ? betaGates.unknown_count : null,
    connection_success_rate: Number.isFinite(connectionSuccessRate) ? connectionSuccessRate : null,
    approval_decision_rate: Number.isFinite(approvalDecisionRate) ? approvalDecisionRate : null,
    approval_average_latency_ms: Number.isFinite(approvalAverageLatencyMs) ? approvalAverageLatencyMs : null,
    approval_p95_latency_ms: Number.isFinite(approvalP95LatencyMs) ? approvalP95LatencyMs : null,
    task_completion_rate: Number.isFinite(taskCompletionRate) ? taskCompletionRate : null,
    cursor_conflict_recovery_rate: Number.isFinite(cursorConflictRecoveryRate) ? cursorConflictRecoveryRate : null,
    cursor_conflicts_unresolved: Number.isFinite(cursorUnresolved) ? cursorUnresolved : null,
    unresolved_high_risk_security_alerts: Number.isFinite(unresolvedHighRiskSecurityAlerts)
      ? unresolvedHighRiskSecurityAlerts
      : null,
    crash_free_session_rate: Number.isFinite(crashFreeSessionRate) ? crashFreeSessionRate : null
  };
}

function buildMarkdownReport(snapshot) {
  const lines = [];
  lines.push('# Nomad Beta Snapshot');
  lines.push('');
  lines.push(`- Generated At: ${snapshot.generated_at}`);
  lines.push(`- Bridge: ${snapshot.bridge_base_url}`);
  lines.push(`- Window Seconds: ${snapshot.query.window_seconds}`);
  lines.push(`- Overall: ${snapshot.summary.overall_status}`);
  lines.push('');
  lines.push('## Endpoint Status');
  lines.push('');
  lines.push('| Endpoint | OK | HTTP | Error |');
  lines.push('| --- | --- | --- | --- |');
  for (const [key, value] of Object.entries(snapshot.endpoints)) {
    const status = value.status === null ? 'n/a' : String(value.status);
    const error = value.error ? String(value.error).replace(/\|/g, '\\|') : '';
    lines.push(`| ${value.url} | ${value.ok ? 'yes' : 'no'} | ${status} | ${error} |`);
    if (key) {
      // keep linter happy about key in loop context
    }
  }
  lines.push('');
  lines.push('## KPI Gate Snapshot');
  lines.push('');
  lines.push(`- beta_gates_overall_status: ${snapshot.summary.beta_gates_overall_status ?? 'n/a'}`);
  lines.push(`- beta_pass_count: ${snapshot.summary.beta_pass_count ?? 'n/a'}`);
  lines.push(`- beta_fail_count: ${snapshot.summary.beta_fail_count ?? 'n/a'}`);
  lines.push(`- beta_unknown_count: ${snapshot.summary.beta_unknown_count ?? 'n/a'}`);
  lines.push(`- connection_success_rate: ${ratioToPercent(snapshot.summary.connection_success_rate)}`);
  lines.push(`- approval_decision_rate: ${ratioToPercent(snapshot.summary.approval_decision_rate)}`);
  lines.push(`- approval_average_latency_ms: ${snapshot.summary.approval_average_latency_ms ?? 'n/a'}`);
  lines.push(`- approval_p95_latency_ms: ${snapshot.summary.approval_p95_latency_ms ?? 'n/a'}`);
  lines.push(`- task_completion_rate: ${ratioToPercent(snapshot.summary.task_completion_rate)}`);
  lines.push(`- cursor_conflict_recovery_rate: ${ratioToPercent(snapshot.summary.cursor_conflict_recovery_rate)}`);
  lines.push(`- cursor_conflicts_unresolved: ${snapshot.summary.cursor_conflicts_unresolved ?? 'n/a'}`);
  lines.push(`- unresolved_high_risk_security_alerts: ${snapshot.summary.unresolved_high_risk_security_alerts ?? 'n/a'}`);
  if (Number.isFinite(snapshot.query.crash_free_session_rate)) {
    lines.push(`- crash_free_session_rate_input: ${ratioToPercent(snapshot.query.crash_free_session_rate)}`);
  }
  lines.push('');
  return `${lines.join('\n')}\n`;
}

async function collectBetaAcceptanceSnapshot(options = {}) {
  const bridgeBaseUrl = normalizeBridgeBaseUrl(options.bridgeBaseUrl);
  const outputDir = typeof options.outputDir === 'string' && options.outputDir.trim() !== ''
    ? path.resolve(options.outputDir)
    : path.resolve(process.cwd(), 'reports', 'beta-acceptance');
  const windowSeconds = parsePositiveInt(options.windowSeconds, 3600);
  const baselineWindowSeconds = parsePositiveInt(options.baselineWindowSeconds, 86400);
  const consistencyLimit = parsePositiveInt(options.consistencyLimit, 20);
  const crashFreeSessionRate = parseOptionalUnitInterval(options.crashFreeSessionRate);
  const nowDate = options.now instanceof Date ? options.now : new Date();
  const fetchImpl = typeof options.fetchImpl === 'function' ? options.fetchImpl : globalThis.fetch;
  if (typeof fetchImpl !== 'function') {
    throw new Error('fetch implementation is not available');
  }

  const urls = {
    health: endpointURL(bridgeBaseUrl, '/health'),
    kpi: endpointURL(bridgeBaseUrl, '/metrics/kpi', {
      window_seconds: windowSeconds
    }),
    kpi_beta_gates: endpointURL(bridgeBaseUrl, '/metrics/kpi/beta-gates', {
      window_seconds: windowSeconds,
      crash_free_session_rate: crashFreeSessionRate
    }),
    kpi_anomalies: endpointURL(bridgeBaseUrl, '/metrics/kpi/anomalies', {
      window_seconds: windowSeconds,
      baseline_window_seconds: baselineWindowSeconds
    }),
    replay_consistency: endpointURL(bridgeBaseUrl, '/metrics/replay/consistency', {
      window_seconds: windowSeconds,
      limit: consistencyLimit
    }),
    security_alert_summary: endpointURL(bridgeBaseUrl, '/security/alerts/summary', {
      window_seconds: windowSeconds
    })
  };

  const [health, kpi, kpiBetaGates, kpiAnomalies, replayConsistency, securityAlertSummary] = await Promise.all([
    fetchJsonEndpoint(urls.health, fetchImpl),
    fetchJsonEndpoint(urls.kpi, fetchImpl),
    fetchJsonEndpoint(urls.kpi_beta_gates, fetchImpl),
    fetchJsonEndpoint(urls.kpi_anomalies, fetchImpl),
    fetchJsonEndpoint(urls.replay_consistency, fetchImpl),
    fetchJsonEndpoint(urls.security_alert_summary, fetchImpl)
  ]);

  const endpoints = {
    health,
    kpi,
    kpi_beta_gates: kpiBetaGates,
    kpi_anomalies: kpiAnomalies,
    replay_consistency: replayConsistency,
    security_alert_summary: securityAlertSummary
  };

  const summary = resolveSummary(endpoints);
  const snapshot = {
    schema_version: 'nomad.beta.snapshot.v1',
    generated_at: nowDate.toISOString(),
    generated_timestamp: Math.floor(nowDate.getTime() / 1000),
    bridge_base_url: bridgeBaseUrl,
    query: {
      window_seconds: windowSeconds,
      baseline_window_seconds: baselineWindowSeconds,
      consistency_limit: consistencyLimit,
      crash_free_session_rate: crashFreeSessionRate
    },
    summary,
    endpoints
  };

  fs.mkdirSync(outputDir, { recursive: true });
  const stamp = safeSnapshotStamp(nowDate);
  const jsonPath = path.join(outputDir, `snapshot-${stamp}.json`);
  const markdownPath = path.join(outputDir, `snapshot-${stamp}.md`);
  const latestJsonPath = path.join(outputDir, 'latest.json');
  const latestMarkdownPath = path.join(outputDir, 'latest.md');
  const historyPath = path.join(outputDir, 'history.ndjson');

  fs.writeFileSync(jsonPath, `${JSON.stringify(snapshot, null, 2)}\n`, 'utf8');
  fs.writeFileSync(markdownPath, buildMarkdownReport(snapshot), 'utf8');
  fs.writeFileSync(latestJsonPath, `${JSON.stringify(snapshot, null, 2)}\n`, 'utf8');
  fs.writeFileSync(latestMarkdownPath, buildMarkdownReport(snapshot), 'utf8');
  fs.appendFileSync(historyPath, `${JSON.stringify({
    generated_at: snapshot.generated_at,
    generated_timestamp: snapshot.generated_timestamp,
    overall_status: summary.overall_status,
    endpoint_fail_count: summary.endpoint_fail_count,
    beta_gates_overall_status: summary.beta_gates_overall_status,
    connection_success_rate: summary.connection_success_rate,
    approval_decision_rate: summary.approval_decision_rate,
    approval_average_latency_ms: summary.approval_average_latency_ms,
    approval_p95_latency_ms: summary.approval_p95_latency_ms,
    task_completion_rate: summary.task_completion_rate,
    cursor_conflict_recovery_rate: summary.cursor_conflict_recovery_rate,
    cursor_conflicts_unresolved: summary.cursor_conflicts_unresolved,
    unresolved_high_risk_security_alerts: summary.unresolved_high_risk_security_alerts,
    crash_free_session_rate: summary.crash_free_session_rate
  })}\n`, 'utf8');

  return {
    ...snapshot,
    paths: {
      json: jsonPath,
      markdown: markdownPath,
      latest_json: latestJsonPath,
      latest_markdown: latestMarkdownPath,
      history: historyPath
    }
  };
}

module.exports = {
  collectBetaAcceptanceSnapshot
};
