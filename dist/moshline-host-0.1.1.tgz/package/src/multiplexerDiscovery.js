'use strict';

const { execFileSync } = require('node:child_process');

const FIELD_SEPARATOR = '\u001f';
const MAX_OUTPUT_BYTES = 256 * 1024;
const MAX_TOKEN_LENGTH = 4096;

function defaultRunCommand(command, args) {
  return execFileSync(command, args, {
    encoding: 'utf8',
    timeout: 2000,
    maxBuffer: MAX_OUTPUT_BYTES,
    stdio: ['ignore', 'pipe', 'ignore']
  });
}

function boundedString(value, { required = false, maxLength = 1024 } = {}) {
  const normalized = typeof value === 'string' ? value.trim() : '';
  if ((required && normalized === '')
    || normalized.length > maxLength
    || normalized.includes('\0')
    || normalized.includes('\n')
    || normalized.includes('\r')) {
    throw new Error('invalid multiplexer target field');
  }
  return normalized || null;
}

function normalizeAttachTarget(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('invalid multiplexer attach token');
  }
  const kind = boundedString(value.kind, { required: true, maxLength: 32 });
  if (kind !== 'tmux' && kind !== 'zellij') {
    throw new Error('unsupported multiplexer kind');
  }
  return {
    kind,
    session: boundedString(value.session, { required: true, maxLength: 512 }),
    window: boundedString(value.window, { maxLength: 128 }),
    pane: boundedString(value.pane, { maxLength: 128 })
  };
}

function encodeAttachTarget(value) {
  return Buffer.from(JSON.stringify(normalizeAttachTarget(value)), 'utf8').toString('base64url');
}

function decodeAttachTarget(token) {
  if (typeof token !== 'string'
    || token.length === 0
    || token.length > MAX_TOKEN_LENGTH
    || !/^[A-Za-z0-9_-]+$/.test(token)) {
    throw new Error('invalid multiplexer attach token');
  }
  let value;
  try {
    value = JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
  } catch {
    throw new Error('invalid multiplexer attach token');
  }
  return normalizeAttachTarget(value);
}

function stripANSI(value) {
  return value.replace(/\u001b\[[0-?]*[ -/]*[@-~]/g, '');
}

function parseTmuxTargets(output) {
  return String(output || '')
    .split(/\r?\n/)
    .filter(Boolean)
    .flatMap((line) => {
      const fields = line.split(FIELD_SEPARATOR);
      if (fields.length !== 10) {
        return [];
      }
      const [sessionID, sessionName, windowID, windowIndex, windowName,
        paneID, paneIndex, paneTitle, cwd, active] = fields;
      try {
        const attachToken = encodeAttachTarget({
          kind: 'tmux',
          session: sessionName,
          window: windowIndex,
          pane: paneID
        });
        return [{
          id: `tmux:${sessionID}:${windowID}:${paneID}`,
          kind: 'tmux',
          session_id: sessionID || null,
          session_name: sessionName || null,
          window_id: windowID || null,
          window_index: windowIndex || null,
          window_name: windowName || null,
          pane_id: paneID || null,
          pane_index: paneIndex || null,
          pane_title: paneTitle || null,
          cwd: cwd || null,
          active: active === '1',
          confidence: 'observed',
          attach_token: attachToken
        }];
      } catch {
        return [];
      }
    });
}

function parseZellijTargets(output) {
  return String(output || '')
    .split(/\r?\n/)
    .map((line) => stripANSI(line).trim())
    .filter(Boolean)
    .flatMap((sessionName) => {
      try {
        return [{
          id: `zellij:${sessionName}`,
          kind: 'zellij',
          session_id: sessionName,
          session_name: sessionName,
          window_id: null,
          window_index: null,
          window_name: null,
          pane_id: null,
          pane_index: null,
          pane_title: null,
          cwd: null,
          active: false,
          confidence: 'observed',
          attach_token: encodeAttachTarget({
            kind: 'zellij',
            session: sessionName,
            window: null,
            pane: null
          })
        }];
      } catch {
        return [];
      }
    });
}

function createMultiplexerDiscovery({ runCommand = defaultRunCommand } = {}) {
  function adapterAvailable(command, versionArgs) {
    try {
      return String(runCommand(command, versionArgs) || '').trim() !== '';
    } catch {
      return false;
    }
  }

  function availableKinds() {
    const kinds = [];
    if (adapterAvailable('tmux', ['-V'])) {
      kinds.push('tmux');
    }
    if (adapterAvailable('zellij', ['--version'])) {
      kinds.push('zellij');
    }
    return kinds;
  }

  function capabilities() {
    const kinds = availableKinds();
    if (kinds.length === 0) {
      return [];
    }
    return ['multiplexer.list', ...kinds.map((kind) => `multiplexer.${kind}`)];
  }

  function list() {
    const kinds = availableKinds();
    const targets = [];
    if (kinds.includes('tmux')) {
      try {
        const format = [
          '#{session_id}', '#{session_name}', '#{window_id}', '#{window_index}',
          '#{window_name}', '#{pane_id}', '#{pane_index}', '#{pane_title}',
          '#{pane_current_path}', '#{pane_active}'
        ].join(FIELD_SEPARATOR);
        targets.push(...parseTmuxTargets(runCommand('tmux', [
          'list-panes', '-a', '-F', format
        ])));
      } catch {
        // The tmux server may exit between the version probe and the list call.
      }
    }
    if (kinds.includes('zellij')) {
      try {
        targets.push(...parseZellijTargets(runCommand('zellij', [
          'list-sessions', '--short', '--no-formatting'
        ])));
      } catch {
        // The Zellij server may exit between the version probe and the list call.
      }
    }
    return targets;
  }

  return { capabilities, list };
}

module.exports = {
  createMultiplexerDiscovery,
  decodeAttachTarget,
  encodeAttachTarget,
  parseTmuxTargets,
  parseZellijTargets
};
