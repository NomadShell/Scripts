const { spawn } = require('node:child_process');

const { normalizeCodexCliLine, normalizeCodexMcpEvent } = require('./normalize');

function createMessagePump(onMessage) {
  let buffer = '';

  function drain(flushTail = false) {
    while (true) {
      buffer = buffer.replace(/^\r?\n+/, '');
      if (!buffer) {
        break;
      }

      if (/^Content-Length:/i.test(buffer)) {
        let headerEnd = buffer.indexOf('\r\n\r\n');
        let delimiterLength = 4;
        if (headerEnd < 0) {
          headerEnd = buffer.indexOf('\n\n');
          delimiterLength = 2;
        }
        if (headerEnd < 0) {
          break;
        }

        const headerBlock = buffer.slice(0, headerEnd);
        const lengthMatch = headerBlock.match(/Content-Length:\s*(\d+)/i);
        const bodyLength = lengthMatch ? Number.parseInt(lengthMatch[1], 10) : NaN;
        if (!Number.isFinite(bodyLength) || bodyLength < 0) {
          const nextLineEnd = buffer.indexOf('\n');
          if (nextLineEnd < 0) {
            break;
          }
          const line = buffer.slice(0, nextLineEnd).trim();
          buffer = buffer.slice(nextLineEnd + 1);
          if (line) {
            onMessage(line);
          }
          continue;
        }

        const frameEnd = headerEnd + delimiterLength + bodyLength;
        if (buffer.length < frameEnd) {
          break;
        }

        const body = buffer.slice(headerEnd + delimiterLength, frameEnd).trim();
        buffer = buffer.slice(frameEnd);
        if (body) {
          onMessage(body);
        }
        continue;
      }

      const lineEnd = buffer.indexOf('\n');
      if (lineEnd < 0) {
        if (flushTail) {
          const tail = buffer.trim();
          buffer = '';
          if (tail) {
            onMessage(tail);
          }
        }
        break;
      }
      const line = buffer.slice(0, lineEnd).trim();
      buffer = buffer.slice(lineEnd + 1);
      if (line) {
        onMessage(line);
      }
    }
  }

  return {
    push(chunk) {
      buffer += chunk.toString('utf8');
      drain(false);
    },
    flush() {
      drain(true);
    }
  };
}

function createCodexSessionRunner(options) {
  const {
    sessionId,
    command,
    args,
    cwd,
    env,
    onEvent,
    onError,
    onExit,
    spawnImpl
  } = options;

  const doSpawn = typeof spawnImpl === 'function' ? spawnImpl : spawn;
  let child = null;
  let running = false;

  function normalizeJsonRpcId(id) {
    if (typeof id === 'number' && Number.isFinite(id)) {
      return id;
    }
    if (typeof id !== 'string') {
      return null;
    }
    const trimmed = id.trim();
    if (!trimmed) {
      return null;
    }
    if (/^-?\d+$/.test(trimmed)) {
      return Number.parseInt(trimmed, 10);
    }
    return trimmed;
  }

  function emitEvent(event) {
    if (event) {
      onEvent(event);
    }
  }

  function emitError(message, traceId) {
    emitEvent(normalizeCodexMcpEvent({
      session_id: sessionId,
      event_type: 'error',
      payload: { message },
      trace_id: traceId
    }));
  }

  function start() {
    if (running) {
      return;
    }

    child = doSpawn(command, Array.isArray(args) ? args : [], {
      cwd,
      env,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    running = true;

    const stdoutPump = createMessagePump((message) => {
      const event = normalizeCodexCliLine(sessionId, message, 'stdout');
      emitEvent(event);
    });
    const stderrPump = createMessagePump((message) => {
      const event = normalizeCodexCliLine(sessionId, message, 'stderr');
      emitEvent(event);
    });
    let exited = false;
    let flushed = false;

    function flushBuffersOnce() {
      if (flushed) {
        return;
      }
      flushed = true;
      stdoutPump.flush();
      stderrPump.flush();
    }

    function finalizeExit(code, signal) {
      if (exited) {
        return;
      }
      exited = true;
      running = false;
      flushBuffersOnce();
      onExit(code, signal);
    }

    if (child.stdout) {
      child.stdout.on('data', (chunk) => stdoutPump.push(chunk));
    }
    if (child.stderr) {
      child.stderr.on('data', (chunk) => stderrPump.push(chunk));
    }

    child.on('error', (error) => {
      onError(error);
      emitError(error.message);
      finalizeExit(null, 'spawn_error');
    });

    child.on('exit', (code, signal) => {
      finalizeExit(code, signal);
    });

    child.on('close', (code, signal) => {
      finalizeExit(code, signal);
    });
  }

  function stop() {
    if (!running || !child) {
      return;
    }
    child.kill('SIGTERM');
  }

  function respondElicitation(requestId, decision, reason = '') {
    if (!running || !child || !child.stdin) {
      return false;
    }
    const jsonRpcId = normalizeJsonRpcId(requestId);
    if (jsonRpcId === null) {
      return false;
    }
    const normalizedDecision = decision === 'denied' ? 'denied' : 'approved';
    const result = { decision: normalizedDecision };
    if (normalizedDecision === 'denied' && typeof reason === 'string' && reason.trim() !== '') {
      result.reason = reason;
    }
    const frameBody = JSON.stringify({
      jsonrpc: '2.0',
      id: jsonRpcId,
      result
    });
    const frame = `Content-Length: ${Buffer.byteLength(frameBody, 'utf8')}\r\n\r\n${frameBody}`;
    child.stdin.write(frame);
    return true;
  }

  return {
    start,
    stop,
    respondElicitation,
    isRunning: () => running,
    pid: () => (child ? child.pid : null)
  };
}

module.exports = {
  createCodexSessionRunner
};
