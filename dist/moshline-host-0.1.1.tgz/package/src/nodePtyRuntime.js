const fs = require('node:fs');
const path = require('node:path');

function ensureNodePtyHelperExecutable({
  platform = process.platform,
  arch = process.arch,
  packagePath = require.resolve('node-pty/package.json')
} = {}) {
  if (platform !== 'darwin') {
    return null;
  }
  const helperPath = path.join(
    path.dirname(packagePath),
    'prebuilds',
    `${platform}-${arch}`,
    'spawn-helper'
  );
  if (!fs.existsSync(helperPath)) {
    return null;
  }
  const mode = fs.statSync(helperPath).mode & 0o777;
  if ((mode & 0o100) === 0) {
    fs.chmodSync(helperPath, mode | 0o100);
  }
  return helperPath;
}

function loadNodePty() {
  ensureNodePtyHelperExecutable();
  return require('node-pty');
}

module.exports = { ensureNodePtyHelperExecutable, loadNodePty };
