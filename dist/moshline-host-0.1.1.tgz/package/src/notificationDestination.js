'use strict';

const fs = require('node:fs');
const path = require('node:path');

function normalizeWebhookURL(value) {
  if (typeof value !== 'string' || value.trim() === '' || value.length > 4096) {
    throw new Error('webhook_url must be a non-empty HTTPS URL');
  }
  let parsed;
  try {
    parsed = new URL(value.trim());
  } catch {
    throw new Error('webhook_url must be a non-empty HTTPS URL');
  }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.hash) {
    throw new Error('webhook_url must be a non-empty HTTPS URL');
  }
  return parsed.toString();
}

function createNotificationDestinationStore({ filePath }) {
  let webhookURL = '';
  try {
    webhookURL = normalizeWebhookURL(JSON.parse(fs.readFileSync(filePath, 'utf8')).webhook_url);
  } catch {
    webhookURL = '';
  }
  return {
    get: () => webhookURL,
    describe: () => ({
      configured: webhookURL !== '',
      origin: webhookURL ? new URL(webhookURL).origin : null
    }),
    set(value) {
      webhookURL = normalizeWebhookURL(value);
      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      const temporaryPath = `${filePath}.tmp-${process.pid}`;
      fs.writeFileSync(temporaryPath, `${JSON.stringify({ webhook_url: webhookURL }, null, 2)}\n`, {
        mode: 0o600
      });
      fs.renameSync(temporaryPath, filePath);
      return this.describe();
    }
  };
}

module.exports = { createNotificationDestinationStore, normalizeWebhookURL };
