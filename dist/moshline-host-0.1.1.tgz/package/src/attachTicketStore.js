const { randomBytes } = require('node:crypto');

function createAttachTicketStore({
  ttlMs = 30_000,
  now = () => Date.now(),
  randomBytesFactory = randomBytes
} = {}) {
  const tickets = new Map();

  function purgeExpired() {
    const timestamp = now();
    for (const [ticket, record] of tickets) {
      if (record.expiresAtMs <= timestamp) {
        tickets.delete(ticket);
      }
    }
  }

  function issue({ surfaceId, serverBootID }) {
    purgeExpired();
    let ticket = '';
    for (let attempt = 0; attempt < 8; attempt += 1) {
      ticket = randomBytesFactory(32).toString('base64url');
      if (!tickets.has(ticket)) {
        break;
      }
      ticket = '';
    }
    if (ticket === '') {
      throw new Error('could not allocate a unique attach ticket');
    }
    const expiresAtMs = now() + ttlMs;
    tickets.set(ticket, { surfaceId, serverBootID, expiresAtMs });
    return {
      ticket,
      surface_id: surfaceId,
      server_boot_id: serverBootID,
      expires_at: new Date(expiresAtMs).toISOString()
    };
  }

  function consume(ticket, serverBootID) {
    purgeExpired();
    const record = tickets.get(ticket);
    if (!record) {
      return null;
    }
    tickets.delete(ticket);
    if (record.serverBootID !== serverBootID) {
      return null;
    }
    return {
      surface_id: record.surfaceId,
      server_boot_id: record.serverBootID
    };
  }

  function clear() {
    tickets.clear();
  }

  return { issue, consume, clear };
}

module.exports = { createAttachTicketStore };
