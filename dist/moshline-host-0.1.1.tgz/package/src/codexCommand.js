const { execSync, spawnSync } = require('node:child_process');

function resolveCodexMcpSubcommandFromVersionOutput(versionOutput) {
  if (typeof versionOutput !== 'string') {
    return null;
  }

  const match = versionOutput.match(/codex-cli\s+(\d+)\.(\d+)\.(\d+)(?:-alpha\.(\d+))?/);
  if (!match) {
    return null;
  }

  const major = Number.parseInt(match[1], 10);
  const minor = Number.parseInt(match[2], 10);
  const patch = Number.parseInt(match[3], 10);
  const alpha = match[4] ? Number.parseInt(match[4], 10) : null;

  if (major > 0 || minor > 43) {
    return 'mcp-server';
  }
  if (minor < 43) {
    return 'mcp';
  }
  if (patch > 0) {
    return 'mcp-server';
  }
  if (alpha === null) {
    return 'mcp-server';
  }
  return alpha >= 5 ? 'mcp-server' : 'mcp';
}

function detectCodexMcpSubcommand(execFn) {
  const doExec = typeof execFn === 'function'
    ? execFn
    : () => execSync('codex --version', { encoding: 'utf8' });

  try {
    const output = doExec();
    return resolveCodexMcpSubcommandFromVersionOutput(output);
  } catch {
    return null;
  }
}

function resolveCodexLaunch(options = {}) {
  const command = typeof options.command === 'string' && options.command.trim() !== ''
    ? options.command
    : 'codex';
  const args = Array.isArray(options.args) ? options.args.map(String) : [];
  const mode = options.mode === 'mcp' ? 'mcp' : 'cli';

  if (mode !== 'mcp' || command !== 'codex' || args.length > 0) {
    return {
      command,
      args,
      mode
    };
  }

  const detect = typeof options.detectMcpSubcommand === 'function'
    ? options.detectMcpSubcommand
    : () => detectCodexMcpSubcommand(options.execFn);
  const mcpSubcommand = detect() || 'mcp-server';
  return {
    command,
    args: [mcpSubcommand],
    mode,
    mcp_subcommand: mcpSubcommand
  };
}

function runCodexVersionCommand(command) {
  const result = spawnSync(command, ['--version'], {
    encoding: 'utf8'
  });
  if (result.error) {
    return {
      ok: false,
      error: result.error.message,
      error_code: result.error.code || null
    };
  }
  if (result.status !== 0) {
    const message = (result.stderr || result.stdout || `command exited ${result.status}`).trim();
    return {
      ok: false,
      error: message || `command exited ${result.status}`,
      error_code: `EXIT_${result.status}`
    };
  }
  const output = (result.stdout || result.stderr || '').trim();
  if (!output) {
    return {
      ok: false,
      error: 'empty version output',
      error_code: 'EMPTY_OUTPUT'
    };
  }
  return {
    ok: true,
    output
  };
}

function inspectCodexRuntime(options = {}) {
  const command = typeof options.command === 'string' && options.command.trim() !== ''
    ? options.command.trim()
    : 'codex';
  const runVersionCommand = typeof options.runVersionCommand === 'function'
    ? options.runVersionCommand
    : runCodexVersionCommand;
  const probe = runVersionCommand(command);
  if (!probe || probe.ok !== true || typeof probe.output !== 'string') {
    return {
      available: false,
      command,
      version: null,
      mcp_subcommand: null,
      error: probe && typeof probe.error === 'string' ? probe.error : 'failed to run version command',
      error_code: probe && probe.error_code ? String(probe.error_code) : null
    };
  }
  return {
    available: true,
    command,
    version: probe.output,
    mcp_subcommand: resolveCodexMcpSubcommandFromVersionOutput(probe.output),
    error: null,
    error_code: null
  };
}

module.exports = {
  resolveCodexMcpSubcommandFromVersionOutput,
  resolveCodexLaunch,
  inspectCodexRuntime
};
