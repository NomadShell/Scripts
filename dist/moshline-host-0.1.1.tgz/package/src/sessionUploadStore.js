'use strict';

const { randomUUID } = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const TYPE_RULES = Object.freeze({
  'image/png': { kind: 'image', maxBytes: 5 * 1024 * 1024 },
  'image/jpeg': { kind: 'image', maxBytes: 5 * 1024 * 1024 },
  'image/heic': { kind: 'image', maxBytes: 5 * 1024 * 1024 },
  'image/heif': { kind: 'image', maxBytes: 5 * 1024 * 1024 },
  'application/pdf': { kind: 'pdf', maxBytes: 10 * 1024 * 1024 },
  'text/plain': { kind: 'text', maxBytes: 2 * 1024 * 1024 },
  'text/x-log': { kind: 'text', maxBytes: 2 * 1024 * 1024 },
  'application/json': { kind: 'text', maxBytes: 2 * 1024 * 1024 }
});

function validateContent(data, rule) {
  if (rule.kind === 'pdf' && !data.subarray(0, 5).equals(Buffer.from('%PDF-'))) {
    throw new Error('PDF attachment has an invalid signature');
  }
  if (rule.kind === 'text') {
    let text;
    try {
      text = new TextDecoder('utf-8', { fatal: true }).decode(data);
    } catch {
      throw new Error('text attachment must be valid UTF-8');
    }
    if (text.includes('\0')) {
      throw new Error('text attachment cannot contain binary data');
    }
  }
}

function createSessionUploadStore({ maxBytes = 10 * 1024 * 1024, idFactory = randomUUID } = {}) {
  return {
    save({ workspace, name, mimeType, dataBase64 }) {
      if (typeof workspace !== 'string' || !path.isAbsolute(workspace)) {
        throw new Error('session workspace is invalid');
      }
      const rule = TYPE_RULES[mimeType];
      if (!rule) {
        throw new Error('unsupported attachment type');
      }
      if (typeof dataBase64 !== 'string' || !/^[A-Za-z0-9+/]*={0,2}$/.test(dataBase64)) {
        throw new Error('image data must be base64');
      }
      const data = Buffer.from(dataBase64, 'base64');
      const effectiveMaxBytes = Math.min(maxBytes, rule.maxBytes);
      if (data.length === 0 || data.length > effectiveMaxBytes) {
        throw new Error('attachment exceeds the upload size limit');
      }
      validateContent(data, rule);
      const originalName = path.basename(typeof name === 'string' ? name : 'attachment')
        .replace(/[^A-Za-z0-9._-]/g, '-')
        .slice(0, 100) || 'attachment';
      const uploadDirectory = path.join(workspace, '.moshline', 'uploads');
      fs.mkdirSync(uploadDirectory, { recursive: true, mode: 0o700 });
      const fileName = `${idFactory()}-${originalName}`;
      const absolutePath = path.join(uploadDirectory, fileName);
      fs.writeFileSync(absolutePath, data, { mode: 0o600, flag: 'wx' });
      return {
        relative_path: path.posix.join('.moshline', 'uploads', fileName),
        absolute_path: absolutePath,
        mime_type: mimeType,
        size_bytes: data.length
      };
    },
    capabilities() {
      return [
        'file.upload',
        'file.upload.image',
        'file.upload.pdf',
        'file.upload.text'
      ];
    }
  };
}

module.exports = { createSessionUploadStore };
