'use strict';

const { spawnSync } = require('node:child_process');
const path = require('node:path');

function runGit(cwd, args, maxBuffer) {
  const result = spawnSync('git', ['-C', cwd, ...args], {
    encoding: 'utf8',
    maxBuffer
  });
  if (result.error) {
    throw result.error;
  }
  if (result.status !== 0) {
    throw new Error((result.stderr || 'git diff failed').trim());
  }
  return result.stdout || '';
}

function validatePaths(paths) {
  if (!Array.isArray(paths)) {
    return [];
  }
  if (paths.length > 50) {
    throw new Error('too many diff paths');
  }
  return paths.map((value) => {
    if (typeof value !== 'string' || value.trim() === '' || value.includes('\0')) {
      throw new Error('diff path must be a relative repository path');
    }
    const normalized = value.replaceAll('\\', '/');
    if (path.posix.isAbsolute(normalized)
      || normalized.split('/').some((segment) => segment === '..')) {
      throw new Error('diff path must be a relative repository path');
    }
    return normalized;
  });
}

function splitFiles(patch) {
  const files = [];
  let current = null;
  for (const line of patch.split('\n')) {
    const match = line.match(/^diff --git a\/(.+) b\/(.+)$/);
    if (match) {
      if (current) {
        current.patch = current.lines.join('\n');
        delete current.lines;
        files.push(current);
      }
      current = { path: match[2], lines: [line] };
    } else if (current) {
      current.lines.push(line);
    }
  }
  if (current) {
    current.patch = current.lines.join('\n');
    delete current.lines;
    files.push(current);
  }
  return files;
}

function truncateUTF8(value, maxBytes) {
  const buffer = Buffer.from(value, 'utf8');
  if (buffer.length <= maxBytes) {
    return { value, truncated: false, bytes: buffer.length };
  }
  let end = maxBytes;
  while (end > 0 && (buffer[end] & 0xC0) === 0x80) {
    end -= 1;
  }
  return {
    value: buffer.subarray(0, end).toString('utf8'),
    truncated: true,
    bytes: end
  };
}

function createBoundedDiffReader({ runGit: injectedRunGit } = {}) {
  return {
    read({ cwd, paths = [], maxBytes = 512 * 1024, maxFiles = 100 }) {
      if (typeof cwd !== 'string' || !path.isAbsolute(cwd)) {
        throw new Error('diff cwd must be an absolute workspace path');
      }
      const safePaths = validatePaths(paths);
      const byteLimit = Math.min(Math.max(Number(maxBytes) || 0, 1024), 1024 * 1024);
      const fileLimit = Math.min(Math.max(Number(maxFiles) || 0, 1), 100);
      const args = ['diff', '--no-ext-diff', '--unified=3', '--', ...safePaths];
      const output = (injectedRunGit || ((workdir, gitArgs) => runGit(
        workdir,
        gitArgs,
        byteLimit * 4
      )))(cwd, args);
      const allFiles = splitFiles(output);
      const files = [];
      let remainingBytes = byteLimit;
      let truncated = allFiles.length > fileLimit;
      for (const file of allFiles.slice(0, fileLimit)) {
        const bounded = truncateUTF8(file.patch, remainingBytes);
        files.push({ path: file.path, patch: bounded.value });
        remainingBytes -= bounded.bytes;
        truncated ||= bounded.truncated;
        if (remainingBytes <= 0) {
          truncated = true;
          break;
        }
      }
      return {
        files,
        truncated,
        byte_limit: byteLimit,
        file_limit: fileLimit
      };
    }
  };
}

module.exports = { createBoundedDiffReader };
