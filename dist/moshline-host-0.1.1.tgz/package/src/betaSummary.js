const fs = require('node:fs');
const path = require('node:path');

function parsePositiveInt(value, defaultValue) {
  const parsed = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return defaultValue;
  }
  return parsed;
}

function safeSummaryStamp(nowDate) {
  return nowDate.toISOString().replace(/[:]/g, '-').replace(/\.\d{3}Z$/, 'Z');
}

function loadHistoryEntries(historyPath) {
  if (!fs.existsSync(historyPath)) {
    return [];
  }
  const raw = fs.readFileSync(historyPath, 'utf8');
  return raw
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter((value) => value && typeof value === 'object');
}

function selectWindowEntries(entries, nowDate, windowDays) {
  const nowTimestamp = Math.floor(nowDate.getTime() / 1000);
  const startTimestamp = nowTimestamp - (windowDays * 24 * 3600);
  return entries
    .filter((entry) => Number.isFinite(entry.generated_timestamp))
    .filter((entry) => entry.generated_timestamp >= startTimestamp && entry.generated_timestamp <= nowTimestamp)
    .sort((a, b) => b.generated_timestamp - a.generated_timestamp);
}

function numericValues(entries, field) {
  return entries
    .map((entry) => entry[field])
    .filter((value) => Number.isFinite(value));
}

function minMetric(entries, field) {
  const values = numericValues(entries, field);
  return values.length > 0 ? Math.min(...values) : null;
}

function maxMetric(entries, field) {
  const values = numericValues(entries, field);
  return values.length > 0 ? Math.max(...values) : null;
}

function buildEvidenceSummary(entries) {
  return {
    max_endpoint_fail_count: maxMetric(entries, 'endpoint_fail_count'),
    min_connection_success_rate: minMetric(entries, 'connection_success_rate'),
    min_approval_decision_rate: minMetric(entries, 'approval_decision_rate'),
    max_approval_average_latency_ms: maxMetric(entries, 'approval_average_latency_ms'),
    max_approval_p95_latency_ms: maxMetric(entries, 'approval_p95_latency_ms'),
    min_task_completion_rate: minMetric(entries, 'task_completion_rate'),
    min_cursor_conflict_recovery_rate: minMetric(entries, 'cursor_conflict_recovery_rate'),
    max_cursor_conflicts_unresolved: maxMetric(entries, 'cursor_conflicts_unresolved'),
    max_unresolved_high_risk_security_alerts: maxMetric(entries, 'unresolved_high_risk_security_alerts'),
    min_crash_free_session_rate: minMetric(entries, 'crash_free_session_rate')
  };
}

function buildGateResult(counts, expectedSamples, evidence) {
  if (counts.fail > 0) {
    return 'Fail';
  }
  if (Number.isFinite(evidence?.max_cursor_conflicts_unresolved) && evidence.max_cursor_conflicts_unresolved > 0) {
    return 'Fail';
  }
  if (
    Number.isFinite(evidence?.max_unresolved_high_risk_security_alerts)
    && evidence.max_unresolved_high_risk_security_alerts > 0
  ) {
    return 'Fail';
  }
  if (counts.total < expectedSamples) {
    return 'Conditional Pass';
  }
  if (counts.degraded > 0 || counts.pass_with_unknown > 0) {
    return 'Conditional Pass';
  }
  return 'Pass';
}

function buildMarkdownReport(summaryResult) {
  const { summary, latest_sample: latestSample } = summaryResult;
  const lines = [];
  lines.push('# Nomad Beta Window Summary');
  lines.push('');
  lines.push(`- Generated At: ${summary.generated_at}`);
  lines.push(`- Window Days: ${summary.window_days}`);
  lines.push(`- Gate Result: ${summary.gate_result}`);
  lines.push(`- Samples: ${summary.samples_in_window}/${summary.expected_samples}`);
  lines.push('');
  lines.push('## Gate Evidence');
  lines.push('');
  lines.push(`- max_endpoint_fail_count: ${summary.max_endpoint_fail_count ?? 'n/a'}`);
  lines.push(`- min_connection_success_rate: ${summary.min_connection_success_rate ?? 'n/a'}`);
  lines.push(`- min_approval_decision_rate: ${summary.min_approval_decision_rate ?? 'n/a'}`);
  lines.push(`- max_approval_average_latency_ms: ${summary.max_approval_average_latency_ms ?? 'n/a'}`);
  lines.push(`- max_approval_p95_latency_ms: ${summary.max_approval_p95_latency_ms ?? 'n/a'}`);
  lines.push(`- min_task_completion_rate: ${summary.min_task_completion_rate ?? 'n/a'}`);
  lines.push(`- min_cursor_conflict_recovery_rate: ${summary.min_cursor_conflict_recovery_rate ?? 'n/a'}`);
  lines.push(`- max_cursor_conflicts_unresolved: ${summary.max_cursor_conflicts_unresolved ?? 'n/a'}`);
  lines.push(`- max_unresolved_high_risk_security_alerts: ${summary.max_unresolved_high_risk_security_alerts ?? 'n/a'}`);
  lines.push(`- min_crash_free_session_rate: ${summary.min_crash_free_session_rate ?? 'n/a'}`);
  lines.push('');
  lines.push('## Status Counts');
  lines.push('');
  lines.push(`- pass: ${summary.pass_count}`);
  lines.push(`- pass_with_unknown: ${summary.pass_with_unknown_count}`);
  lines.push(`- degraded: ${summary.degraded_count}`);
  lines.push(`- fail: ${summary.fail_count}`);
  lines.push('');
  lines.push('## Latest Sample');
  lines.push('');
  if (latestSample) {
    lines.push(`- generated_at: ${latestSample.generated_at}`);
    lines.push(`- overall_status: ${latestSample.overall_status}`);
    lines.push(`- endpoint_fail_count: ${latestSample.endpoint_fail_count ?? 'n/a'}`);
    lines.push(`- beta_gates_overall_status: ${latestSample.beta_gates_overall_status ?? 'n/a'}`);
  } else {
    lines.push('- none');
  }
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function summarizeBetaAcceptanceWindow(options = {}) {
  const reportDir = typeof options.reportDir === 'string' && options.reportDir.trim() !== ''
    ? path.resolve(options.reportDir)
    : path.resolve(process.cwd(), 'reports', 'beta-acceptance');
  const windowDays = parsePositiveInt(options.windowDays, 7);
  const samplesPerDay = parsePositiveInt(options.samplesPerDay, 2);
  const expectedSamples = windowDays * samplesPerDay;
  const nowDate = options.now instanceof Date ? options.now : new Date();
  const historyPath = path.join(reportDir, 'history.ndjson');
  const historyEntries = loadHistoryEntries(historyPath);
  const windowEntries = selectWindowEntries(historyEntries, nowDate, windowDays);

  const counts = {
    total: windowEntries.length,
    pass: 0,
    pass_with_unknown: 0,
    degraded: 0,
    fail: 0
  };

  for (const entry of windowEntries) {
    const status = typeof entry.overall_status === 'string' ? entry.overall_status : 'degraded';
    if (status === 'pass') {
      counts.pass += 1;
    } else if (status === 'pass_with_unknown') {
      counts.pass_with_unknown += 1;
    } else if (status === 'fail') {
      counts.fail += 1;
    } else {
      counts.degraded += 1;
    }
  }

  const evidence = buildEvidenceSummary(windowEntries);
  const gateResult = buildGateResult(counts, expectedSamples, evidence);
  const summaryPayload = {
    schema_version: 'nomad.beta.summary.v1',
    generated_at: nowDate.toISOString(),
    generated_timestamp: Math.floor(nowDate.getTime() / 1000),
    window_days: windowDays,
    samples_per_day: samplesPerDay,
    expected_samples: expectedSamples,
    samples_in_window: counts.total,
    pass_count: counts.pass,
    pass_with_unknown_count: counts.pass_with_unknown,
    degraded_count: counts.degraded,
    fail_count: counts.fail,
    ...evidence,
    gate_result: gateResult
  };

  const outputPayload = {
    summary: summaryPayload,
    latest_sample: windowEntries[0] || null,
    samples: windowEntries
  };

  fs.mkdirSync(reportDir, { recursive: true });
  const stamp = safeSummaryStamp(nowDate);
  const jsonPath = path.join(reportDir, `summary-${stamp}.json`);
  const markdownPath = path.join(reportDir, `summary-${stamp}.md`);
  const latestJsonPath = path.join(reportDir, 'summary-latest.json');
  const latestMarkdownPath = path.join(reportDir, 'summary-latest.md');

  fs.writeFileSync(jsonPath, `${JSON.stringify(outputPayload, null, 2)}\n`, 'utf8');
  fs.writeFileSync(markdownPath, buildMarkdownReport(outputPayload), 'utf8');
  fs.writeFileSync(latestJsonPath, `${JSON.stringify(outputPayload, null, 2)}\n`, 'utf8');
  fs.writeFileSync(latestMarkdownPath, buildMarkdownReport(outputPayload), 'utf8');

  return {
    ...outputPayload,
    paths: {
      json: jsonPath,
      markdown: markdownPath,
      latest_json: latestJsonPath,
      latest_markdown: latestMarkdownPath
    }
  };
}

module.exports = {
  summarizeBetaAcceptanceWindow
};
