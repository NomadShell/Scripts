const state = {
  sessions: [],
  policy: null,
  policyAudit: [],
  selectedSessionId: '',
  eventCursorBySession: {},
  eventListBySession: {},
  decisionInFlightEventId: '',
  eventsTypeFilter: 'all'
};

const els = {
  badgeHealth: document.getElementById('badge-health'),
  badgeRuntime: document.getElementById('badge-runtime'),
  badgeSessions: document.getElementById('badge-sessions'),
  overviewList: document.getElementById('overview-list'),
  formStartSession: document.getElementById('form-start-session'),
  startSessionId: document.getElementById('start-session-id'),
  startMode: document.getElementById('start-mode'),
  startCwd: document.getElementById('start-cwd'),
  formSessionCommand: document.getElementById('form-session-command'),
  commandSessionId: document.getElementById('command-session-id'),
  commandMessage: document.getElementById('command-message'),
  btnSendPrompt: document.getElementById('btn-send-prompt'),
  btnAbortSession: document.getElementById('btn-abort-session'),
  btnRefreshEvents: document.getElementById('btn-refresh-events'),
  eventsTypeFilter: document.getElementById('events-type-filter'),
  sessionEventsMeta: document.getElementById('session-events-meta'),
  sessionEvents: document.getElementById('session-events'),
  permissionRequests: document.getElementById('permission-requests'),
  formPolicy: document.getElementById('form-policy'),
  policyWhitelist: document.getElementById('policy-whitelist'),
  policyEnforce: document.getElementById('policy-enforce'),
  policyAuditList: document.getElementById('policy-audit-list'),
  sessionTable: document.getElementById('session-table'),
  actionLog: document.getElementById('action-log'),
  btnRefresh: document.getElementById('btn-refresh'),
  btnReloadPolicy: document.getElementById('btn-reload-policy'),
  btnApplyPolicy: document.getElementById('btn-apply-policy')
};

function parseJson(text) {
  if (!text) {
    return {};
  }
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

async function requestJson(path, options = {}) {
  const response = await fetch(path, options);
  const bodyText = await response.text();
  const body = parseJson(bodyText);
  if (!response.ok) {
    const message = body && body.error ? body.error : `HTTP ${response.status}`;
    throw new Error(message);
  }
  return body;
}

function log(message) {
  const timestamp = new Date().toISOString();
  const nextLine = `[${timestamp}] ${message}`;
  const prev = els.actionLog.textContent || '';
  els.actionLog.textContent = `${nextLine}\n${prev}`.trimEnd();
}

function formatUnixSeconds(value) {
  if (!Number.isFinite(value)) {
    return '-';
  }
  return new Date(value * 1000).toLocaleString();
}

function parseWhitelistInput(input) {
  const seen = new Set();
  return String(input || '')
    .split(/[\n,]/)
    .map((item) => item.trim())
    .filter((item) => item.length > 0)
    .filter((item) => {
      if (seen.has(item)) {
        return false;
      }
      seen.add(item);
      return true;
    });
}

function formatEventSummary(event) {
  const payload = event && typeof event.payload === 'object' ? event.payload : {};
  const eventType = String((event && event.type) || 'unknown');
  if (eventType === 'task.step') {
    if (typeof payload.message === 'string' && payload.message.trim()) {
      return payload.message.trim();
    }
    if (typeof payload.text === 'string' && payload.text.trim()) {
      return payload.text.trim();
    }
  }
  if (eventType === 'tool.call' || eventType === 'tool.result') {
    const toolName = typeof payload.tool_name === 'string'
      ? payload.tool_name
      : (typeof payload.name === 'string' ? payload.name : 'tool');
    const status = typeof payload.status === 'string' ? ` status=${payload.status}` : '';
    return `${toolName}${status}`;
  }
  if (eventType === 'permission.requested') {
    const command = typeof payload.command === 'string' ? payload.command : '';
    return command ? `command=${command}` : 'approval requested';
  }
  if (eventType === 'permission.decided') {
    const decision = typeof payload.decision === 'string' ? payload.decision : 'decided';
    return `decision=${decision}`;
  }
  if (eventType === 'session.ended') {
    const exitCode = Number.isFinite(payload.exit_code) ? ` exit=${payload.exit_code}` : '';
    const signal = typeof payload.signal === 'string' ? ` signal=${payload.signal}` : '';
    return `${exitCode}${signal}`.trim() || 'session ended';
  }
  try {
    const raw = JSON.stringify(payload);
    if (!raw || raw === '{}') {
      return '';
    }
    return raw.length > 220 ? `${raw.slice(0, 220)}...` : raw;
  } catch {
    return '';
  }
}

function escapeHtml(input) {
  const text = String(input || '');
  return text
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function unresolvedPermissionRequestsForSession(sessionId) {
  const events = Array.isArray(state.eventListBySession[sessionId])
    ? state.eventListBySession[sessionId]
    : [];
  const decidedRequestEventIds = new Set();
  const decidedRequestIds = new Set();

  for (const event of events) {
    if (!event || event.type !== 'permission.decided') {
      continue;
    }
    const requestEventId = typeof event.payload?.request_event_id === 'string'
      ? event.payload.request_event_id.trim()
      : '';
    if (requestEventId) {
      decidedRequestEventIds.add(requestEventId);
    }
    const requestId = typeof event.payload?.request_id === 'string'
      ? event.payload.request_id.trim()
      : '';
    if (requestId) {
      decidedRequestIds.add(requestId);
    }
  }

  const pending = [];
  for (const event of events) {
    if (!event || event.type !== 'permission.requested') {
      continue;
    }
    const requestEventId = String(event.id || '');
    const requestId = typeof event.payload?.request_id === 'string'
      ? event.payload.request_id.trim()
      : '';
    if (requestEventId && decidedRequestEventIds.has(requestEventId)) {
      continue;
    }
    if (requestId && decidedRequestIds.has(requestId)) {
      continue;
    }
    pending.push(event);
  }
  return pending.slice(-20).reverse();
}

function matchEventTypeFilter(event, filter) {
  const eventType = String((event && event.type) || '');
  if (filter === 'all') {
    return true;
  }
  if (filter === 'permission') {
    return eventType.startsWith('permission.');
  }
  if (filter === 'tool') {
    return eventType.startsWith('tool.');
  }
  if (filter === 'task') {
    return eventType.startsWith('task.');
  }
  if (filter === 'session') {
    return eventType.startsWith('session.');
  }
  if (filter === 'system') {
    return eventType.startsWith('system.');
  }
  return true;
}

function renderPermissionRequests(sessionId) {
  if (!sessionId) {
    els.permissionRequests.innerHTML = '<p class="approval-meta">No session selected.</p>';
    return;
  }
  const pending = unresolvedPermissionRequestsForSession(sessionId);
  if (pending.length === 0) {
    els.permissionRequests.innerHTML = '<p class="approval-meta">No pending approvals.</p>';
    return;
  }

  const rows = pending.map((event) => {
    const eventId = String(event.id || '');
    const requestId = typeof event.payload?.request_id === 'string'
      ? event.payload.request_id.trim()
      : '';
    const command = typeof event.payload?.command === 'string'
      ? event.payload.command.trim()
      : '';
    const message = typeof event.payload?.message === 'string'
      ? event.payload.message.trim()
      : '';
    const risk = typeof event.meta?.risk_level === 'string'
      ? event.meta.risk_level
      : 'unknown';
    const busy = state.decisionInFlightEventId === eventId;
    const commandLine = command || message || '(no command detail)';
    return `<div class="approval-item">
      <div class="approval-item-head">
        <code>${escapeHtml(eventId)}</code>
        <div class="actions-row">
          <button class="button" data-approval-event-id="${escapeHtml(eventId)}" data-approval-decision="approved"${busy ? ' disabled' : ''}>Approve</button>
          <button class="button danger" data-approval-event-id="${escapeHtml(eventId)}" data-approval-decision="denied"${busy ? ' disabled' : ''}>Deny</button>
        </div>
      </div>
      <div class="approval-meta">risk=${escapeHtml(risk)} ${requestId ? `request_id=${escapeHtml(requestId)}` : ''}</div>
      <div class="approval-meta">${escapeHtml(commandLine)}</div>
    </div>`;
  }).join('');
  els.permissionRequests.innerHTML = rows;
}

function renderEventsForSelectedSession() {
  const sessionId = state.selectedSessionId;
  if (!sessionId) {
    els.sessionEventsMeta.textContent = 'No session selected.';
    els.sessionEvents.textContent = '';
    renderPermissionRequests('');
    return;
  }
  const events = Array.isArray(state.eventListBySession[sessionId])
    ? state.eventListBySession[sessionId]
    : [];
  const filter = state.eventsTypeFilter || 'all';
  const filteredEvents = events.filter((event) => matchEventTypeFilter(event, filter));
  const cursor = typeof state.eventCursorBySession[sessionId] === 'string'
    ? state.eventCursorBySession[sessionId]
    : null;
  els.sessionEventsMeta.textContent = `session=${sessionId} events=${filteredEvents.length}/${events.length} filter=${filter}${cursor ? ' cursor=ready' : ''}`;
  if (events.length === 0) {
    els.sessionEvents.textContent = 'No events yet.';
    renderPermissionRequests(sessionId);
    return;
  }
  if (filteredEvents.length === 0) {
    els.sessionEvents.textContent = 'No events matched current filter.';
    renderPermissionRequests(sessionId);
    return;
  }

  const lines = filteredEvents.slice(-120).map((event) => {
    const ts = formatUnixSeconds(Number(event && event.timestamp));
    const eventType = String((event && event.type) || 'unknown');
    const eventId = String((event && event.id) || '-');
    const summary = formatEventSummary(event);
    const summaryPart = summary ? ` ${summary}` : '';
    return `${ts} ${eventType} id=${eventId}${summaryPart}`;
  });
  els.sessionEvents.textContent = lines.join('\n');
  renderPermissionRequests(sessionId);
}

function renderOverview({ health, runtime, kpi, policy, sessions }) {
  els.badgeHealth.textContent = `Health: ${health && health.ok ? 'ok' : 'down'}`;
  els.badgeRuntime.textContent = `Runtime: ${runtime && runtime.available ? 'ready' : 'unavailable'}`;
  els.badgeSessions.textContent = `Sessions: ${Array.isArray(sessions) ? sessions.length : 0}`;

  const lines = [
    ['Bridge Service', health && health.service ? health.service : '-'],
    ['Runtime Command', runtime && runtime.command ? runtime.command : '-'],
    ['Runtime Version', runtime && runtime.version ? runtime.version : '-'],
    ['Runtime Subcommand', runtime && runtime.mcp_subcommand ? runtime.mcp_subcommand : '-'],
    ['Task Completion', kpi && kpi.kpi ? String(kpi.kpi.task.completion_rate ?? '-') : '-'],
    ['Approval Pending', kpi && kpi.kpi ? String(kpi.kpi.approval.pending ?? '-') : '-'],
    ['Strict Reason Gate', policy && policy.enforce_high_risk_reason === true ? 'enabled' : 'disabled']
  ];

  els.overviewList.innerHTML = lines
    .map(([key, value]) => `<dt>${key}</dt><dd>${String(value)}</dd>`)
    .join('');
}

function renderPolicy(policy) {
  state.policy = policy;
  const commands = Array.isArray(policy && policy.whitelist_commands)
    ? policy.whitelist_commands
    : [];
  els.policyWhitelist.value = commands.join(', ');
  els.policyEnforce.checked = policy && policy.enforce_high_risk_reason === true;
}

function renderPolicyAudit(events) {
  state.policyAudit = Array.isArray(events) ? events : [];
  if (state.policyAudit.length === 0) {
    els.policyAuditList.innerHTML = '<li>No audit events</li>';
    return;
  }
  els.policyAuditList.innerHTML = state.policyAudit
    .slice(0, 10)
    .map((event) => {
      const action = event && event.action ? event.action : 'unknown';
      const ts = event && Number.isFinite(event.timestamp)
        ? formatUnixSeconds(event.timestamp)
        : '-';
      const status = event && event.meta && Number.isFinite(event.meta.status)
        ? ` status=${event.meta.status}`
        : '';
      const sessionId = extractSessionIdFromPolicyAuditRecord(event);
      const openButton = sessionId
        ? ` <button class="button ghost" data-open-audit-session="${escapeHtml(sessionId)}">Open Session</button>`
        : '';
      const sessionText = sessionId ? ` session=${escapeHtml(sessionId)}` : '';
      return `<li>${escapeHtml(action)} @ ${escapeHtml(ts)}${escapeHtml(status)}${sessionText}${openButton}</li>`;
    })
    .join('');
}

function extractSessionIdFromPolicyAuditRecord(event) {
  if (!event || typeof event !== 'object') {
    return '';
  }
  const payload = event.payload && typeof event.payload === 'object' ? event.payload : {};
  const detail = payload.detail && typeof payload.detail === 'object' ? payload.detail : {};
  const candidates = [
    payload.session_id,
    payload.sessionId,
    payload.bridge_session_id,
    payload.bridgeSessionId,
    detail.session_id,
    detail.sessionId,
    event.session_id
  ];
  for (const candidate of candidates) {
    if (typeof candidate === 'string' && candidate.trim() !== '') {
      return candidate.trim();
    }
  }
  return '';
}

function renderSessions(sessions) {
  state.sessions = Array.isArray(sessions) ? sessions : [];
  renderCommandTargets();
  if (state.sessions.length === 0) {
    els.sessionTable.innerHTML = '<p>No running sessions.</p>';
    return;
  }

  const rows = state.sessions.map((session) => {
    const bridgeSessionId = String(session.bridge_session_id || session.session_id || 'unknown-session');
    const runtime = String(session.runtime || '-');
    const nativeSessionId = String(session.pi_session_id || session.codex_session_id || '-');
    const mode = String(session.mode || '-');
    const cwd = String(session.cwd || '-');
    const startedAt = formatUnixSeconds(Number(session.started_at));
    const running = session.running === true ? 'yes' : 'no';
    return `<tr>
      <td>${bridgeSessionId}</td>
      <td>${runtime}</td>
      <td>${nativeSessionId}</td>
      <td>${mode}</td>
      <td>${running}</td>
      <td>${startedAt}</td>
      <td>${cwd}</td>
      <td><button class="button danger" data-stop-session="${bridgeSessionId}">Stop</button></td>
    </tr>`;
  }).join('');

  els.sessionTable.innerHTML = `<table class="table">
    <thead>
      <tr>
        <th>bridge_session_id</th>
        <th>runtime</th>
        <th>native_session_id</th>
        <th>mode</th>
        <th>running</th>
        <th>started_at</th>
        <th>cwd</th>
        <th>action</th>
      </tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>`;
}

function renderCommandTargets() {
  const current = state.selectedSessionId;
  const options = state.sessions.map((session) => {
    const bridgeSessionId = String(session.bridge_session_id || session.session_id || '');
    const nativeSessionId = String(session.pi_session_id || session.codex_session_id || '-');
    const runtime = String(session.runtime || '-');
    const label = `${bridgeSessionId} (${runtime}:${nativeSessionId})`;
    return { bridgeSessionId, label };
  }).filter((item) => item.bridgeSessionId.length > 0);

  if (options.length === 0) {
    state.selectedSessionId = '';
    els.commandSessionId.innerHTML = '<option value="">No running sessions</option>';
    els.commandSessionId.disabled = true;
    els.btnSendPrompt.disabled = true;
    els.btnAbortSession.disabled = true;
    els.btnRefreshEvents.disabled = true;
    renderEventsForSelectedSession();
    return;
  }

  const selected = options.find((item) => item.bridgeSessionId === current)
    ? current
    : options[0].bridgeSessionId;
  state.selectedSessionId = selected;
  els.commandSessionId.innerHTML = options
    .map((item) => `<option value="${item.bridgeSessionId}">${item.label}</option>`)
    .join('');
  els.commandSessionId.value = selected;
  els.commandSessionId.disabled = false;
  els.btnSendPrompt.disabled = false;
  els.btnAbortSession.disabled = false;
  els.btnRefreshEvents.disabled = false;
  renderEventsForSelectedSession();
}

async function refreshSessionEvents(options = {}) {
  const sessionId = state.selectedSessionId;
  const forceFull = options.forceFull === true;
  const silent = options.silent === true;
  if (!sessionId) {
    renderEventsForSelectedSession();
    return;
  }

  const knownEvents = Array.isArray(state.eventListBySession[sessionId])
    ? state.eventListBySession[sessionId]
    : [];
  const knownById = new Set(knownEvents.map((event) => String(event && event.id || '')));
  const knownCursor = typeof state.eventCursorBySession[sessionId] === 'string'
    ? state.eventCursorBySession[sessionId]
    : null;
  const cursor = forceFull ? null : knownCursor;
  const query = cursor
    ? `limit=100&cursor=${encodeURIComponent(cursor)}`
    : 'limit=100';

  try {
    const response = await requestJson(`/sessions/${encodeURIComponent(sessionId)}/events?${query}`);
    const incoming = Array.isArray(response.events) ? response.events : [];
    const nextCursor = typeof response.next_cursor === 'string' ? response.next_cursor : null;
    let merged = forceFull || !cursor ? [] : [...knownEvents];
    for (const event of incoming) {
      const eventId = String(event && event.id || '');
      if (eventId && knownById.has(eventId)) {
        continue;
      }
      merged.push(event);
      if (eventId) {
        knownById.add(eventId);
      }
    }
    if (merged.length > 400) {
      merged = merged.slice(-400);
    }
    state.eventListBySession[sessionId] = merged;
    if (nextCursor) {
      state.eventCursorBySession[sessionId] = nextCursor;
    }
    renderEventsForSelectedSession();
  } catch (error) {
    if (!silent) {
      log(`Events refresh failed (${sessionId}): ${error.message}`);
    }
  }
}

async function loadAll() {
  const [health, runtime, sessionsResp, kpi, policy, policyAudit] = await Promise.all([
    requestJson('/health'),
    requestJson('/codex/runtime?runtime=pi_rpc&command=pi'),
    requestJson('/codex/sessions'),
    requestJson('/metrics/kpi?window_seconds=3600'),
    requestJson('/policy/config'),
    requestJson('/policy/audit?limit=20')
  ]);

  const sessions = Array.isArray(sessionsResp.sessions) ? sessionsResp.sessions : [];
  renderOverview({ health, runtime, sessions, kpi, policy });
  renderSessions(sessions);
  renderPolicy(policy);
  renderPolicyAudit(policyAudit.events || []);
  await refreshSessionEvents({ silent: true });
}

async function startSession(event) {
  event.preventDefault();
  const preferredSessionId = String(els.startSessionId.value || '').trim();
  const sessionId = preferredSessionId || `console-${Date.now()}`;

  const mode = String(els.startMode.value || 'mcp').trim() === 'cli' ? 'cli' : 'mcp';
  const cwd = String(els.startCwd.value || '').trim();
  const payload = {
    session_id: sessionId,
    mode,
    runtime: 'pi_rpc'
  };
  if (cwd) {
    payload.cwd = cwd;
  }

  try {
    await requestJson('/codex/sessions/start', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload)
    });
    els.startSessionId.value = sessionId;
    log(`Session started: ${sessionId}`);
    await loadAll();
  } catch (error) {
    log(`Start failed: ${error.message}`);
  }
}

async function stopSession(sessionId) {
  try {
    await requestJson(`/codex/sessions/${encodeURIComponent(sessionId)}/stop`, {
      method: 'POST'
    });
    log(`Session stopped: ${sessionId}`);
    await loadAll();
  } catch (error) {
    log(`Stop failed (${sessionId}): ${error.message}`);
  }
}

function selectedSessionIdFromUI() {
  const previous = state.selectedSessionId;
  const sessionId = String(els.commandSessionId.value || '').trim();
  state.selectedSessionId = sessionId;
  if (sessionId !== previous) {
    renderEventsForSelectedSession();
    const hasCached = Array.isArray(state.eventListBySession[sessionId])
      && state.eventListBySession[sessionId].length > 0;
    if (!hasCached) {
      refreshSessionEvents({ forceFull: true, silent: true });
    }
  }
  return sessionId;
}

function selectRunningSessionForConsole(sessionId) {
  const trimmed = String(sessionId || '').trim();
  if (!trimmed) {
    return false;
  }
  const exists = state.sessions.some((session) => {
    const bridgeSessionId = String(session.bridge_session_id || session.session_id || '');
    return bridgeSessionId === trimmed;
  });
  if (!exists) {
    return false;
  }
  els.commandSessionId.value = trimmed;
  selectedSessionIdFromUI();
  return true;
}

async function sendSessionCommand(sessionId, type, message) {
  const payload = { type };
  if (message) {
    payload.message = message;
  }
  const response = await requestJson(`/codex/sessions/${encodeURIComponent(sessionId)}/command`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return response;
}

function buildPermissionDecisionPath(sessionId) {
  return `/sessions/${encodeURIComponent(sessionId)}/permissions/decide`;
}

function buildElicitationRespondPath(sessionId) {
  return `/codex/sessions/${encodeURIComponent(sessionId)}/elicitation/respond`;
}

function findEventById(sessionId, eventId) {
  const events = Array.isArray(state.eventListBySession[sessionId])
    ? state.eventListBySession[sessionId]
    : [];
  return events.find((event) => String(event && event.id || '') === eventId) || null;
}

async function submitPermissionDecision(eventId, decision) {
  const sessionId = state.selectedSessionId;
  if (!sessionId) {
    log('Approval rejected: no selected session');
    return;
  }
  const event = findEventById(sessionId, eventId);
  if (!event || event.type !== 'permission.requested') {
    log(`Approval rejected: request event not found (${eventId})`);
    return;
  }
  if (state.decisionInFlightEventId) {
    return;
  }
  const reason = decision === 'approved'
    ? 'Approved from bridge console'
    : 'Denied from bridge console';
  const requestId = typeof event.payload?.request_id === 'string'
    ? event.payload.request_id.trim()
    : '';

  state.decisionInFlightEventId = eventId;
  renderPermissionRequests(sessionId);
  try {
    if (requestId) {
      await requestJson(buildElicitationRespondPath(sessionId), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          request_id: requestId,
          request_event_id: eventId,
          decision,
          actor: 'console',
          reason
        })
      });
    } else {
      await requestJson(buildPermissionDecisionPath(sessionId), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          request_event_id: eventId,
          decision,
          actor: 'console',
          reason
        })
      });
    }
    log(`${decision === 'approved' ? 'Approved' : 'Denied'} permission: ${eventId}`);
    await refreshSessionEvents({ forceFull: true, silent: true });
  } catch (error) {
    log(`Approval failed (${eventId}): ${error.message}`);
  } finally {
    state.decisionInFlightEventId = '';
    renderPermissionRequests(sessionId);
  }
}

async function submitPrompt(event) {
  event.preventDefault();
  const sessionId = selectedSessionIdFromUI();
  if (!sessionId) {
    log('Prompt rejected: no running session');
    return;
  }
  const message = String(els.commandMessage.value || '').trim();
  if (!message) {
    log('Prompt rejected: message is empty');
    return;
  }

  els.btnSendPrompt.disabled = true;
  try {
    const result = await sendSessionCommand(sessionId, 'prompt', message);
    const commandId = result && result.command_id ? ` command_id=${result.command_id}` : '';
    log(`Prompt accepted: session=${sessionId}${commandId}`);
    await loadAll();
  } catch (error) {
    log(`Prompt failed (${sessionId}): ${error.message}`);
  } finally {
    els.btnSendPrompt.disabled = false;
  }
}

async function abortSessionCommand() {
  const sessionId = selectedSessionIdFromUI();
  if (!sessionId) {
    log('Abort rejected: no running session');
    return;
  }
  els.btnAbortSession.disabled = true;
  try {
    const result = await sendSessionCommand(sessionId, 'abort');
    const commandId = result && result.command_id ? ` command_id=${result.command_id}` : '';
    log(`Abort accepted: session=${sessionId}${commandId}`);
    await refreshSessionEvents({ silent: true });
  } catch (error) {
    log(`Abort failed (${sessionId}): ${error.message}`);
  } finally {
    els.btnAbortSession.disabled = false;
  }
}

async function applyPolicy(event) {
  event.preventDefault();
  els.btnApplyPolicy.disabled = true;
  const originalLabel = els.btnApplyPolicy.textContent;
  els.btnApplyPolicy.textContent = 'Applying...';

  const payload = {
    whitelist_commands: parseWhitelistInput(els.policyWhitelist.value),
    enforce_high_risk_reason: els.policyEnforce.checked
  };

  try {
    const updated = await requestJson('/console/api/policy/config', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload)
    });
    renderPolicy(updated);
    log('Policy applied from console');
    await loadAll();
  } catch (error) {
    log(`Policy apply failed: ${error.message}`);
  } finally {
    els.btnApplyPolicy.disabled = false;
    els.btnApplyPolicy.textContent = originalLabel;
  }
}

function bindEvents() {
  if (els.eventsTypeFilter) {
    els.eventsTypeFilter.value = state.eventsTypeFilter;
  }
  els.formStartSession.addEventListener('submit', startSession);
  els.formSessionCommand.addEventListener('submit', submitPrompt);
  els.commandSessionId.addEventListener('change', () => {
    selectedSessionIdFromUI();
  });
  els.eventsTypeFilter.addEventListener('change', () => {
    state.eventsTypeFilter = String(els.eventsTypeFilter.value || 'all');
    renderEventsForSelectedSession();
  });
  els.btnRefreshEvents.addEventListener('click', () => {
    refreshSessionEvents({ forceFull: true }).then(() => {
      if (state.selectedSessionId) {
        log(`Events refreshed: ${state.selectedSessionId}`);
      }
    });
  });
  els.btnAbortSession.addEventListener('click', () => {
    abortSessionCommand();
  });
  els.permissionRequests.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const eventId = target.dataset.approvalEventId;
    const decision = target.dataset.approvalDecision;
    if (!eventId || (decision !== 'approved' && decision !== 'denied')) {
      return;
    }
    submitPermissionDecision(eventId, decision);
  });
  els.formPolicy.addEventListener('submit', applyPolicy);
  els.btnRefresh.addEventListener('click', () => {
    loadAll().then(() => {
      log('Refreshed all panels');
    }).catch((error) => {
      log(`Refresh failed: ${error.message}`);
    });
  });
  els.btnReloadPolicy.addEventListener('click', () => {
    Promise.all([
      requestJson('/policy/config'),
      requestJson('/policy/audit?limit=20')
    ]).then(([policy, audit]) => {
      renderPolicy(policy);
      renderPolicyAudit(audit.events || []);
      log('Policy panel reloaded');
    }).catch((error) => {
      log(`Policy reload failed: ${error.message}`);
    });
  });
  els.policyAuditList.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const sessionId = target.dataset.openAuditSession;
    if (!sessionId) {
      return;
    }
    const switched = selectRunningSessionForConsole(sessionId);
    if (switched) {
      log(`Switched to audit session: ${sessionId}`);
      refreshSessionEvents({ forceFull: true, silent: true });
      return;
    }
    log(`Audit session not running: ${sessionId}`);
  });
  els.sessionTable.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const sessionId = target.dataset.stopSession;
    if (!sessionId) {
      return;
    }
    stopSession(sessionId);
  });
}

bindEvents();
loadAll().then(() => {
  log('Console ready');
}).catch((error) => {
  log(`Initial load failed: ${error.message}`);
});
